<?php
session_start();

// Check if treasurer is logged in
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'treasurer') {
    header('Location: index.php');
    exit;
}

// Generate CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Set active tab
if (isset($_POST['active_tab'])) {
    $_SESSION['active_tab'] = $_POST['active_tab'];
}
$active_tab = $_SESSION['active_tab'] ?? 'overview';

// Database connection
$conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Include Dompdf for report generation
require_once 'vendor/autoload.php';
use Dompdf\Dompdf;

// Helper function to validate CSRF token
function validate_csrf_token($token) {
    if (!isset($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token']) || !is_string($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

// Handle financial record update
if (isset($_POST['update_record']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $household_id = $_POST['household_id'];
        $payment_status = $_POST['payment_status'];
        $amount_paid = $_POST['amount_paid'];
        $payment_date = $_POST['payment_date'];
        $notes = $_POST['payment_notes'];
        
        $stmt = $conn->prepare("UPDATE household_financials SET payment_status = ?, amount_paid = ?, last_payment_date = ?, notes = ? WHERE household_id = ?");
        $stmt->bind_param("sdssi", $payment_status, $amount_paid, $payment_date, $notes, $household_id);
        $stmt->execute();
        $stmt->close();
        
        $log_stmt = $conn->prepare("INSERT INTO transaction_logs (transaction_type, related_id, amount, performed_by, notes, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $transaction_type = "Payment Update";
        $treasurer_id = $_SESSION['user']['id'];
        $log_stmt->bind_param("sidis", $transaction_type, $household_id, $amount_paid, $treasurer_id, $notes);
        $log_stmt->execute();
        $log_stmt->close();
        
        $_SESSION['toast_message'] = "Financial record updated successfully!";
        $_SESSION['toast_type'] = "success";
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
} elseif (isset($_POST['update_record'])) {
    $_SESSION['toast_message'] = "CSRF token missing.";
    $_SESSION['toast_type'] = "error";
}

// Handle budget allocation update
if (isset($_POST['update_budget']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $category = $_POST['category'];
        $allocated_amount = $_POST['allocated_amount'];
        $fiscal_year = $_POST['fiscal_year'];
        $description = $_POST['budget_description'];
        
        $check = $conn->prepare("SELECT id FROM barangay_budget WHERE category = ? AND fiscal_year = ?");
        $check->bind_param("ss", $category, $fiscal_year);
        $check->execute();
        $result = $check->get_result();
        $check->close();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $stmt = $conn->prepare("UPDATE barangay_budget SET allocated_amount = ?, description = ? WHERE id = ?");
            $stmt->bind_param("dsi", $allocated_amount, $description, $row['id']);
        } else {
            $stmt = $conn->prepare("INSERT INTO barangay_budget (category, allocated_amount, fiscal_year, description) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sdss", $category, $allocated_amount, $fiscal_year, $description);
        }
        $stmt->execute();
        $stmt->close();

        $_SESSION['toast_message'] = "Budget allocation updated successfully!";
        $_SESSION['toast_type'] = "success";
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
} elseif (isset($_POST['update_budget'])) {
    $_SESSION['toast_message'] = "CSRF token missing.";
    $_SESSION['toast_type'] = "error";
}

// Handle financial aid recording
if (isset($_POST['record_aid']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $household_id = $_POST['household_id'];
        $aid_type = $_POST['aid_type'];
        $amount = $_POST['amount'];
        $distribution_date = $_POST['distribution_date'];
        $notes = $_POST['notes'] ?? null;

        $stmt = $conn->prepare("INSERT INTO financial_aid (household_id, aid_type, amount, distribution_date, notes) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("isdss", $household_id, $aid_type, $amount, $distribution_date, $notes);
        $stmt->execute();
        $stmt->close();

        $log_stmt = $conn->prepare("INSERT INTO transaction_logs (transaction_type, related_id, amount, performed_by, notes, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $transaction_type = "Financial Aid";
        $treasurer_id = $_SESSION['user']['id'];
        $log_stmt->bind_param("sidis", $transaction_type, $household_id, $amount, $treasurer_id, $notes);
        $log_stmt->execute();
        $log_stmt->close();

        $_SESSION['toast_message'] = "Financial aid recorded successfully!";
        $_SESSION['toast_type'] = "success";
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
} elseif (isset($_POST['record_aid'])) {
    $_SESSION['toast_message'] = "CSRF token missing.";
    $_SESSION['toast_type'] = "error";
}

// Handle household add/edit
if (isset($_POST['update_household']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $household_id = $_POST['household_id'] ?? null;
        $household_name = $_POST['household_name'];
        $head_of_family = $_POST['head_of_family'];
        $address = $_POST['address'];
        $members_count = $_POST['members_count'];
        $contact_number = $_POST['contact_number'] ?? null;
        $email = $_POST['email'] ?? null;
        $registration_date = $_POST['registration_date'];
        $status = 'Active';

        if ($household_id) {
            $stmt = $conn->prepare("UPDATE households SET household_name = ?, head_of_family = ?, address = ?, members_count = ?, contact_number = ?, email = ?, registration_date = ? WHERE household_id = ?");
            $stmt->bind_param("sssissii", $household_name, $head_of_family, $address, $members_count, $contact_number, $email, $registration_date, $household_id);
        } else {
            $stmt = $conn->prepare("INSERT INTO households (household_name, head_of_family, address, members_count, contact_number, email, registration_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssissis", $household_name, $head_of_family, $address, $members_count, $contact_number, $email, $registration_date, $status);
        }
        $stmt->execute();
        $new_household_id = $household_id ?: $conn->insert_id;
        $stmt->close();

        $log_stmt = $conn->prepare("INSERT INTO transaction_logs (transaction_type, related_id, amount, performed_by, notes, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $transaction_type = $household_id ? "Household Update" : "Household Add";
        $treasurer_id = $_SESSION['user']['id'];
        $amount = 0;
        $notes = $household_id ? "Updated household: $household_name" : "Added household: $household_name";
        $log_stmt->bind_param("sidis", $transaction_type, $new_household_id, $amount, $treasurer_id, $notes);
        $log_stmt->execute();
        $log_stmt->close();

        $_SESSION['toast_message'] = "Household " . ($household_id ? "updated" : "added") . " successfully!";
        $_SESSION['toast_type'] = "success";
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
} elseif (isset($_POST['update_household'])) {
    $_SESSION['toast_message'] = "CSRF token missing.";
    $_SESSION['toast_type'] = "error";
}

// Handle household status update
if (isset($_POST['update_household_status']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $household_id = $_POST['household_id'];
        $status = $_POST['status'];

        $stmt = $conn->prepare("UPDATE households SET status = ? WHERE household_id = ?");
        $stmt->bind_param("si", $status, $household_id);
        $stmt->execute();
        $stmt->close();

        $log_stmt = $conn->prepare("INSERT INTO transaction_logs (transaction_type, related_id, amount, performed_by, notes, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $transaction_type = "Household Status Update";
        $treasurer_id = $_SESSION['user']['id'];
        $amount = 0;
        $notes = "Updated status to $status for household ID: $household_id";
        $log_stmt->bind_param("sidis", $transaction_type, $household_id, $amount, $treasurer_id, $notes);
        $log_stmt->execute();
        $log_stmt->close();

        $_SESSION['toast_message'] = "Household status updated successfully!";
        $_SESSION['toast_type'] = "success";
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
} elseif (isset($_POST['update_household_status'])) {
    $_SESSION['toast_message'] = "CSRF token missing.";
    $_SESSION['toast_type'] = "error";
}

// Handle searching households
$search_term = '';
if (isset($_GET['search'])) {
    $search_term = $conn->real_escape_string($_GET['search']);
    $households = $conn->query("SELECT * FROM households WHERE household_name LIKE '%$search_term%' OR head_of_family LIKE '%$search_term%' ORDER BY household_name LIMIT 50");
} else {
    $households = $conn->query("SELECT * FROM households ORDER BY household_name LIMIT 50");
}

// Handle searching financial records
$financial_search_term = '';
if (isset($_GET['financial_search'])) {
    $financial_search_term = $conn->real_escape_string($_GET['financial_search']);
    $financials = $conn->query("SELECT hf.*, h.household_name FROM household_financials hf 
                               JOIN households h ON hf.household_id = h.household_id 
                               WHERE h.household_name LIKE '%$financial_search_term%' 
                               ORDER BY hf.last_payment_date DESC LIMIT 20");
} else {
    $financials = $conn->query("SELECT hf.*, h.household_name FROM household_financials hf 
                               JOIN households h ON hf.household_id = h.household_id 
                               ORDER BY hf.last_payment_date DESC LIMIT 20");
}

// Handle searching transaction logs
$transaction_search_term = '';
if (isset($_GET['transaction_search'])) {
    $transaction_search_term = $conn->real_escape_string($_GET['transaction_search']);
    $transactions = $conn->query("SELECT tl.*, bu.first_name FROM transaction_logs tl 
                                 JOIN barangay_users bu ON tl.performed_by = bu.id 
                                 WHERE tl.transaction_type LIKE '%$transaction_search_term%' 
                                 OR bu.first_name LIKE '%$transaction_search_term%' 
                                 ORDER BY tl.created_at DESC LIMIT 50");
} else {
    $transactions = $conn->query("SELECT tl.*, bu.first_name FROM transaction_logs tl 
                                 JOIN barangay_users bu ON tl.performed_by = bu.id 
                                 ORDER BY tl.created_at DESC LIMIT 50");
}

// Get pending payments
$pending_payments = $conn->query("SELECT COUNT(*) as count FROM household_financials WHERE payment_status = 'Pending'");
$pending_count = $pending_payments->fetch_assoc()['count'];

// Get total collected amount
$total_collected = $conn->query("SELECT SUM(amount_paid) as total FROM household_financials WHERE payment_status = 'Paid'");
$collected_amount = $total_collected->fetch_assoc()['total'] ?? 0;

// Get budget allocations
$budget_query = $conn->query("SELECT * FROM barangay_budget WHERE fiscal_year = '2025' ORDER BY category");
$budget_allocations = [];
while ($row = $budget_query->fetch_assoc()) {
    $budget_allocations[] = $row;
}

// Sample budget data if none exists
if (empty($budget_allocations)) {
    $budget_allocations = [
        ['category' => 'Healthcare', 'allocated_amount' => 125000, 'spent_amount' => 78500, 'fiscal_year' => '2025'],
        ['category' => 'Education', 'allocated_amount' => 180000, 'spent_amount' => 95000, 'fiscal_year' => '2025'],
        ['category' => 'Infrastructure', 'allocated_amount' => 250000, 'spent_amount' => 120000, 'fiscal_year' => '2025'],
        ['category' => 'Social Services', 'allocated_amount' => 150000, 'spent_amount' => 65000, 'fiscal_year' => '2025']
    ];
}

// Get recent financial aid distributions
$aid_query = $conn->query("SELECT fa.*, h.household_name FROM financial_aid fa 
                          JOIN households h ON fa.household_id = h.household_id 
                          ORDER BY fa.distribution_date DESC LIMIT 10");
$recent_aid = [];
while ($row = $aid_query->fetch_assoc()) {
    $recent_aid[] = $row;
}

// Get announcements
$announcements = $conn->query("SELECT a.*, bu.first_name 
                               FROM announcements a 
                               JOIN barangay_users bu ON a.created_by = bu.id 
                               WHERE a.is_active = 1 
                               ORDER BY a.created_at DESC LIMIT 10");
$announcement_count = $conn->query("SELECT COUNT(*) as count FROM announcements WHERE is_active = 1")->fetch_assoc()['count'];

// Get monthly financial data for charts
$current_year = date('Y');
$monthly_data = [];
for ($i = 1; $i <= 12; $i++) {
    $income_query = $conn->query("SELECT SUM(amount_paid) as total FROM household_financials 
                                WHERE MONTH(last_payment_date) = $i AND YEAR(last_payment_date) = $current_year");
    $income = $income_query->fetch_assoc()['total'] ?? 0;
    
    $expenses_query = $conn->query("SELECT SUM(amount) as total FROM financial_aid 
                                  WHERE MONTH(distribution_date) = $i AND YEAR(distribution_date) = $current_year");
    $expenses = $expenses_query->fetch_assoc()['total'] ?? 0;
    
    $month_name = date('F', mktime(0, 0, 0, $i, 1));
    $monthly_data[] = ['month' => $month_name, 'income' => floatval($income), 'expenses' => floatval($expenses)];
}

// Sample data if no monthly data
if (empty(array_filter($monthly_data, function($item) { return $item['income'] > 0 || $item['expenses'] > 0; }))) {
    $monthly_data = [
        ['month' => 'January', 'income' => 45000, 'expenses' => 38000],
        ['month' => 'February', 'income' => 52000, 'expenses' => 41000],
        ['month' => 'March', 'income' => 48500, 'expenses' => 39500],
        ['month' => 'April', 'income' => 53000, 'expenses' => 42000]
    ];
}

// Get treasurer's name
$treasurer_email = $_SESSION['user']['email'];
$treasurer_query = $conn->prepare("SELECT first_name FROM barangay_users WHERE email = ? LIMIT 1");
$treasurer_query->bind_param("s", $treasurer_email);
$treasurer_query->execute();
$treasurer_result = $treasurer_query->get_result();
$treasurer_name = "Treasurer";
if ($treasurer_result->num_rows > 0) {
    $treasurer_data = $treasurer_result->fetch_assoc();
    $treasurer_name = $treasurer_data['first_name'];
}
$treasurer_query->close();

// Toast message
$toast_message = $_SESSION['toast_message'] ?? '';
$toast_type = $_SESSION['toast_type'] ?? '';
unset($_SESSION['toast_message']);
unset($_SESSION['toast_type']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Barangay Treasurer Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/treasurer.css">
</head>
<body>
    <div class="mobile-toggle" aria-label="Toggle sidebar">
        <i class="fas fa-bars"></i> Menu
    </div>

    <div class="sidebar" role="navigation">
        <div class="sidebar-header">
            <div class="logo-container">
                <img src="images/1.png" alt="Barangay Logo" class="logo">
                <div class="admin-name"><?php echo htmlspecialchars($treasurer_name); ?></div>
                <div class="admin-role">Barangay Treasurer</div>
            </div>
        </div>
        
        <div class="menu">
            <div class="menu-category">DASHBOARD</div>
            <a href="#" class="menu-item <?php echo $active_tab === 'overview' ? 'active' : ''; ?>" data-target="overview">
                <i class="fas fa-tachometer-alt"></i>
                <span>Overview</span>
            </a>
            
            <div class="menu-category">FINANCIAL MANAGEMENT</div>
            <a href="#" class="menu-item <?php echo $active_tab === 'financial_records' ? 'active' : ''; ?>" data-target="financial_records">
                <i class="fas fa-money-bill-wave"></i>
                <span>Financial Records</span>
                <span class="menu-badge"><?php echo $pending_count; ?></span>
            </a>
            <a href="#" class="menu-item <?php echo $active_tab === 'budget' ? 'active' : ''; ?>" data-target="budget">
                <i class="fas fa-chart-pie"></i>
                <span>Budget Management</span>
            </a>
            <a href="#" class="menu-item <?php echo $active_tab === 'financial_aid' ? 'active' : ''; ?>" data-target="financial_aid">
                <i class="fas fa-hand-holding-heart"></i>
                <span>Financial Aid</span>
            </a>
            <a href="#" class="menu-item <?php echo $active_tab === 'households' ? 'active' : ''; ?>" data-target="households">
                <i class="fas fa-house-user"></i>
                <span>Households</span>
            </a>
            <a href="#" class="menu-item <?php echo $active_tab === 'reports' ? 'active' : ''; ?>" data-target="reports">
                <i class="fas fa-chart-bar"></i>
                <span>Reports</span>
            </a>
            <a href="#" class="menu-item <?php echo $active_tab === 'transactions' ? 'active' : ''; ?>" data-target="transactions">
                <i class="fas fa-list-alt"></i>
                <span>Transaction Logs</span>
            </a>
            <a href="#" class="menu-item <?php echo $active_tab === 'announcements' ? 'active' : ''; ?>" data-target="announcements">
                <i class="fas fa-bullhorn"></i>
                <span>Announcements</span>
                <span class="menu-badge"><?php echo $announcement_count; ?></span>
            </a>
            
            <div class="menu-category">HELP</div>
            <a href="#" class="menu-item <?php echo $active_tab === 'guide' ? 'active' : ''; ?>" data-target="guide">
                <i class="fas fa-book"></i>
                <span>User Guide</span>
            </a>
            
            <div class="menu-category">SETTINGS</div>
            <a href="#" class="menu-item <?php echo $active_tab === 'profile' ? 'active' : ''; ?>" data-target="profile">
                <i class="fas fa-user-circle"></i>
                <span>Profile</span>
            </a>
            <a href="php/logout.php" class="menu-item" id="logoutBtn">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </div>

    <div class="main-content" role="main">
        <div class="dashboard-header">
            <div class="dashboard-header-left">
                <h1 class="page-title">
                    <i class="fas fa-tachometer-alt"></i>
                    Barangay Treasury Management
                </h1>
                <div class="dashboard-header-subtitle">
                    Welcome back, <?php echo htmlspecialchars($treasurer_name); ?>! Today is <?php echo date('F j, Y'); ?>
                </div>
            </div>
            <a href="php/logout.php" class="logout-btn" id="headerLogout" aria-label="Logout">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </div>

        <div class="tab-container">
            <div class="tab-nav">
                <div class="tab-nav-item <?php echo $active_tab === 'overview' ? 'active' : ''; ?>" data-target="overview">Overview</div>
                <div class="tab-nav-item <?php echo $active_tab === 'financial_records' ? 'active' : ''; ?>" data-target="financial_records">Financial Records</div>
                <div class="tab-nav-item <?php echo $active_tab === 'budget' ? 'active' : ''; ?>" data-target="budget">Budget Management</div>
                <div class="tab-nav-item <?php echo $active_tab === 'financial_aid' ? 'active' : ''; ?>" data-target="financial_aid">Financial Aid</div>
                <div class="tab-nav-item <?php echo $active_tab === 'households' ? 'active' : ''; ?>" data-target="households">Households</div>
                <div class="tab-nav-item <?php echo $active_tab === 'reports' ? 'active' : ''; ?>" data-target="reports">Reports</div>
                <div class="tab-nav-item <?php echo $active_tab === 'transactions' ? 'active' : ''; ?>" data-target="transactions">Transaction Logs</div>
                <div class="tab-nav-item <?php echo $active_tab === 'announcements' ? 'active' : ''; ?>" data-target="announcements">Announcements</div>
                <div class="tab-nav-item <?php echo $active_tab === 'guide' ? 'active' : ''; ?>" data-target="guide">User Guide</div>
                <div class="tab-nav-item <?php echo $active_tab === 'profile' ? 'active' : ''; ?>" data-target="profile">Profile</div>
            </div>

            <!-- Overview Tab -->
            <div id="overview" class="tab-content <?php echo $active_tab === 'overview' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-wallet"></i>
                            Financial Overview
                        </h2>
                        <span class="badge badge-primary">Current Fiscal Year: 2025</span>
                    </div>
                    <div class="card-body">
                        <?php
                        $total_budget = 0;
                        $total_spent = 0;
                        foreach ($budget_allocations as $budget) {
                            $total_budget += $budget['allocated_amount'];
                            $total_spent += $budget['spent_amount'];
                        }
                        $budget_percentage = ($total_budget > 0) ? round(($total_spent / $total_budget) * 100) : 0;
                        $budget_remaining = $total_budget - $total_spent;
                        ?>
                        <div class="stats-container">
                            <div class="stat-card">
                                <i class="fas fa-money-bill stat-icon"></i>
                                <div class="stat-value">₱<?php echo number_format($collected_amount, 2); ?></div>
                                <div class="stat-label">TOTAL COLLECTIONS</div>
                            </div>
                            <div class="stat-card">
                                <i class="fas fa-exclamation-circle stat-icon"></i>
                                <div class="stat-value"><?php echo $pending_count; ?></div>
                                <div class="stat-label">PENDING PAYMENTS</div>
                            </div>
                            <div class="stat-card">
                                <i class="fas fa-chart-line stat-icon"></i>
                                <div class="stat-value"><?php echo $budget_percentage; ?>%</div>
                                <div class="stat-label">BUDGET UTILIZATION</div>
                            </div>
                            <div class="stat-card">
                                <i class="fas fa-wallet stat-icon"></i>
                                <div class="stat-value">₱<?php echo number_format($budget_remaining, 2); ?></div>
                                <div class="stat-label">BUDGET REMAINING</div>
                            </div>
                        </div>
                        <h3 style="margin-top: 15px; color: var(--primary);">Monthly Financial Activity</h3>
                        <div class="chart-container">
                            <canvas id="monthlyFinanceChart"></canvas>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-exchange-alt"></i>
                            Recent Transactions
                        </h2>
                        <button class="btn btn-primary btn-sm" data-target="financial_records">
                            <i class="fas fa-list"></i> View All
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" aria-describedby="Recent Transactions">
                                <thead>
                                    <tr>
                                        <th scope="col">Household</th>
                                        <th scope="col">Transaction Type</th>
                                        <th scope="col">Amount</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($financials) {
                                        $financials->data_seek(0);
                                        while ($row = $financials->fetch_assoc()) {
                                            $status_class = ($row['payment_status'] == 'Paid') ? 'success' : 'warning';
                                            echo '<tr>';
                                            echo '<td>' . htmlspecialchars($row['household_name']) . '</td>';
                                            echo '<td>' . htmlspecialchars($row['account_type']) . '</td>';
                                            echo '<td>₱' . number_format($row['amount_paid'], 2) . '</td>';
                                            echo '<td>' . ($row['last_payment_date'] ? date('M d, Y', strtotime($row['last_payment_date'])) : 'N/A') . '</td>';
                                            echo '<td><span class="badge badge-' . $status_class . '">' . htmlspecialchars($row['payment_status']) . '</span></td>';
                                            echo '</tr>';
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Financial Records Tab -->
            <div id="financial_records" class="tab-content <?php echo $active_tab === 'financial_records' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-money-bill-wave"></i>
                            Household Financial Records
                        </h2>
                        <div class="form-group" style="max-width: 280px;">
                            <input type="text" class="form-control-full" id="searchFinancials" placeholder="Search by household name..." value="<?php echo htmlspecialchars($financial_search_term); ?>" aria-label="Search financial records">
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" id="financialsTable" aria-describedby="Household Financial Records">
                                <thead>
                                    <tr>
                                        <th scope="col">Household</th>
                                        <th scope="col">Account Type</th>
                                        <th scope="col">Amount Due</th>
                                        <th scope="col">Amount Paid</th>
                                        <th scope="col">Last Payment</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($financials) {
                                        $financials->data_seek(0);
                                        while ($row = $financials->fetch_assoc()) {
                                            $status_class = ($row['payment_status'] == 'Paid') ? 'success' : 'warning';
                                            echo '<tr>';
                                            echo '<td>' . htmlspecialchars($row['household_name']) . '</td>';
                                            echo '<td>' . htmlspecialchars($row['account_type']) . '</td>';
                                            echo '<td>₱' . number_format($row['amount_due'], 2) . '</td>';
                                            echo '<td>₱' . number_format($row['amount_paid'], 2) . '</td>';
                                            echo '<td>' . ($row['last_payment_date'] ? date('M d, Y', strtotime($row['last_payment_date'])) : 'N/A') . '</td>';
                                            echo '<td><span class="badge badge-' . $status_class . '">' . htmlspecialchars($row['payment_status']) . '</span></td>';
                                            echo '<td>
                                                    <button class="btn btn-primary btn-sm update-payment" data-id="' . $row['household_id'] . '" data-name="' . htmlspecialchars($row['household_name']) . '" data-due="' . $row['amount_due'] . '" data-paid="' . $row['amount_paid'] . '" data-status="' . $row['payment_status'] . '" data-date="' . ($row['last_payment_date'] ?? '') . '" data-notes="' . htmlspecialchars($row['notes'] ?? '') . '">
                                                        <i class="fas fa-edit"></i> Update
                                                    </button>
                                                  </td>';
                                            echo '</tr>';
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Budget Management Tab -->
            <div id="budget" class="tab-content <?php echo $active_tab === 'budget' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-chart-pie"></i>
                            Budget Allocation
                        </h2>
                        <button class="btn btn-primary btn-sm" id="addBudgetBtn">
                            <i class="fas fa-plus"></i> Add Budget Item
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" aria-describedby="Budget Allocation">
                                <thead>
                                    <tr>
                                        <th scope="col">Category</th>
                                        <th scope="col">Allocated Amount</th>
                                        <th scope="col">Spent Amount</th>
                                        <th scope="col">Remaining</th>
                                        <th scope="col">Progress</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($budget_allocations as $budget): ?>
                                        <?php 
                                        $remaining = $budget['allocated_amount'] - $budget['spent_amount'];
                                        $percentage = ($budget['allocated_amount'] > 0) ? round(($budget['spent_amount'] / $budget['allocated_amount']) * 100) : 0;
                                        ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($budget['category']); ?></td>
                                            <td>₱<?php echo number_format($budget['allocated_amount'], 2); ?></td>
                                            <td>₱<?php echo number_format($budget['spent_amount'], 2); ?></td>
                                            <td>₱<?php echo number_format($remaining, 2); ?></td>
                                            <td>
                                                <div class="budget-progress">
                                                    <div class="budget-bar" style="width: <?php echo $percentage; ?>%"></div>
                                                </div>
                                                <small><?php echo $percentage; ?>% used</small>
                                            </td>
                                            <td>
                                                <button class="btn btn-primary btn-sm edit-budget" data-category="<?php echo htmlspecialchars($budget['category']); ?>" data-allocated="<?php echo $budget['allocated_amount']; ?>" data-fiscal-year="<?php echo $budget['fiscal_year']; ?>" data-description="<?php echo htmlspecialchars($budget['description'] ?? ''); ?>">
                                                    <i class="fas fa-edit"></i> Edit
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Financial Aid Tab -->
            <div id="financial_aid" class="tab-content <?php echo $active_tab === 'financial_aid' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-hand-holding-heart"></i>
                            Financial Aid Distribution
                        </h2>
                        <button class="btn btn-primary btn-sm" id="recordAidBtn">
                            <i class="fas fa-plus"></i> Record New Aid
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" aria-describedby="Financial Aid Distribution">
                                <thead>
                                    <tr>
                                        <th scope="col">Household</th>
                                        <th scope="col">Aid Type</th>
                                        <th scope="col">Amount</th>
                                        <th scope="col">Distribution Date</th>
                                        <th scope="col">Notes</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_aid as $aid): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($aid['household_name']); ?></td>
                                            <td><?php echo htmlspecialchars($aid['aid_type']); ?></td>
                                            <td>₱<?php echo number_format($aid['amount'], 2); ?></td>
                                            <td><?php echo date('M d, Y', strtotime($aid['distribution_date'])); ?></td>
                                            <td><?php echo htmlspecialchars($aid['notes'] ?? 'N/A'); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Households Tab -->
            <div id="households" class="tab-content <?php echo $active_tab === 'households' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-house-user"></i>
                            Registered Households
                        </h2>
                        <div class="quick-actions">
                            <input type="text" class="form-control-full" id="searchHouseholds" placeholder="Search by household name or head..." value="<?php echo htmlspecialchars($search_term); ?>" aria-label="Search households">
                            <button class="btn btn-primary btn-sm" id="addHouseholdBtn">
                                <i class="fas fa-plus"></i> Add New Household
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="household-list" id="householdList">
                            <?php if ($households && $households->num_rows > 0): ?>
                                <?php while ($household = $households->fetch_assoc()): ?>
                                    <div class="household-card">
                                        <div class="household-info">
                                            <h3><?php echo htmlspecialchars($household['household_name']); ?></h3>
                                            <p><strong>Head:</strong> <?php echo htmlspecialchars($household['head_of_family']); ?></p>
                                            <p><strong>Members:</strong> <?php echo htmlspecialchars($household['members_count']); ?> | <strong>Status:</strong> <span class="badge badge-<?php echo ($household['status'] == 'Active') ? 'success' : 'warning'; ?>"><?php echo htmlspecialchars($household['status']); ?></span></p>
                                            <p><strong>Registered:</strong> <?php echo date('M d, Y', strtotime($household['registration_date'])); ?></p>
                                        </div>
                                        <div class="household-actions">
                                            <button class="btn btn-primary btn-sm view-household" data-id="<?php echo $household['household_id']; ?>" data-name="<?php echo htmlspecialchars($household['household_name']); ?>" data-head="<?php echo htmlspecialchars($household['head_of_family']); ?>" data-address="<?php echo htmlspecialchars($household['address']); ?>" data-members="<?php echo htmlspecialchars($household['members_count']); ?>" data-contact="<?php echo htmlspecialchars($household['contact_number'] ?? 'N/A'); ?>" data-email="<?php echo htmlspecialchars($household['email'] ?? 'N/A'); ?>" data-status="<?php echo htmlspecialchars($household['status']); ?>" data-registered="<?php echo $household['registration_date']; ?>">
                                                <i class="fas fa-eye"></i> View
                                            </button>
                                            <button class="btn btn-warning btn-sm edit-household" data-id="<?php echo $household['household_id']; ?>" data-name="<?php echo htmlspecialchars($household['household_name']); ?>" data-head="<?php echo htmlspecialchars($household['head_of_family']); ?>" data-address="<?php echo htmlspecialchars($household['address']); ?>" data-members="<?php echo htmlspecialchars($household['members_count']); ?>" data-contact="<?php echo htmlspecialchars($household['contact_number'] ?? ''); ?>" data-email="<?php echo htmlspecialchars($household['email'] ?? ''); ?>" data-registered="<?php echo $household['registration_date']; ?>">
                                                <i class="fas fa-edit"></i> Edit
                                            </button>
                                            <button class="btn btn-primary btn-sm update-household-status" data-id="<?php echo $household['household_id']; ?>" data-status="<?php echo htmlspecialchars($household['status']); ?>">
                                                <i class="fas fa-sync-alt"></i> Update Status
                                            </button>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p>No households found.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

     <div id="reports" class="tab-content <?php echo $active_tab === 'reports' ? 'active' : ''; ?>">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-chart-bar"></i>
                Financial Reports
            </h2>
            <button class="btn btn-primary btn-sm" id="generateReportBtn">
                <i class="fas fa-file-pdf"></i> Generate Report
            </button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table" aria-describedby="Financial Reports">
                    <thead>
                        <tr>
                            <th scope="col">Report Type</th>
                            <th scope="col">Period</th>
                            <th scope="col">Total Income</th>
                            <th scope="col">Total Expenses</th>
                            <th scope="col">Generated By</th>
                            <th scope="col">Date</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
                        $reports_query = $conn->query("SELECT fr.*, bu.first_name 
                                                    FROM financial_reports fr 
                                                    JOIN barangay_users bu ON fr.generated_by = bu.id 
                                                    ORDER BY fr.created_at DESC LIMIT 10");
                        while ($report = $reports_query->fetch_assoc()) {
                            echo "<tr>
                                    <td>" . htmlspecialchars($report['report_type']) . "</td>
                                    <td>" . htmlspecialchars($report['report_period']) . "</td>
                                    <td>₱" . number_format($report['total_income'], 2) . "</td>
                                    <td>₱" . number_format($report['total_expenses'], 2) . "</td>
                                    <td>" . htmlspecialchars($report['first_name']) . "</td>
                                    <td>" . date('M d, Y', strtotime($report['created_at'])) . "</td>
                                    <td>
                                        <a href=\"php/download_report.php?id=" . $report['id'] . "\" class=\"btn btn-primary btn-sm\">
                                            <i class=\"fas fa-download\"></i> Download
                                        </a>
                                    </td>
                                  </tr>";
                        }
                        $conn->close();
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div id="generateReportModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title">Generate Financial Report</h3>
            <button class="modal-close" data-modal="generateReportModal">×</button>
        </div>
        <form action="php/generate_report.php" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
            <div class="form-group">
                <label for="reportType">Report Type</label>
                <select class="form-control-full" id="reportType" name="report_type" required>
                    <option value="Financial Summary">Financial Summary</option>
                    <option value="Budget Utilization">Budget Utilization</option>
                    <option value="Aid Distribution">Aid Distribution</option>
                </select>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="reportPeriod">Period</label>
                    <input type="text" class="form-control-full" id="reportPeriod" name="report_period" placeholder="e.g., Q1 2025" required>
                </div>
                <div class="form-group">
                    <label for="reportDate">Date</label>
                    <input type="date" class="form-control-full" id="reportDate" name="report_date" required>
                </div>
            </div>
            <div class="button-group">
                <button type="button" class="btn btn-secondary modal-close" data-modal="generateReportModal">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-file-pdf"></i> Generate
                </button>
            </div>
        </form>
    </div>
</div>
            <!-- Transaction Logs Tab -->
            <div id="transactions" class="tab-content <?php echo $active_tab === 'transactions' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-list-alt"></i>
                            Transaction Logs
                        </h2>
                        <div class="form-group" style="max-width: 280px;">
                            <input type="text" class="form-control-full" id="searchTransactions" placeholder="Search by type or user..." value="<?php echo htmlspecialchars($transaction_search_term); ?>" aria-label="Search transactions">
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" id="transactionsTable" aria-describedby="Transaction Logs">
                                <thead>
                                    <tr>
                                        <th scope="col">Transaction Type</th>
                                        <th scope="col">Performed By</th>
                                        <th scope="col">Amount</th>
                                        <th scope="col">Related ID</th>
                                        <th scope="col">Notes</th>
                                        <th scope="col">Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($transactions) {
                                        $transactions->data_seek(0);
                                        while ($row = $transactions->fetch_assoc()): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($row['transaction_type']); ?></td>
                                                <td><?php echo htmlspecialchars($row['first_name']); ?></td>
                                                <td>₱<?php echo number_format($row['amount'], 2); ?></td>
                                                <td><?php echo htmlspecialchars($row['related_id'] ?? 'N/A'); ?></td>
                                                <td><?php echo htmlspecialchars($row['notes'] ?? 'N/A'); ?></td>
                                                <td><?php echo date('M d, Y H:i', strtotime($row['created_at'])); ?></td>
                                            </tr>
                                        <?php endwhile;
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Announcements Tab -->
            <div id="announcements" class="tab-content <?php echo $active_tab === 'announcements' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-bullhorn"></i>
                            Announcements
                        </h2>
                    </div>
                    <div class="card-body">
                        <div class="household-list">
                            <?php if ($announcements && $announcements->num_rows > 0): ?>
                                <?php while ($announcement = $announcements->fetch_assoc()): ?>
                                    <div class="household-card">
                                        <div class="household-info alert alert-info">
                                            <h3><?php echo htmlspecialchars($announcement['title']); ?></h3>
                                            <p><?php echo htmlspecialchars($announcement['content']); ?></p>
                                            <p><strong>Posted by:</strong> <?php echo htmlspecialchars($announcement['first_name']); ?> on <?php echo date('M d, Y H:i', strtotime($announcement['created_at'])); ?></p>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p>No announcements found.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- User Guide Tab -->
            <div id="guide" class="tab-content <?php echo $active_tab === 'guide' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-book"></i>
                            User Guide
                        </h2>
                    </div>
                    <div class="card-body">
                        <h3>Welcome to the Barangay Treasurer Dashboard</h3>
                        <p>This guide provides an overview of the dashboard's features and how to navigate them effectively. As the Barangay Treasurer, you can manage financial records, budget allocations, household data, and more.</p>
                        
                        <h4>Key Features</h4>
                        <ul>
                            <li><strong>Overview:</strong> View financial summaries, including total collections, pending payments, and budget utilization. Use the monthly financial chart to track income and expenses.</li>
                            <li><strong>Financial Records:</strong> Manage household payments, update statuses, and log transactions. Use the search bar to find specific records quickly.</li>
                            <li><strong>Budget Management:</strong> Allocate and track budgets for various categories. Edit or add new budget items to reflect current fiscal plans.</li>
                            <li><strong>Financial Aid:</strong> Record and review aid distributions to households, ensuring accurate documentation.</li>
                            <li><strong>Households:</strong> View, edit, or add household information. Update statuses and manage contact details.</li>
                            <li><strong>Reports:</strong> Generate and download financial reports in PDF format for transparency and record-keeping.</li>
                            <li><strong>Transaction Logs:</strong> Review all financial transactions, including updates and distributions, with detailed notes.</li>
                            <li><strong>Announcements:</strong> Stay updated on barangay announcements and share important notices.</li>
                            <li><strong>Profile:</strong> Manage your account details and update your password.</li>
                        </ul>

                        <h4>Navigation Tips</h4>
                        <ul>
                            <li>Use the sidebar or top tabs to switch between sections. On mobile, tap the menu button to toggle the sidebar.</li>
                            <li>Click the <strong>Update</strong>, <strong>Edit</strong>, or <strong>Add</strong> buttons to open modals for data entry.</li>
                            <li>Search bars are available in the Financial Records, Households, and Transaction Logs tabs to filter data quickly.</li>
                            <li>Hover over cards or buttons for a subtle animation, indicating they are clickable.</li>
                            <li>Ensure all forms are filled correctly to avoid errors. CSRF tokens are automatically included for security.</li>
                        </ul>

                        <h4>Need Help?</h4>
                        <p>If you encounter issues or have questions, contact the system administrator or refer to the official barangay documentation. Your feedback helps us improve the dashboard!</p>
                    </div>
                </div>
            </div>

            <!-- Profile Tab -->
            <div id="profile" class="tab-content <?php echo $active_tab === 'profile' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-user-circle"></i>
                            User Profile
                        </h2>
                    </div>
                    <div class="card-body">
                        <form action="php/update_profile.php" method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="first_name">First Name</label>
                                    <input type="text" class="form-control-full" id="first_name" name="first_name" value="<?php echo htmlspecialchars($treasurer_name); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control-full" id="email" name="email" value="<?php echo htmlspecialchars($_SESSION['user']['email']); ?>" required>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="new_password">New Password (optional)</label>
                                    <input type="password" class="form-control-full" id="new_password" name="new_password" placeholder="Leave blank to keep current password">
                                </div>
                                <div class="form-group">
                                    <label for="confirm_password">Confirm New Password</label>
                                    <input type="password" class="form-control-full" id="confirm_password" name="confirm_password" placeholder="Confirm new password">
                                </div>
                            </div>
                            <div class="button-group">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Save Changes
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modals -->
    <!-- Update Payment Modal -->
    <div id="updatePaymentModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Update Payment</h3>
                <button class="modal-close" data-modal="updatePaymentModal">×</button>
            </div>
            <form action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="household_id" id="paymentHouseholdId">
                <input type="hidden" name="update_record" value="1">
                <div class="form-group">
                    <label for="paymentHouseholdName">Household Name</label>
                    <input type="text" class="form-control-full" id="paymentHouseholdName" disabled>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="amountDue">Amount Due</label>
                        <input type="number" step="0.01" class="form-control-full" id="amountDue" disabled>
                    </div>
                    <div class="form-group">
                        <label for="amountPaid">Amount Paid</label>
                        <input type="number" step="0.01" class="form-control-full" id="amountPaid" name="amount_paid" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="paymentStatus">Payment Status</label>
                        <select class="form-control-full" id="paymentStatus" name="payment_status" required>
                            <option value="Pending">Pending</option>
                            <option value="Paid">Paid</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="paymentDate">Payment Date</label>
                        <input type="date" class="form-control-full" id="paymentDate" name="payment_date" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="paymentNotes">Notes</label>
                    <textarea class="form-control-full" id="paymentNotes" name="payment_notes" rows="4"></textarea>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close" data-modal="updatePaymentModal">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add/Edit Budget Modal -->
    <div id="budgetModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Budget Allocation</h3>
                <button class="modal-close" data-modal="budgetModal">×</button>
            </div>
            <form action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="update_budget" value="1">
                <div class="form-group">
                    <label for="budgetCategory">Category</label>
                    <input type="text" class="form-control-full" id="budgetCategory" name="category" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="allocatedAmount">Allocated Amount</label>
                        <input type="number" step="0.01" class="form-control-full" id="allocatedAmount" name="allocated_amount" required>
                    </div>
                    <div class="form-group">
                        <label for="fiscalYear">Fiscal Year</label>
                        <input type="text" class="form-control-full" id="fiscalYear" name="fiscal_year" value="2025" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="budgetDescription">Description</label>
                    <textarea class="form-control-full" id="budgetDescription" name="budget_description" rows="4"></textarea>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close" data-modal="budgetModal">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Record Aid Modal -->
    <div id="recordAidModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Record Financial Aid</h3>
                <button class="modal-close" data-modal="recordAidModal">×</button>
            </div>
            <form action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="record_aid" value="1">
                <div class="form-group">
                    <label for="aidHouseholdId">Household</label>
                    <select class="form-control-full" id="aidHouseholdId" name="household_id" required>
                        <option value="">Select Household</option>
                        <?php
                        $households->data_seek(0);
                        while ($household = $households->fetch_assoc()) {
                            echo '<option value="' . $household['household_id'] . '">' . htmlspecialchars($household['household_name']) . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="aidType">Aid Type</label>
                        <input type="text" class="form-control-full" id="aidType" name="aid_type" required>
                    </div>
                    <div class="form-group">
                        <label for="aidAmount">Amount</label>
                        <input type="number" step="0.01" class="form-control-full" id="aidAmount" name="amount" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="distributionDate">Distribution Date</label>
                    <input type="date" class="form-control-full" id="distributionDate" name="distribution_date" required>
                </div>
                <div class="form-group">
                    <label for="aidNotes">Notes</label>
                    <textarea class="form-control-full" id="aidNotes" name="notes" rows="4"></textarea>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close" data-modal="recordAidModal">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add/Edit Household Modal -->
    <div id="householdModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Household Information</h3>
                <button class="modal-close" data-modal="householdModal">×</button>
            </div>
            <form action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="household_id" id="householdId">
                <input type="hidden" name="update_household" value="1">
                <div class="form-row">
                    <div class="form-group">
                        <label for="householdName">Household Name</label>
                        <input type="text" class="form-control-full" id="householdName" name="household_name" required>
                    </div>
                    <div class="form-group">
                        <label for="headOfFamily">Head of Family</label>
                        <input type="text" class="form-control-full" id="headOfFamily" name="head_of_family" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="householdAddress">Address</label>
                    <input type="text" class="form-control-full" id="householdAddress" name="address" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="membersCount">Number of Members</label>
                        <input type="number" class="form-control-full" id="membersCount" name="members_count" required>
                    </div>
                    <div class="form-group">
                        <label for="contactNumber">Contact Number</label>
                        <input type="text" class="form-control-full" id="contactNumber" name="contact_number">
                    </div>
                </div>
                <div class="form-group">
                    <label for="householdEmail">Email</label>
                    <input type="email" class="form-control-full" id="householdEmail" name="email">
                </div>
                <div class="form-group">
                    <label for="registrationDate">Registration Date</label>
                    <input type="date" class="form-control-full" id="registrationDate" name="registration_date" required>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close" data-modal="householdModal">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Household Modal -->
    <div id="viewHouseholdModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Household Details</h3>
                <button class="modal-close" data-modal="viewHouseholdModal">×</button>
            </div>
            <div class="form-group">
                <label>Household Name</label>
                <p id="viewHouseholdName"></p>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Head of Family</label>
                    <p id="viewHeadOfFamily"></p>
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <p id="viewHouseholdAddress"></p>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Number of Members</label>
                    <p id="viewMembersCount"></p>
                </div>
                <div class="form-group">
                    <label>Contact Number</label>
                    <p id="viewContactNumber"></p>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Email</label>
                    <p id="viewHouseholdEmail"></p>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <p id="viewHouseholdStatus"></p>
                </div>
            </div>
            <div class="form-group">
                <label>Registration Date</label>
                <p id="viewRegistrationDate"></p>
            </div>
            <div class="button-group">
                <button type="button" class="btn btn-secondary modal-close" data-modal="viewHouseholdModal">
                    <i class="fas fa-times"></i> Close
                </button>
            </div>
        </div>
    </div>

    <!-- Update Household Status Modal -->
    <div id="updateHouseholdStatusModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Update Household Status</h3>
                <button class="modal-close" data-modal="updateHouseholdStatusModal">×</button>
            </div>
            <form action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="household_id" id="statusHouseholdId">
                <input type="hidden" name="update_household_status" value="1">
                <div class="form-group">
                    <label for="householdStatus">Status</label>
                    <select class="form-control-full" id="householdStatus" name="status" required>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                    </select>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close" data-modal="updateHouseholdStatusModal">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Toast Notifications -->
    <?php if ($toast_message): ?>
        <div class="toast-container">
            <div class="toast toast-<?php echo $toast_type; ?>">
                <div class="toast-header">
                    <span class="toast-title">
                        <i class="fas fa-<?php echo $toast_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                        <?php echo $toast_type === 'success' ? 'Success' : 'Error'; ?>
                    </span>
                    <button class="toast-close">×</button>
                </div>
                <div class="toast-body">
                    <?php echo htmlspecialchars($toast_message); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <script>
        $(document).ready(function() {
            // Sidebar toggle for mobile
            $('.mobile-toggle').click(function() {
                $('.sidebar').toggleClass('show');
            });

            // Close sidebar when clicking outside on mobile
            $(document).click(function(e) {
                if ($(window).width() <= 768 && !$(e.target).closest('.sidebar').length && !$(e.target).closest('.mobile-toggle').length) {
                    $('.sidebar').removeClass('show');
                }
            });

            // Tab navigation
            $('.tab-nav-item, .menu-item').click(function(e) {
                e.preventDefault();
                var target = $(this).data('target');
                $('.tab-nav-item').removeClass('active');
                $('.tab-content').removeClass('active');
                $('.menu-item').removeClass('active');
                
                $('.tab-nav-item[data-target="' + target + '"]').addClass('active');
                $('#' + target).addClass('active');
                $('.menu-item[data-target="' + target + '"]').addClass('active');

                // Update active tab via AJAX
                $.post('', { active_tab: target });
            });

            // Modal handling
function openModal(modalId) {
    $('#' + modalId).fadeIn();
    $('body').css('overflow', 'hidden');
}

            function closeModal(modalId) {
                $('#' + modalId).fadeOut();
                $('body').css('overflow', 'auto');
            }

            $('.modal-close').click(function() {
                var modalId = $(this).data('modal');
                closeModal(modalId);
            });
// Generate Report Modal
$('#generateReportBtn').click(function() {
    $('#reportType').val('Financial Summary');
    $('#reportPeriod').val('');
    $('#reportDate').val('');
    openModal('generateReportModal');
});

$(document).ready(function() {
    $('#generateReportBtn').click(function() {
        openModal('generateReportModal');
    });
});
            // Update Payment Modal
            $('.update-payment').click(function() {
                var id = $(this).data('id');
                var name = $(this).data('name');
                var due = $(this).data('due');
                var paid = $(this).data('paid');
                var status = $(this).data('status');
                var date = $(this).data('date');
                var notes = $(this).data('notes');

                $('#paymentHouseholdId').val(id);
                $('#paymentHouseholdName').val(name);
                $('#amountDue').val(due);
                $('#amountPaid').val(paid);
                $('#paymentStatus').val(status);
                $('#paymentDate').val(date);
                $('#paymentNotes').val(notes);

                openModal('updatePaymentModal');
            });

            // Add/Edit Budget Modal
            $('#addBudgetBtn').click(function() {
                $('#budgetModal .modal-title').text('Add Budget Item');
                $('#budgetCategory').val('');
                $('#allocatedAmount').val('');
                $('#fiscalYear').val('2025');
                $('#budgetDescription').val('');
                openModal('budgetModal');
            });

            $('.edit-budget').click(function() {
                $('#budgetModal .modal-title').text('Edit Budget Item');
                $('#budgetCategory').val($(this).data('category'));
                $('#allocatedAmount').val($(this).data('allocated'));
                $('#fiscalYear').val($(this).data('fiscal-year'));
                $('#budgetDescription').val($(this).data('description'));
                openModal('budgetModal');
            });

            // Record Aid Modal
            $('#recordAidBtn').click(function() {
                $('#aidHouseholdId').val('');
                $('#aidType').val('');
                $('#aidAmount').val('');
                $('#distributionDate').val('');
                $('#aidNotes').val('');
                openModal('recordAidModal');
            });

            // Add/Edit Household Modal
            $('#addHouseholdBtn').click(function() {
                $('#householdModal .modal-title').text('Add New Household');
                $('#householdId').val('');
                $('#householdName').val('');
                $('#headOfFamily').val('');
                $('#householdAddress').val('');
                $('#membersCount').val('');
                $('#contactNumber').val('');
                $('#householdEmail').val('');
                $('#registrationDate').val('');
                openModal('householdModal');
            });

            $('.edit-household').click(function() {
                $('#householdModal .modal-title').text('Edit Household');
                $('#householdId').val($(this).data('id'));
                $('#householdName').val($(this).data('name'));
                $('#headOfFamily').val($(this).data('head'));
                $('#householdAddress').val($(this).data('address'));
                $('#membersCount').val($(this).data('members'));
                $('#contactNumber').val($(this).data('contact'));
                $('#householdEmail').val($(this).data('email'));
                $('#registrationDate').val($(this).data('registered'));
                openModal('householdModal');
            });

            // View Household Modal
            $('.view-household').click(function() {
                $('#viewHouseholdName').text($(this).data('name'));
                $('#viewHeadOfFamily').text($(this).data('head'));
                $('#viewHouseholdAddress').text($(this).data('address'));
                $('#viewMembersCount').text($(this).data('members'));
                $('#viewContactNumber').text($(this).data('contact'));
                $('#viewHouseholdEmail').text($(this).data('email'));
                $('#viewHouseholdStatus').text($(this).data('status'));
                $('#viewRegistrationDate').text(new Date($(this).data('registered')).toLocaleDateString());
                openModal('viewHouseholdModal');
            });

            // Update Household Status Modal
            $('.update-household-status').click(function() {
                $('#statusHouseholdId').val($(this).data('id'));
                $('#householdStatus').val($(this).data('status'));
                openModal('updateHouseholdStatusModal');
            });

            // Search functionality
            $('#searchFinancials').on('input', function() {
                var query = $(this).val();
                window.location.href = '?financial_search=' + encodeURIComponent(query) + '#financial_records';
            });

            $('#searchHouseholds').on('input', function() {
                var query = $(this).val();
                window.location.href = '?search=' + encodeURIComponent(query) + '#households';
            });

            $('#searchTransactions').on('input', function() {
                var query = $(this).val();
                window.location.href = '?transaction_search=' + encodeURIComponent(query) + '#transactions';
            });

            // Chart initialization
            var monthlyData = <?php echo json_encode($monthly_data); ?>;
            var ctx = document.getElementById('monthlyFinanceChart').getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: monthlyData.map(item => item.month),
                    datasets: [
                        {
                            label: 'Income',
                            data: monthlyData.map(item => item.income),
                            backgroundColor: 'rgba(11, 83, 69, 0.7)',
                            borderColor: 'rgba(11, 83, 69, 1)',
                            borderWidth: 1
                        },
                        {
                            label: 'Expenses',
                            data: monthlyData.map(item => item.expenses),
                            backgroundColor: 'rgba(231, 76, 60, 0.7)',
                            borderColor: 'rgba(231, 76, 60, 1)',
                            borderWidth: 1
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Amount (₱)'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            position: 'top'
                        },
                        title: {
                            display: true,
                            text: 'Monthly Financial Activity'
                        }
                    }
                }
            });

            // Toast handling
            $('.toast-close').click(function() {
                $(this).closest('.toast').fadeOut();
            });

            setTimeout(function() {
                $('.toast').fadeOut();
            }, 5000);

            // Prevent modal form resubmission on page refresh
            if (window.history.replaceState) {
                window.history.replaceState(null, null, window.location.href);
            }
        });
    </script>
</body>
</html>