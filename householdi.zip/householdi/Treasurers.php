<?php
// Set secure session parameters before starting the session
ini_set('session.cookie_httponly', 1);
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}

session_start();

// Basic security measure - regenerate session ID after login
if (isset($_SESSION['just_logged_in']) && $_SESSION['just_logged_in'] === true) {
    session_regenerate_id(true);
    $_SESSION['just_logged_in'] = false;
}

// Session timeout (30 minutes)
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: index.php?timeout=1');
    exit;
}
$_SESSION['last_activity'] = time();

// Check if treasurer is logged in
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'treasurer') {
    header('Location: index.php');
    exit;
}

// Include the configuration file for database connection
require_once 'php/config.php';

// Generate CSRF token if not present
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Toast message system
$toast_message = '';
$toast_type = '';

if (isset($_SESSION['toast_message'], $_SESSION['toast_type'])) {
    $toast_message = $_SESSION['toast_message'];
    $toast_type = $_SESSION['toast_type'];
    unset($_SESSION['toast_message']);
    unset($_SESSION['toast_type']);
}

// Create database helper class for secure operations
class DatabaseHelper {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    public function prepare($sql) {
        try {
            $stmt = $this->conn->prepare($sql);
            if (!$stmt) {
                error_log("PDO prepare error: " . implode(", ", $this->conn->errorInfo()));
                return false;
            }
            return $stmt;
        } catch (PDOException $e) {
            error_log("PDO prepare exception: " . $e->getMessage());
            return false;
        }
    }
    
    public function query($sql) {
        try {
            return $this->conn->query($sql);
        } catch (PDOException $e) {
            error_log("PDO query error: " . $e->getMessage());
            return false;
        }
    }
    
    public function executeTransaction($callback) {
        try {
            $this->conn->beginTransaction();
            $result = $callback($this);
            if ($result) {
                $this->conn->commit();
                return true;
            } else {
                $this->conn->rollBack();
                return false;
            }
        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log("Transaction error: " . $e->getMessage());
            return false;
        }
    }
    
    public function close() {
        $this->conn = null;
        return true;
    }
}

$db = new DatabaseHelper($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['record_aid'], $_POST['csrf_token'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        setToastMessage("Security verification failed", "error");
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    
    $household_id = filter_input(INPUT_POST, 'household_id', FILTER_VALIDATE_INT);
    $aid_amount = filter_input(INPUT_POST, 'aid_amount', FILTER_VALIDATE_FLOAT);
    $aid_type = filter_input(INPUT_POST, 'aid_type', FILTER_SANITIZE_STRING);
    $distribution_date = filter_input(INPUT_POST, 'distribution_date', FILTER_SANITIZE_STRING);
    $notes = filter_input(INPUT_POST, 'aid_notes', FILTER_SANITIZE_STRING) ?? '';
    
    if (!$household_id || !$aid_amount || !$aid_type || !validateDate($distribution_date)) {
        setToastMessage("Invalid input data", "error");
    } else {
        $status = 'distributed';
        
        $db->executeTransaction(function($dbHelper) use ($household_id, $aid_amount, $aid_type, $distribution_date, $status, $notes) {
            $stmt = $dbHelper->prepare("INSERT INTO financial_aid (household_id, amount, purpose, date_released, recorded_by, notes) VALUES (:household_id, :amount, :purpose, :date_released, :recorded_by, :notes)");
            if (!$stmt) return false;
            
            $user_id = $_SESSION['user']['user_id'];
            $stmt->execute([
                ':household_id' => $household_id,
                ':amount' => $aid_amount,
                ':purpose' => $aid_type,
                ':date_released' => $distribution_date,
                ':recorded_by' => $user_id,
                ':notes' => $notes
            ]);
            $result = $stmt->rowCount() > 0;
            $stmt->close();

            if ($result) {
                $aid_id = $dbHelper->conn->lastInsertId();
                $logStmt = $dbHelper->prepare("INSERT INTO activity_log (user_id, action_type, entity_type, entity_id, details) VALUES (:user_id, :action_type, :entity_type, :entity_id, :details)");
                if (!$logStmt) return false;
                
                $details = "Added financial aid record: ₱" . number_format($aid_amount, 2) . " for household #$household_id";
                $logStmt->execute([
                    ':user_id' => $user_id,
                    ':action_type' => 'insert',
                    ':entity_type' => 'financial_aid',
                    ':entity_id' => $aid_id,
                    ':details' => $details
                ]);
                $logResult = $logStmt->rowCount() > 0;
                $logStmt->close();
                
                return $result && $logResult;
            }
            return false;
        }) ? setToastMessage("Financial aid record added successfully!", "success") : setToastMessage("Failed to add financial aid record", "error");
    }
    
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Handle household financial profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_household'], $_POST['csrf_token'])) {
    // Validate CSRF token
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        setToastMessage("Security verification failed", "error");
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    
    $household_id = filter_input(INPUT_POST, 'household_id', FILTER_VALIDATE_INT);
    $income_level = filter_input(INPUT_POST, 'income_level', FILTER_VALIDATE_FLOAT);
    $financial_status = filter_input(INPUT_POST, 'financial_status', FILTER_SANITIZE_STRING);
    $last_assessment_date = date('Y-m-d'); // Current date
    
    // Input validation
    if (!$household_id || !$income_level || !in_array($financial_status, ['Low Income', 'Middle Income', 'High Income'])) {
        setToastMessage("Invalid input data", "error");
    } else {
        $db->executeTransaction(function($dbHelper) use ($income_level, $financial_status, $last_assessment_date, $household_id) {
            // Update household
            $stmt = $dbHelper->prepare("UPDATE households SET income_level = ?, financial_status = ?, last_assessment_date = ? WHERE household_id = ?");
            if (!$stmt) return false;
            
            $stmt->bind_param("dssi", $income_level, $financial_status, $last_assessment_date, $household_id);
            $result = $stmt->execute();
            $stmt->close();
            
            // Log the update
            $user_id = $_SESSION['user']['user_id'];
            $logStmt = $dbHelper->prepare("INSERT INTO activity_log (user_id, action_type, entity_type, entity_id, details) VALUES (?, 'update', 'household', ?, ?)");
            if (!$logStmt) return false;
            
            $details = "Updated household financial profile: income level = ₱" . number_format($income_level, 2) . ", status = $financial_status";
            $logStmt->bind_param("iis", $user_id, $household_id, $details);
            $logResult = $logStmt->execute();
            $logStmt->close();
            
            return $result && $logResult;
        }) ? setToastMessage("Household financial profile updated successfully!", "success") : setToastMessage("Failed to update household financial profile", "error");
    }
    
    // Redirect to prevent form resubmission
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Handle budget allocation creation/update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['allocate_budget'], $_POST['csrf_token'])) {
    // Validate CSRF token
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        setToastMessage("Security verification failed", "error");
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    
    $program_id = filter_input(INPUT_POST, 'program_id', FILTER_VALIDATE_INT);
    $allocation_amount = filter_input(INPUT_POST, 'allocation_amount', FILTER_VALIDATE_FLOAT);
    $allocation_period = filter_input(INPUT_POST, 'allocation_period', FILTER_SANITIZE_STRING);
    $allocation_notes = filter_input(INPUT_POST, 'allocation_notes', FILTER_SANITIZE_STRING) ?? '';
    
    // Input validation
    if (!$program_id || !$allocation_amount || !$allocation_period) {
        setToastMessage("Invalid input data", "error");
    } else {
        $db->executeTransaction(function($dbHelper) use ($program_id, $allocation_amount, $allocation_period, $allocation_notes) {
            // Check if allocation exists
            $check = $dbHelper->prepare("SELECT allocation_id FROM budget_allocations WHERE program_id = ? AND allocation_period = ?");
            if (!$check) return false;
            
            $check->bind_param("is", $program_id, $allocation_period);
            if (!$check->execute()) {
                $check->close();
                return false;
            }
            
            $result = $check->get_result();
            $isUpdate = $result->num_rows > 0;
            $allocation_id = $isUpdate ? $result->fetch_assoc()['allocation_id'] : 0;
            $check->close();
            
            // Prepare the appropriate statement (update or insert)
            if ($isUpdate) {
                $stmt = $dbHelper->prepare("UPDATE budget_allocations SET amount = ?, notes = ?, updated_at = NOW() WHERE allocation_id = ?");
                if (!$stmt) return false;
                
                $stmt->bind_param("dsi", $allocation_amount, $allocation_notes, $allocation_id);
            } else {
                $stmt = $dbHelper->prepare("INSERT INTO budget_allocations (program_id, amount, allocation_period, notes, allocated_by) VALUES (?, ?, ?, ?, ?)");
                if (!$stmt) return false;
                
                $treasurer_id = $_SESSION['user']['user_id'];
                $stmt->bind_param("idssi", $program_id, $allocation_amount, $allocation_period, $allocation_notes, $treasurer_id);
            }
            
            $result = $stmt->execute();
            if (!$isUpdate) $allocation_id = $dbHelper->conn->insert_id;
            $stmt->close();
            
            // Log the transaction
            $user_id = $_SESSION['user']['user_id'];
            $action_type = $isUpdate ? 'update' : 'insert';
            $logStmt = $dbHelper->prepare("INSERT INTO activity_log (user_id, action_type, entity_type, entity_id, details) VALUES (?, ?, 'budget_allocation', ?, ?)");
            if (!$logStmt) return false;
            
            $details = ($isUpdate ? "Updated" : "Created") . " budget allocation: ₱" . number_format($allocation_amount, 2) . " for program #$program_id, period $allocation_period";
            $logStmt->bind_param("isis", $user_id, $action_type, $allocation_id, $details);
            $logResult = $logStmt->execute();
            $logStmt->close();
            
            return $result && $logResult;
        }) ? setToastMessage("Budget allocation saved successfully!", "success") : setToastMessage("Failed to save budget allocation", "error");
    }
    
    // Redirect to prevent form resubmission
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Handle aid request approval/denial
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['process_request'], $_POST['csrf_token'])) {
    // Validate CSRF token
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        setToastMessage("Security verification failed", "error");
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    
    $request_id = filter_input(INPUT_POST, 'request_id', FILTER_VALIDATE_INT);
    $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING);
    $remarks = filter_input(INPUT_POST, 'remarks', FILTER_SANITIZE_STRING);
    
    // Input validation
    if (!$request_id || !in_array($status, ['distributed', 'denied']) || !$remarks) {
        setToastMessage("Invalid input data", "error");
    } else {
        $db->executeTransaction(function($dbHelper) use ($status, $remarks, $request_id) {
            // Update financial aid status
            $stmt = $dbHelper->prepare("UPDATE financial_aid SET status = ?, notes = CONCAT(IFNULL(notes, ''), '\nProcessed on ', NOW(), ': ', ?), updated_at = NOW() WHERE id = ? AND status = 'pending'");
            if (!$stmt) return false;
            
            $stmt->bind_param("ssi", $status, $remarks, $request_id);
            $result = $stmt->execute();
            if ($stmt->affected_rows === 0) {
                // Request might have been processed already
                $stmt->close();
                return false;
            }
            $stmt->close();
            
            // Log the action
            $user_id = $_SESSION['user']['user_id'];
            $logStmt = $dbHelper->prepare("INSERT INTO activity_log (user_id, action_type, entity_type, entity_id, details) VALUES (?, 'update', 'financial_aid', ?, ?)");
            if (!$logStmt) return false;
            
            $details = "Processed aid request #$request_id: $status, with remarks: $remarks";
            $logStmt->bind_param("iis", $user_id, $request_id, $details);
            $logResult = $logStmt->execute();
            $logStmt->close();
            
            return $result && $logResult;
        }) ? setToastMessage("Aid request " . ($status === 'distributed' ? 'approved' : 'denied') . " successfully!", "success") : setToastMessage("Failed to process aid request or request already processed", "error");
    }
    
    // Redirect to prevent form resubmission
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'], $_POST['csrf_token'])) {
    // Validate CSRF token
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        setToastMessage("Security verification failed", "error");
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    
    $fullname = filter_input(INPUT_POST, 'fullname', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $current_email = $_SESSION['user']['email'];
    
    // Validate inputs
    if (!$fullname || !$email) {
        setToastMessage("All fields are required and must be valid!", "error");
    } else {
        $db->executeTransaction(function($dbHelper) use ($fullname, $email, $current_email) {
            // Check if email is already used by another user
            $stmt = $dbHelper->prepare("SELECT user_id FROM barangay_users WHERE email = ? AND email != ?");
            if (!$stmt) return false;
            
            $stmt->bind_param("ss", $email, $current_email);
            if (!$stmt->execute()) {
                $stmt->close();
                return false;
            }
            
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $stmt->close();
                setToastMessage("Email is already in use!", "error");
                return false;
            }
            $stmt->close();
            
            // Update user information
            $updateStmt = $dbHelper->prepare("UPDATE barangay_users SET fullname = ?, email = ?, updated_at = NOW() WHERE email = ?");
            if (!$updateStmt) return false;
            
            $updateStmt->bind_param("sss", $fullname, $email, $current_email);
            $result = $updateStmt->execute();
            $updateStmt->close();
            
            if ($result) {
                // Update session data
                $_SESSION['user']['fullname'] = $fullname;
                $_SESSION['user']['email'] = $email;
            }
            
            return $result;
        }) ? setToastMessage("Profile updated successfully!", "success") : setToastMessage("Failed to update profile", "error");
    }
    
    // Redirect to prevent form resubmission
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'], $_POST['csrf_token'])) {
    // Validate CSRF token
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        setToastMessage("Security verification failed", "error");
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    $email = $_SESSION['user']['email'];
    
    // Validate password inputs
    if (!$current_password || !$new_password || !$confirm_password) {
        setToastMessage("All password fields are required", "error");
    } elseif ($new_password !== $confirm_password) {
        setToastMessage("New passwords do not match!", "error");
    } elseif (strlen($new_password) < 8) {
        setToastMessage("New password must be at least 8 characters long!", "error");
    } elseif (!preg_match('/[A-Z]/', $new_password) || !preg_match('/[a-z]/', $new_password) || !preg_match('/[0-9]/', $new_password)) {
        setToastMessage("Password must include uppercase, lowercase, and numbers", "error");
    } else {
        $db->executeTransaction(function($dbHelper) use ($current_password, $new_password, $email) {
            // Fetch the current hashed password
            $stmt = $dbHelper->prepare("SELECT user_id, password FROM barangay_users WHERE email = ?");
            if (!$stmt) return false;
            
            $stmt->bind_param("s", $email);
            if (!$stmt->execute()) {
                $stmt->close();
                return false;
            }
            
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $stmt->close();
            
            if (!$user) {
                setToastMessage("User not found!", "error");
                return false;
            } elseif (!password_verify($current_password, $user['password'])) {
                setToastMessage("Current password is incorrect!", "error");
                return false;
            }
            
            // Update password
            $new_password_hashed = password_hash($new_password, PASSWORD_DEFAULT);
            $updateStmt = $dbHelper->prepare("UPDATE barangay_users SET password = ?, updated_at = NOW() WHERE email = ?");
            if (!$updateStmt) return false;
            
            $updateStmt->bind_param("ss", $new_password_hashed, $email);
            $result = $updateStmt->execute();
            $updateStmt->close();
            
            // Log password change
            if ($result) {
                $logStmt = $dbHelper->prepare("INSERT INTO activity_log (user_id, action_type, entity_type, entity_id, details) VALUES (?, 'update', 'user', ?, ?)");
                if (!$logStmt) return false;
                
                $user_id = $user['user_id'];
                $details = "Changed password";
                $logStmt->bind_param("iis", $user_id, $user_id, $details);
                $logResult = $logStmt->execute();
                $logStmt->close();
                
                return $logResult;
            }
            
            return $result;
        }) ? setToastMessage("Password changed successfully!", "success") : setToastMessage("Failed to change password", "error");
    }
    
    // Redirect to prevent form resubmission
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// --- Data retrieval functions ---

function fetchHouseholds($db) {
    $households = $db->query("SELECT household_id, household_name, address FROM households ORDER BY household_name");
    return $households ?: [];
}

function fetchFinancialAid($db, $limit = 50) {
    $query = "
        SELECT fa.*, h.household_name 
        FROM financial_aid fa
        JOIN households h ON fa.household_id = h.household_id
        ORDER BY fa.date_released DESC
        LIMIT :limit";
    
    $stmt = $db->prepare($query);
    if (!$stmt) {
        error_log("Prepare failed: " . implode(", ", $db->conn->errorInfo()));
        return [];
    }
    
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    if (!$stmt->execute()) {
        error_log("Execute failed: " . implode(", ", $stmt->errorInfo()));
        return [];
    }
    
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Mimic MySQLi result object for compatibility with dashboard
    $resultObject = new stdClass();
    $resultObject->num_rows = count($result);
    $resultObject->fetch_assoc = function() use (&$result) {
        return array_shift($result);
    };
    
    return $resultObject;
}

function fetchPendingRequests($db) {
    $query = "
        SELECT fa.*, h.household_name, h.address
        FROM financial_aid fa
        JOIN households h ON fa.household_id = h.household_id
        WHERE fa.status = 'pending'
        ORDER BY fa.created_at ASC";
    
    return $db->query($query) ?: [];
}

function fetchSocialPrograms($db) {
    return $db->query("SELECT program_id, program_name FROM social_programs ORDER BY program_name") ?: [];
}

function fetchBudgetAllocations($db, $limit = 50) {
    $query = "
        SELECT ba.*, sp.program_name 
        FROM budget_allocations ba
        JOIN social_programs sp ON ba.program_id = sp.program_id
        ORDER BY ba.created_at DESC, sp.program_name
        LIMIT :limit";
    
    $stmt = $db->prepare($query);
    if (!$stmt) {
        error_log("Prepare failed: " . implode(", ", $db->conn->errorInfo()));
        return [];
    }
    
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    if (!$stmt->execute()) {
        error_log("Execute failed: " . implode(", ", $stmt->errorInfo()));
        return [];
    }
    
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Mimic MySQLi result object for compatibility with dashboard
    $resultObject = new stdClass();
    $resultObject->num_rows = count($result);
    $resultObject->fetch_assoc = function() use (&$result) {
        return array_shift($result);
    };
    
    return $resultObject;
}
function fetchTreasurerDetails($db, $email) {
    try {
        $stmt = $db->prepare("SELECT name FROM barangay_users WHERE email = :email AND role = 'treasurer' LIMIT 1");
        if (!$stmt) {
            error_log("Failed to prepare statement in fetchTreasurerDetails");
            return "Treasurer";
        }
        
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        if (!$stmt->execute()) {
            error_log("Failed to execute statement in fetchTreasurerDetails");
            return "Treasurer";
        }
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $result['name'] : "Treasurer";
    } catch (PDOException $e) {
        error_log("PDO error in fetchTreasurerDetails: " . $e->getMessage());
        return "Treasurer";
    }
}
function fetchFinancialSummary($db) {
    $summary = [
        'total_aid_disbursed' => 0,
        'current_month_aid' => 0,
        'total_households_helped' => 0,
        'pending_request_count' => 0
    ];
    
    // Total aid disbursed
    $result = $db->query("SELECT SUM(amount) as total FROM financial_aid WHERE status = 'distributed'");
    if ($result && $result->num_rows > 0) {
        $summary['total_aid_disbursed'] = $result->fetch_assoc()['total'] ?? 0;
    }
    
    // Current month aid
    $result = $db->query("SELECT SUM(amount) as total FROM financial_aid WHERE status = 'distributed' AND MONTH(distribution_date) = MONTH(CURRENT_DATE()) AND YEAR(distribution_date) = YEAR(CURRENT_DATE())");
    if ($result && $result->num_rows > 0) {
        $summary['current_month_aid'] = $result->fetch_assoc()['total'] ?? 0;
    }
    
    // Total households helped
    $result = $db->query("SELECT COUNT(DISTINCT household_id) as total FROM financial_aid WHERE status = 'distributed'");
    if ($result && $result->num_rows > 0) {
        $summary['total_households_helped'] = $result->fetch_assoc()['total'] ?? 0;
    }
    
    // Pending request count
    $result = $db->query("SELECT COUNT(*) as total FROM financial_aid WHERE status = 'pending'");
    if ($result && $result->num_rows > 0) {
        $summary['pending_request_count'] = $result->fetch_assoc()['total'] ?? 0;
    }
    
    return $summary;
}

function fetchHouseholdProfiles($db) {
    $query = "
        SELECT h.household_id, h.household_name, h.address, h.income_level, h.financial_status, h.last_assessment_date,
        COUNT(fa.id) as aid_count, SUM(CASE WHEN fa.status = 'distributed' THEN fa.amount ELSE 0 END) as total_aid
        FROM households h
        LEFT JOIN financial_aid fa ON h.household_id = fa.household_id
        GROUP BY h.household_id
        ORDER BY h.household_name";
    
    return $db->query($query) ?: [];
}

// --- Helper functions ---

function setToastMessage($message, $type) {
    $_SESSION['toast_message'] = $message;
    $_SESSION['toast_type'] = $type;
}

function validateDate($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

// Fetch data for the dashboard
$treasurer_name = fetchTreasurerDetails($db, $_SESSION['user']['email']);
$households = fetchHouseholds($db);
$financial_aid = fetchFinancialAid($db);
$pending_requests = fetchPendingRequests($db);
$programs = fetchSocialPrograms($db);
$allocations = fetchBudgetAllocations($db);
$summary = fetchFinancialSummary($db);
$household_profiles = fetchHouseholdProfiles($db);

// Extract variables from summary
$total_aid_disbursed = $summary['total_aid_disbursed'];
$current_month_aid = $summary['current_month_aid'];
$total_households_helped = $summary['total_households_helped'];
$pending_request_count = $summary['pending_request_count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Treasurer Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="logo-container">
                <img src="images/ilogos.png" alt="Barangay Logo" class="logo">
                <div class="admin-name"><?php echo htmlspecialchars($treasurer_name); ?></div>
                <div class="admin-role">Barangay Treasurer</div>
            </div>
        </div>
        
        <div class="menu">
            <a href="#dashboard" class="menu-item active" data-section="dashboard">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="#financial-aid" class="menu-item" data-section="financial-aid">
                <i class="fas fa-hand-holding-usd"></i>
                <span>Financial Aid</span>
                <?php if ($pending_request_count > 0): ?>
                <span class="menu-badge"><?php echo $pending_request_count; ?></span>
                <?php endif; ?>
            </a>
            <a href="#budget-allocation" class="menu-item" data-section="budget-allocation">
                <i class="fas fa-money-bill-wave"></i>
                <span>Budget Allocation</span>
            </a>
            <a href="#financial-reports" class="menu-item" data-section="financial-reports">
                <i class="fas fa-chart-line"></i>
                <span>Financial Reports</span>
            </a>
            <a href="#household-profiles" class="menu-item" data-section="household-profiles">
                <i class="fas fa-house-user"></i>
                <span>Household Profiles</span>
            </a>
            <a href="#settings" class="menu-item" data-section="settings">
                <i class="fas fa-cog"></i>
                <span>Settings</span>
            </a>
            <a href="#" id="logoutBtn" class="menu-item">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Toast message -->
        <?php if (!empty($toast_message)): ?>
        <div class="toast-container position-fixed top-0 end-0 p-3">
            <div id="liveToast" class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header bg-<?php echo ($toast_type === 'success') ? 'success' : 'danger'; ?> text-white">
                    <i class="fas fa-<?php echo ($toast_type === 'success') ? 'check-circle' : 'exclamation-circle'; ?> me-2"></i>
                    <strong class="me-auto"><?php echo ($toast_type === 'success') ? 'Success' : 'Error'; ?></strong>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    <?php echo htmlspecialchars($toast_message); ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Dashboard Section -->
        <section id="dashboard" class="content-section active">
            <div class="section-header">
                <h2>Financial Dashboard</h2>
                <p class="text-muted">Overview of financial metrics and activities</p>
            </div>
            
            <div class="row">
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-card-body">
                            <div class="stat-card-icon bg-primary">
                                <i class="fas fa-peso-sign"></i>
                            </div>
                            <div class="stat-card-info">
                                <div class="stat-card-title">Total Aid Disbursed</div>
                                <div class="stat-card-value">₱ <?php echo number_format($total_aid_disbursed, 2); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-card-body">
                            <div class="stat-card-icon bg-success">
                                <i class="fas fa-calendar-check"></i>
                            </div>
                            <div class="stat-card-info">
                                <div class="stat-card-title">Current Month Aid</div>
                                <div class="stat-card-value">₱ <?php echo number_format($current_month_aid, 2); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-card-body">
                            <div class="stat-card-icon bg-info">
                                <i class="fas fa-users"></i>
                            </div>
                            <div class="stat-card-info">
                                <div class="stat-card-title">Households Helped</div>
                                <div class="stat-card-value"><?php echo number_format($total_households_helped); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-card-body">
                            <div class="stat-card-icon bg-warning">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="stat-card-info">
                                <div class="stat-card-title">Pending Requests</div>
                                <div class="stat-card-value"><?php echo number_format($pending_request_count); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row mt-4">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-header">
                <h5 class="card-title">Recent Financial Aid Disbursements</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Household</th>
                                <th>Amount</th>
                                <th>Type</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($financial_aid && $financial_aid->num_rows > 0): ?>
                                <?php foreach ($financial_aid as $row): ?>
                                    <?php if ($row['status'] === 'distributed'): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['household_name']); ?></td>
                                        <td>₱ <?php echo number_format($row['amount'], 2); ?></td>
                                        <td><?php echo htmlspecialchars($row['purpose']); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($row['date_released'])); ?></td>
                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center">No recent disbursements found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-header">
                <h5 class="card-title">Pending Aid Requests</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Household</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($pending_requests && $pending_requests->num_rows > 0): ?>
                                        <?php foreach ($pending_requests as $req): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($req['household_name']); ?></td>
                                    <td><?php echo htmlspecialchars($req['purpose']); ?></td>
                                    <td>₱ <?php echo number_format($req['amount'], 2); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#processRequestModal" 
                                                data-request-id="<?php echo $req['id']; ?>" 
                                                data-household="<?php echo htmlspecialchars($req['household_name']); ?>"
                                                data-amount="<?php echo $req['amount']; ?>"
                                                data-type="<?php echo htmlspecialchars($req['purpose']); ?>">
                                            Process
                                        </button>
                                    </td>
                                </tr>
                                        <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center">No pending requests</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

        <!-- Financial Aid Section -->
        <section id="financial-aid" class="content-section">
            <div class="section-header">
                <h2>Financial Aid Management</h2>
                <p class="text-muted">Record and manage financial assistance to households</p>
            </div>
            
            <div class="row">
                <div class="col-md-5">
                    <div class="card shadow-sm">
                        <div class="card-header">
                            <h5 class="card-title">Record New Financial Aid</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                
                                <div class="mb-3">
                                    <label for="household_id" class="form-label">Beneficiary Household</label>
                                    <select class="form-select" id="household_id" name="household_id" required>
                                        <option value="">Select household...</option>
                                        <?php if ($households && $households->num_rows > 0): ?>
                                            <?php while ($household = $households->fetch_assoc()): ?>
                                                <option value="<?php echo $household['household_id']; ?>"><?php echo htmlspecialchars($household['household_name']); ?> - <?php echo htmlspecialchars($household['address']); ?></option>
                                            <?php endwhile; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="aid_amount" class="form-label">Amount (₱)</label>
                                    <input type="number" class="form-control" id="aid_amount" name="aid_amount" min="0.01" step="0.01" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="aid_type" class="form-label">Aid Type</label>
                                    <select class="form-select" id="aid_type" name="aid_type" required>
                                        <option value="">Select type...</option>
                                        <option value="Cash Assistance">Cash Assistance</option>
                                        <option value="Medical Aid">Medical Aid</option>
                                        <option value="Educational Aid">Educational Aid</option>
                                        <option value="Housing Aid">Housing Aid</option>
                                        <option value="Food Aid">Food Aid</option>
                                        <option value="Emergency Relief">Emergency Relief</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="distribution_date" class="form-label">Distribution Date</label>
                                    <input type="date" class="form-control" id="distribution_date" name="distribution_date" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="aid_notes" class="form-label">Notes</label>
                                    <textarea class="form-control" id="aid_notes" name="aid_notes" rows="3"></textarea>
                                </div>
                                
                                <button type="submit" name="record_aid" class="btn btn-primary">Record Aid</button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-7">
                    <div class="card shadow-sm">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">Financial Aid Records</h5>
                            <div class="input-group search-box">
                                <input type="text" class="_MESSAGE: Your message has been truncated because it exceeds the maximum allowed length of 32768 characters. Please shorten your message and try again.
                                <input type="text" class="form-control" id="aidSearch" placeholder="Search records...">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover" id="aidRecordsTable">
                                    <thead>
                                        <tr>
                                            <th>Household</th>
                                            <th>Amount</th>
                                            <th>Type</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if ($financial_aid && $financial_aid->num_rows > 0): ?>
                                            <?php foreach ($financial_aid as $row): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($row['household_name']); ?></td>
                                                    <td>₱ <?php echo number_format($row['amount'], 2); ?></td>
                                                    <td><?php echo htmlspecialchars($row['aid_type']); ?></td>
                                                    <td><?php echo date('M d, Y', strtotime($row['distribution_date'])); ?></td>
                                                    <td>
                                                        <span class="badge bg-<?php 
                                                            echo $row['status'] === 'distributed' ? 'success' : 
                                                                 ($row['status'] === 'pending' ? 'warning' : 'danger'); ?>">
                                                            <?php echo ucfirst($row['status']); ?>
                                                        </span>
                                                    </td>
                                                </tr>
                                        <?php endforeach; ?>
                                            <tr>
                                                <td colspan="5" class="text-center">No financial aid records found</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Budget Allocation Section -->
        <section id="budget-allocation" class="content-section">
            <div class="section-header">
                <h2>Budget Allocation</h2>
                <p class="text-muted">Allocate funds to social programs</p>
            </div>
            
            <div class="row">
                <div class="col-md-5">
                    <div class="card shadow-sm">
                        <div class="card-header">
                            <h5 class="card-title">Allocate Budget</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                
                                <div class="mb-3">
                                    <label for="program_id" class="form-label">Social Program</label>
                                    <select class="form-select" id="program_id" name="program_id" required>
                                        <option value="">Select program...</option>
                                        <?php if ($programs && $programs->num_rows > 0): ?>
                                            <?php while ($program = $programs->fetch_assoc()): ?>
                                                <option value="<?php echo $program['program_id']; ?>">
                                                    <?php echo htmlspecialchars($program['program_name']); ?>
                                                </option>
                                            <?php endwhile; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="allocation_amount" class="form-label">Amount (₱)</label>
                                    <input type="number" class="form-control" id="allocation_amount" name="allocation_amount" min="0.01" step="0.01" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="allocation_period" class="form-label">Allocation Period</label>
                                    <input type="month" class="form-control" id="allocation_period" name="allocation_period" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="allocation_notes" class="form-label">Notes</label>
                                    <textarea class="form-control" id="allocation_notes" name="allocation_notes" rows="3"></textarea>
                                </div>
                                
                                <button type="submit" name="allocate_budget" class="btn btn-primary">Allocate Budget</button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-7">
                    <div class="card shadow-sm">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">Budget Allocations</h5>
                            <div class="input-group search-box">
                                <input type="text" class="form-control" id="budgetSearch" placeholder="Search allocations...">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover" id="budgetTable">
                                    <thead>
                                        <tr>
                                            <th>Program</th>
                                            <th>Amount</th>
                                            <th>Period</th>
                                            <th>Allocated By</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if ($allocations && $allocations->num_rows > 0): ?>
                                            <?php foreach ($allocations as $alloc): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($alloc['program_name']); ?></td>
                                                    <td>₱ <?php echo number_format($alloc['amount'], 2); ?></td>
                                                    <td><?php echo date('M Y', strtotime($alloc['allocation_period'])); ?></td>
                                                    <td><?php echo htmlspecialchars($alloc['allocated_by'] ?: 'System'); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="4" class="text-center">No budget allocations found</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Financial Reports Section -->
        <section id="financial-reports" class="content-section">
            <div class="section-header">
                <h2>Financial Reports</h2>
                <p class="text-muted">Generate and view financial reports</p>
            </div>
            
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="card-title">Generate Report</h5>
                </div>
                <div class="card-body">
                    <form method="GET" action="generate_report.php">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="report_type" class="form-label">Report Type</label>
                                <select class="form-select" id="report_type" name="report_type" required>
                                    <option value="aid_distribution">Aid Distribution</option>
                                    <option value="budget_allocation">Budget Allocation</option>
                                    <option value="household_summary">Household Summary</option>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="start_date" class="form-label">Start Date</label>
                                <input type="date" class="form-control" id="start_date" name="start_date">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="end_date" class="form-label">End Date</label>
                                <input type="date" class="form-control" id="end_date" name="end_date">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Generate Report</button>
                    </form>
                </div>
            </div>
        </section>

        <!-- Household Profiles Section -->
        <section id="household-profiles" class="content-section">
            <div class="section-header">
                <h2>Household Profiles</h2>
                <p class="text-muted">Manage household financial profiles</p>
            </div>
            
            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Household Financial Profiles</h5>
                    <div class="input-group search-box">
                        <input type="text" class="form-control" id="householdSearch" placeholder="Search households...">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover" id="householdTable">
                            <thead>
                                <tr>
                                    <th>Household</th>
                                    <th>Address</th>
                                    <th>Income Level</th>
                                    <th>Financial Status</th>
                                    <th>Total Aid</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($household_profiles && $household_profiles->num_rows > 0): ?>
                                    <?php while ($profile = $household_profiles->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($profile['household_name']); ?></td>
                                            <td><?php echo htmlspecialchars($profile['address']); ?></td>
                                            <td>₱ <?php echo number_format($profile['income_level'], 2); ?></td>
                                            <td><?php echo htmlspecialchars($profile['financial_status']); ?></td>
                                            <td>₱ <?php echo number_format($profile['total_aid'], 2); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#updateHouseholdModal"
                                                        data-household-id="<?php echo $profile['household_id']; ?>"
                                                        data-household-name="<?php echo htmlspecialchars($profile['household_name']); ?>"
                                                        data-income-level="<?php echo $profile['income_level']; ?>"
                                                        data-financial-status="<?php echo htmlspecialchars($profile['financial_status']); ?>">
                                                    Update
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center">No household profiles found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>

        <!-- Settings Section -->
        <section id="settings" class="content-section">
            <div class="section-header">
                <h2>Settings</h2>
                <p class="text-muted">Manage your account settings</p>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="card-header">
                            <h5 class="card-title">Update Profile</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                
                                <div class="mb-3">
                                    <label for="fullname" class="form-label">Full Name</label>
                                    <input type="text" class="form-control" id="fullname" name="fullname" value="<?php echo htmlspecialchars($_SESSION['user']['fullname']); ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($_SESSION['user']['email']); ?>" required>
                                </div>
                                
                                <button type="submit" name="update_profile" class="btn btn-primary">Update Profile</button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="card-header">
                            <h5 class="card-title">Change Password</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                
                                <div class="mb-3">
                                    <label for="current_password" class="form-label">Current Password</label>
                                    <input type="password" class="form-control" id="current_password" name="current_password" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="new_password" class="form-label">New Password</label>
                                    <input type="password" class="form-control" id="new_password" name="new_password" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="confirm_password" class="form-label">Confirm New Password</label>
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                </div>
                                
                                <button type="submit" name="change_password" class="btn btn-primary">Change Password</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Modals -->
    <!-- Process Request Modal -->
    <div class="modal fade" id="processRequestModal" tabindex="-1" aria-labelledby="processRequestModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="processRequestModalLabel">Process Aid Request</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <input type="hidden" name="request_id" id="request_id">
                        
                        <div class="mb-3">
                            <label class="form-label">Household</label>
                            <input type="text" class="form-control" id="modal_household" readonly>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Aid Type</label>
                            <input type="text" class="form-control" id="modal_type" readonly>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Amount</label>
                            <input type="text" class="form-control" id="modal_amount" readonly>
                        </div>
                        
                        <div class="mb-3">
                            <label for="status" class="form-label">Action</label>
                            <select class="form-select" id="status" name="status" required>
                                <option value="distributed">Approve</option>
                                <option value="denied">Deny</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="remarks" class="form-label">Remarks</label>
                            <textarea class="form-control" id="remarks" name="remarks" rows="3" required></textarea>
                        </div>
                        
                        <button type="submit" name="process_request" class="btn btn-primary">Process Request</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Update Household Modal -->
    <div class="modal fade" id="updateHouseholdModal" tabindex="-1" aria-labelledby="updateHouseholdModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateHouseholdModalLabel">Update Household Profile</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <input type="hidden" name="household_id" id="household_id">
                        
                        <div class="mb-3">
                            <label class="form-label">Household Name</label>
                            <input type="text" class="form-control" id="modal_household_name" readonly>
                        </div>
                        
                        <div class="mb-3">
                            <label for="income_level" class="form-label">Income Level (₱)</label>
                            <input type="number" class="form-control" id="income_level" name="income_level" min="0" step="0.01" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="financial_status" class="form-label">Financial Status</label>
                            <select class="form-select" id="financial_status" name="financial_status" required>
                                <option value="Low Income">Low Income</option>
                                <option value="Middle Income">Middle Income</option>
                                <option value="High Income">High Income</option>
                            </select>
                        </div>
                        
                        <button type="submit" name="update_household" class="btn btn-primary">Update Profile</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script>
        // Sidebar navigation
        document.querySelectorAll('.menu-item').forEach(item => {
            item.addEventListener('click', function(e) {
                if (this.id === 'logoutBtn') {
                    e.preventDefault();
                    if (confirm('Are you sure you want to logout?')) {
                        window.location.href = 'logout.php';
                    }
                    return;
                }
                
                e.preventDefault();
                document.querySelectorAll('.menu-item').forEach(i => i.classList.remove('active'));
                this.classList.add('active');
                
                const section = this.getAttribute('data-section');
                document.querySelectorAll('.content-section').forEach(s => s.classList.remove('active'));
                document.getElementById(section).classList.add('active');
            });
        });

        // Process Request Modal
        document.querySelectorAll('[data-bs-target="#processRequestModal"]').forEach(btn => {
            btn.addEventListener('click', function() {
                document.getElementById('request_id').value = this.dataset.requestId;
                document.getElementById('modal_household').value = this.dataset.household;
                document.getElementById('modal_amount').value = '₱ ' + parseFloat(this.dataset.amount).toFixed(2);
                document.getElementById('modal_type').value = this.dataset.type;
            });
        });

        // Update Household Modal
        document.querySelectorAll('[data-bs-target="#updateHouseholdModal"]').forEach(btn => {
            btn.addEventListener('click', function() {
                document.getElementById('household_id').value = this.dataset.householdId;
                document.getElementById('modal_household_name').value = this.dataset.householdName;
                document.getElementById('income_level').value = this.dataset.incomeLevel;
                document.getElementById('financial_status').value = this.dataset.financialStatus;
            });
        });

        // Table search functionality
        function filterTable(inputId, tableId) {
            const input = document.getElementById(inputId);
            const table = document.getElementById(tableId);
            input.addEventListener('input', function() {
                const filter = this.value.toLowerCase();
                const rows = table.querySelectorAll('tbody tr');
                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(filter) ? '' : 'none';
                });
            });
        }

        filterTable('aidSearch', 'aidRecordsTable');
        filterTable('budgetSearch', 'budgetTable');
        filterTable('householdSearch', 'householdTable');

        // Auto-hide toast after 5 seconds
        const toast = document.getElementById('liveToast');
        if (toast) {
            setTimeout(() => {
                const bsToast = bootstrap.Toast.getInstance(toast);
                if (bsToast) bsToast.hide();
            }, 5000);
        }
    </script>
</body>
</html>
<?php
// Close database connection
$db->close();
?>
