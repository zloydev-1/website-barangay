<?php
session_start();

// Check if user is logged in and is an admin
if (!isset($_SESSION['user']) || !isset($_SESSION['user']['role']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: php/login.php');
    exit;
}

// Generate CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Set active tab
if (isset($_POST['active_tab'])) {
    $_SESSION['active_tab'] = $_POST['active_tab'];
}
$active_tab = $_SESSION['active_tab'] ?? 'dashboard';

require 'php/config.php';

// Ensure $conn is a valid PDO instance
if (!$conn instanceof PDO) {
    die('Database connection is not properly configured.');
}

// Ensure session user data has defaults
$_SESSION['user'] = array_merge([
    'id' => 1,
    'first_name' => 'Admin',
    'last_name' => '',
    'email' => '',
    'role' => 'admin'
], $_SESSION['user']);

// Helper function to validate CSRF token
function validate_csrf_token($token) {
    if (!isset($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token']) || !is_string($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

// Handle profile update
if (isset($_POST['update_user']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $first_name = trim($_POST['first_name']);
        $last_name = trim($_POST['last_name']);
        $email = trim($_POST['email']);
        $current_email = $_SESSION['user']['email'];

        if (empty($first_name) || empty($last_name) || empty($email)) {
            $_SESSION['toast_message'] = 'All fields are required!';
            $_SESSION['toast_type'] = 'error';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['toast_message'] = 'Invalid email format!';
            $_SESSION['toast_type'] = 'error';
        } else {
            try {
                $stmt = $conn->prepare("SELECT id FROM barangay_users WHERE email = ? AND email != ?");
                $stmt->execute([$email, $current_email]);
                if ($stmt->fetch()) {
                    $_SESSION['toast_message'] = 'Email is already in use!';
                    $_SESSION['toast_type'] = 'error';
                } else {
                    $stmt = $conn->prepare("UPDATE barangay_users SET first_name = ?, last_name = ?, email = ? WHERE email = ?");
                    $stmt->execute([$first_name, $last_name, $email, $current_email]);
                    $_SESSION['user']['email'] = $email;
                    $_SESSION['user']['first_name'] = $first_name;
                    $_SESSION['user']['last_name'] = $last_name;
                    $_SESSION['toast_message'] = 'Profile updated successfully!';
                    $_SESSION['toast_type'] = 'success';
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                }
            } catch (PDOException $e) {
                $_SESSION['toast_message'] = 'Error updating profile: ' . $e->getMessage();
                $_SESSION['toast_type'] = 'error';
            }
        }
    } else {
        $_SESSION['toast_message'] = 'Invalid CSRF token.';
        $_SESSION['toast_type'] = 'error';
    }
}

// Handle password change
if (isset($_POST['change_password']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        $email = $_SESSION['user']['email'];

        try {
            $stmt = $conn->prepare("SELECT password FROM barangay_users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                $_SESSION['toast_message'] = 'User not found!';
                $_SESSION['toast_type'] = 'error';
            } elseif (!password_verify($current_password, $user['password'])) {
                $_SESSION['toast_message'] = 'Current password is incorrect!';
                $_SESSION['toast_type'] = 'error';
            } elseif ($new_password !== $confirm_password) {
                $_SESSION['toast_message'] = 'New passwords do not match!';
                $_SESSION['toast_type'] = 'error';
            } elseif (strlen($new_password) < 8) {
                $_SESSION['toast_message'] = 'New password must be at least 8 characters long!';
                $_SESSION['toast_type'] = 'error';
            } else {
                $new_password_hashed = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE barangay_users SET password = ? WHERE email = ?");
                $stmt->execute([$new_password_hashed, $email]);
                $_SESSION['toast_message'] = 'Password changed successfully!';
                $_SESSION['toast_type'] = 'success';
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            }
        } catch (PDOException $e) {
            $_SESSION['toast_message'] = 'Error changing password: ' . $e->getMessage();
            $_SESSION['toast_type'] = 'error';
        }
    } else {
        $_SESSION['toast_message'] = 'Invalid CSRF token.';
        $_SESSION['toast_type'] = 'error';
    }
}

// Handle user status changes
if (isset($_POST['approve_user']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $user_id = $_POST['user_id'];
        $action = $_POST['action'];
        $role = $_POST['role'] ?? 'resident';
        $status = ($action == 'approve') ? 1 : 2;

        try {
            $stmt = $conn->prepare("UPDATE barangay_users SET is_approved = ?, role = ? WHERE id = ?");
            $stmt->execute([$status, $role, $user_id]);
            $_SESSION['toast_message'] = ($action == 'approve') ? 'User approved successfully!' : 'User rejected successfully!';
            $_SESSION['toast_type'] = 'success';
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } catch (PDOException $e) {
            $_SESSION['toast_message'] = 'Error updating user status: ' . $e->getMessage();
            $_SESSION['toast_type'] = 'error';
        }
    } else {
        $_SESSION['toast_message'] = 'Invalid CSRF token.';
        $_SESSION['toast_type'] = 'error';
    }
}

// Handle user role updates
if (isset($_POST['update_role']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $user_id = $_POST['user_id'];
        $role = $_POST['role'];

        try {
            $stmt = $conn->prepare("UPDATE barangay_users SET role = ? WHERE id = ?");
            $stmt->execute([$role, $user_id]);
            $_SESSION['toast_message'] = 'User role updated successfully!';
            $_SESSION['toast_type'] = 'success';
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } catch (PDOException $e) {
            $_SESSION['toast_message'] = 'Error updating role: ' . $e->getMessage();
            $_SESSION['toast_type'] = 'error';
        }
    } else {
        $_SESSION['toast_message'] = 'Invalid CSRF token.';
        $_SESSION['toast_type'] = 'error';
    }
}

// Handle user deletion
if (isset($_POST['delete_user']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $user_id = $_POST['user_id'];

        if ($user_id != $_SESSION['user']['id']) {
            try {
                $stmt = $conn->prepare("DELETE FROM barangay_users WHERE id = ?");
                $stmt->execute([$user_id]);
                $_SESSION['toast_message'] = 'User deleted successfully!';
                $_SESSION['toast_type'] = 'success';
            } catch (PDOException $e) {
                $_SESSION['toast_message'] = 'Error deleting user: ' . $e->getMessage();
                $_SESSION['toast_type'] = 'error';
            }
        } else {
            $_SESSION['toast_message'] = 'You cannot delete your own account!';
            $_SESSION['toast_type'] = 'error';
        }
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $_SESSION['toast_message'] = 'Invalid CSRF token.';
        $_SESSION['toast_type'] = 'error';
    }
}

// Handle add new user
if (isset($_POST['add_user']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $first_name = trim($_POST['new_first_name']);
        $last_name = trim($_POST['new_last_name']);
        $email = trim($_POST['new_email']);
        $phone = trim($_POST['new_phone']);
        $purok = trim($_POST['new_purok']);
        $role = $_POST['new_role'];
        $password = $_POST['new_password'];
        $address = trim($_POST['new_address']);
        $username = strtolower($first_name . '.' . $last_name);

        if (empty($first_name) || empty($last_name) || empty($email) || empty($password)) {
            $_SESSION['toast_message'] = 'All required fields must be filled!';
            $_SESSION['toast_type'] = 'error';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['toast_message'] = 'Invalid email format!';
            $_SESSION['toast_type'] = 'error';
        } elseif (strlen($password) < 8) {
            $_SESSION['toast_message'] = 'Password must be at least 8 characters long!';
            $_SESSION['toast_type'] = 'error';
        } else {
            try {
                $stmt = $conn->prepare("SELECT id FROM barangay_users WHERE email = ? OR username = ?");
                $stmt->execute([$email, $username]);
                if ($stmt->fetch()) {
                    $_SESSION['toast_message'] = 'Email or username already exists!';
                    $_SESSION['toast_type'] = 'error';
                } else {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("INSERT INTO barangay_users (first_name, last_name, email, username, password, phone, purok, address, role, is_approved) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
                    $stmt->execute([$first_name, $last_name, $email, $username, $hashed_password, $phone, $purok, $address, $role]);
                    $_SESSION['toast_message'] = 'User added successfully!';
                    $_SESSION['toast_type'] = 'success';
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                }
            } catch (PDOException $e) {
                $_SESSION['toast_message'] = 'Error adding user: ' . $e->getMessage();
                $_SESSION['toast_type'] = 'error';
            }
        }
    } else {
        $_SESSION['toast_message'] = 'Invalid CSRF token.';
        $_SESSION['toast_type'] = 'error';
    }
}

// Handle edit user
if (isset($_POST['edit_user']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $user_id = $_POST['user_id'];
        $first_name = trim($_POST['edit_first_name']);
        $last_name = trim($_POST['edit_last_name']);
        $email = trim($_POST['edit_email']);
        $role = $_POST['edit_role'];

        if (empty($first_name) || empty($last_name) || empty($email)) {
            $_SESSION['toast_message'] = 'All fields are required!';
            $_SESSION['toast_type'] = 'error';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['toast_message'] = 'Invalid email format!';
            $_SESSION['toast_type'] = 'error';
        } else {
            try {
                $stmt = $conn->prepare("SELECT id FROM barangay_users WHERE email = ? AND id != ?");
                $stmt->execute([$email, $user_id]);
                if ($stmt->fetch()) {
                    $_SESSION['toast_message'] = 'Email is already in use!';
                    $_SESSION['toast_type'] = 'error';
                } else {
                    $stmt = $conn->prepare("UPDATE barangay_users SET first_name = ?, last_name = ?, email = ?, role = ? WHERE id = ?");
                    $stmt->execute([$first_name, $last_name, $email, $role, $user_id]);
                    $_SESSION['toast_message'] = 'User updated successfully!';
                    $_SESSION['toast_type'] = 'success';
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                }
            } catch (PDOException $e) {
                $_SESSION['toast_message'] = 'Error updating user: ' . $e->getMessage();
                $_SESSION['toast_type'] = 'error';
            }
        }
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $_SESSION['toast_message'] = 'Invalid CSRF token.';
        $_SESSION['toast_type'] = 'error';
    }
}

// Handle announcement creation
if (isset($_POST['create_announcement']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $title = trim($_POST['announcement_title']);
        $content = trim($_POST['announcement_content']);
        $created_by = $_SESSION['user']['id'];

        if (empty($title) || empty($content)) {
            $_SESSION['toast_message'] = 'Title and content are required!';
            $_SESSION['toast_type'] = 'error';
        } else {
            try {
                $stmt = $conn->prepare("INSERT INTO announcements (title, content, created_by) VALUES (?, ?, ?)");
                $stmt->execute([$title, $content, $created_by]);
                $_SESSION['toast_message'] = 'Announcement created successfully!';
                $_SESSION['toast_type'] = 'success';
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            } catch (PDOException $e) {
                $_SESSION['toast_message'] = 'Error creating announcement: ' . $e->getMessage();
                $_SESSION['toast_type'] = 'error';
            }
        }
    } else {
        $_SESSION['toast_message'] = 'Invalid CSRF token.';
        $_SESSION['toast_type'] = 'error';
    }
}

// Handle barangay settings update
if (isset($_POST['update_settings']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $barangay_name = trim($_POST['barangay_name']);
        $barangay_address = trim($_POST['barangay_address']);
        $barangay_contact = trim($_POST['barangay_contact']);
        
        if (empty($barangay_name) || empty($barangay_address)) {
            $_SESSION['toast_message'] = 'Barangay name and address are required!';
            $_SESSION['toast_type'] = 'error';
        } else {
            try {
                $stmt = $conn->prepare("SELECT COUNT(*) FROM barangay_settings");
                $stmt->execute();
                $count = $stmt->fetchColumn();
                
                if ($count > 0) {
                    $stmt = $conn->prepare("UPDATE barangay_settings SET barangay_name = ?, barangay_address = ?, barangay_contact = ?");
                    $stmt->execute([$barangay_name, $barangay_address, $barangay_contact]);
                } else {
                    $stmt = $conn->prepare("INSERT INTO barangay_settings (barangay_name, barangay_address, barangay_contact) VALUES (?, ?, ?)");
                    $stmt->execute([$barangay_name, $barangay_address, $barangay_contact]);
                }
                
                $_SESSION['toast_message'] = 'Settings updated successfully!';
                $_SESSION['toast_type'] = 'success';
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            } catch (PDOException $e) {
                $_SESSION['toast_message'] = 'Error updating settings: ' . $e->getMessage();
                $_SESSION['toast_type'] = 'error';
            }
        }
    } else {
        $_SESSION['toast_message'] = 'Invalid CSRF token.';
        $_SESSION['toast_type'] = 'error';
    }
}

// Handle certificate creation
if (isset($_POST['create_certificate']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $user_id = $_POST['user_id'];
        $certificate_type = trim($_POST['certificate_type']);
        $status = 'pending';
        $created_by = $_SESSION['user']['id'];

        if (empty($user_id) || empty($certificate_type)) {
            $_SESSION['toast_message'] = 'User and certificate type are required!';
            $_SESSION['toast_type'] = 'error';
        } else {
            try {
                $stmt = $conn->prepare("INSERT INTO certificate_requests (user_id, certificate_type, status, created_by) VALUES (?, ?, ?, ?)");
                $stmt->execute([$user_id, $certificate_type, $status, $created_by]);
                $_SESSION['toast_message'] = 'Certificate request created successfully!';
                $_SESSION['toast_type'] = 'success';
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            } catch (PDOException $e) {
                $_SESSION['toast_message'] = 'Error creating certificate request: ' . $e->getMessage();
                $_SESSION['toast_type'] = 'error';
            }
        }
        header('Location: ' . $_SERVER['PHP_SELF'] . '#manage-certificates');
        exit;
    } else {
        $_SESSION['toast_message'] = 'Invalid CSRF token.';
        $_SESSION['toast_type'] = 'error';
    }
}

// Handle certificate request processing
if (isset($_POST['process_request']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $request_id = $_POST['request_id'];
        $action = $_POST['action'];
        $status = ($action == 'approve') ? 'approved' : 'rejected';

        try {
            $stmt = $conn->prepare("UPDATE certificate_requests SET status = ? WHERE id = ?");
            $stmt->execute([$status, $request_id]);
            $_SESSION['toast_message'] = "Certificate request " . $status . " successfully!";
            $_SESSION['toast_type'] = 'success';
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        } catch (PDOException $e) {
            $_SESSION['toast_message'] = 'Error processing certificate request: ' . $e->getMessage();
            $_SESSION['toast_type'] = 'error';
        }
        header('Location: ' . $_SERVER['PHP_SELF'] . '#manage-certificates');
        exit;
    } else {
        $_SESSION['toast_message'] = 'Invalid CSRF token.';
        $_SESSION['toast_type'] = 'error';
    }
}

// Fetch dashboard stats
try {
    $stmt = $conn->prepare("SELECT 
        (SELECT COUNT(*) FROM barangay_users WHERE is_approved = 0) as pending_count,
        (SELECT COUNT(*) FROM barangay_users WHERE role = 'admin') as admin_count,
        (SELECT COUNT(*) FROM barangay_users WHERE role = 'treasurer') as treasurer_count,
        (SELECT COUNT(*) FROM barangay_users WHERE role = 'secretary') as secretary_count,
        (SELECT COUNT(*) FROM barangay_users WHERE is_approved = 1) as active_count");
    $stmt->execute();
    $stats = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['pending_count' => 0, 'admin_count' => 0, 'treasurer_count' => 0, 'secretary_count' => 0, 'active_count' => 0];
} catch (PDOException $e) {
    $stats = ['pending_count' => 0, 'admin_count' => 0, 'treasurer_count' => 0, 'secretary_count' => 0, 'active_count' => 0];
    $_SESSION['toast_message'] = 'Error fetching stats: ' . $e->getMessage();
    $_SESSION['toast_type'] = 'error';
}

// Fetch pending users
try {
    $stmt = $conn->prepare("SELECT id, first_name, last_name, email, username, role, is_approved, created_at, phone, purok 
                            FROM barangay_users 
                            WHERE is_approved = 0 
                            ORDER BY created_at DESC");
    $stmt->execute();
    $pending_users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $pending_users = [];
    $_SESSION['toast_message'] = 'Error fetching pending users: ' . $e->getMessage();
    $_SESSION['toast_type'] = 'error';
}

// Fetch all users
try {
    $stmt = $conn->prepare("SELECT id, first_name, last_name, email, username, role, is_approved, created_at 
                            FROM barangay_users 
                            ORDER BY created_at DESC");
    $stmt->execute();
    $all_users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $all_users = [];
    $_SESSION['toast_message'] = 'Error fetching users: ' . $e->getMessage();
    $_SESSION['toast_type'] = 'error';
}

// Fetch certificate stats
try {
    $stmt = $conn->prepare("SELECT 
        (SELECT COUNT(*) FROM certificate_requests WHERE status = 'pending') as pending_certs,
        (SELECT COUNT(*) FROM certificate_requests WHERE status = 'approved') as approved_certs,
        (SELECT COUNT(*) FROM certificate_requests WHERE status = 'rejected') as rejected_certs");
    $stmt->execute();
    $cert_stats = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['pending_certs' => 0, 'approved_certs' => 0, 'rejected_certs' => 0];
} catch (PDOException $e) {
    $cert_stats = ['pending_certs' => 0, 'approved_certs' => 0, 'rejected_certs' => 0];
    $_SESSION['toast_message'] = 'Error fetching certificate stats: ' . $e->getMessage();
    $_SESSION['toast_type'] = 'error';
}

// Fetch barangay settings
try {
    $stmt = $conn->prepare("SELECT * FROM barangay_settings LIMIT 1");
    $stmt->execute();
    $barangay_settings = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    $barangay_settings = array_merge([
        'barangay_name' => 'Your Barangay Name',
        'barangay_address' => 'Your Barangay Address',
        'barangay_contact' => 'Your Contact Number'
    ], $barangay_settings);
} catch (PDOException $e) {
    $barangay_settings = [
        'barangay_name' => 'Your Barangay Name',
        'barangay_address' => 'Your Barangay Address',
        'barangay_contact' => 'Your Contact Number'
    ];
    $_SESSION['toast_message'] = 'Error fetching settings: ' . $e->getMessage();
    $_SESSION['toast_type'] = 'error';
}

// Fetch announcements
try {
    $stmt = $conn->prepare("SELECT title, content, created_at FROM announcements WHERE is_active = 1 ORDER BY created_at DESC");
    $stmt->execute();
    $announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $announcements = [];
    $_SESSION['toast_message'] = 'Error fetching announcements: ' . $e->getMessage();
    $_SESSION['toast_type'] = 'error';
}

// Get admin's first name for display
$admin_name = $_SESSION['user']['first_name'];

// Toast message handling
$toast_message = $_SESSION['toast_message'] ?? '';
$toast_type = $_SESSION['toast_type'] ?? '';
unset($_SESSION['toast_message'], $_SESSION['toast_type']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Barangay Admin Dashboard | <?php echo htmlspecialchars($barangay_settings['barangay_name']); ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/treasurer.css">
</head>
<body>
    <!-- Mobile Toggle Button -->
    <div class="mobile-toggle" aria-label="Toggle sidebar">
        <i class="fas fa-bars"></i> Menu
    </div>

    <!-- Sidebar -->
    <div class="sidebar" role="navigation">
        <div class="sidebar-header">
            <div class="logo-container">
                <img src="images/1.png" alt="Barangay Logo" class="logo">
                <div class="admin-name"><?php echo htmlspecialchars($admin_name); ?></div>
                <div class="admin-role">Barangay Admin</div>
            </div>
        </div>
        
        <div class="menu">
            <div class="menu-category">DASHBOARD</div>
            <a href="#" class="menu-item <?php echo $active_tab === 'dashboard' ? 'active' : ''; ?>" data-target="dashboard">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            
            <div class="menu-category">ADMINISTRATION</div>
            <a href="#" class="menu-item <?php echo $active_tab === 'pending' ? 'active' : ''; ?>" data-target="pending">
                <i class="fas fa-user-clock"></i>
                <span>Pending Approvals</span>
                <?php if ($stats['pending_count'] > 0): ?>
                <span class="menu-badge"><?php echo $stats['pending_count']; ?></span>
                <?php endif; ?>
            </a>
            <a href="#" class="menu-item <?php echo $active_tab === 'manage-certificates' ? 'active' : ''; ?>" data-target="manage-certificates">
                <i class="fas fa-certificate"></i>
                <span>Manage Certificates</span>
                <?php if ($cert_stats['pending_certs'] > 0): ?>
                <span class="menu-badge"><?php echo $cert_stats['pending_certs']; ?></span>
                <?php endif; ?>
            </a>
            <a href="#" class="menu-item <?php echo $active_tab === 'users' ? 'active' : ''; ?>" data-target="users">
                <i class="fas fa-user-shield"></i>
                <span>User Management</span>
            </a>
            <a href="#" class="menu-item <?php echo $active_tab === 'announcements' ? 'active' : ''; ?>" data-target="announcements">
                <i class="fas fa-bullhorn"></i>
                <span>Announcements</span>
            </a>
            <a href="#" class="menu-item <?php echo $active_tab === 'settings' ? 'active' : ''; ?>" data-target="settings">
                <i class="fas fa-cog"></i>
                <span>Settings</span>
            </a>
            
            <div class="menu-category">ACCOUNT</div>
            <a href="#" class="menu-item <?php echo $active_tab === 'profile' ? 'active' : ''; ?>" data-target="profile">
                <i class="fas fa-user-circle"></i>
                <span>Profile</span>
            </a>
            <a href="php/logout.php" class="menu-item" id="logoutBtn">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content" role="main">
        <!-- Dashboard Header -->
        <div class="dashboard-header">
            <div class="dashboard-header-left">
                <h1 class="page-title">
                    <i class="fas fa-tachometer-alt"></i>
                    Barangay Admin Dashboard
                </h1>
                <div class="dashboard-header-subtitle">
                    Welcome back, <?php echo htmlspecialchars($admin_name); ?>! Today is <?php echo date('F j, Y'); ?>
                </div>
            </div>
            <a href="php/logout.php" class="logout-btn" id="headerLogout" aria-label="Logout">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </div>

        <!-- Tab Container -->
        <div class="tab-container">
            <!-- Tab Navigation -->
            <div class="tab-nav">
                <div class="tab-nav-item <?php echo $active_tab === 'dashboard' ? 'active' : ''; ?>" data-target="dashboard">Overview</div>
                <div class="tab-nav-item <?php echo $active_tab === 'pending' ? 'active' : ''; ?>" data-target="pending">Pending Approvals</div>
                <div class="tab-nav-item <?php echo $active_tab === 'manage-certificates' ? 'active' : ''; ?>" data-target="manage-certificates">Manage Certificates</div>
                <div class="tab-nav-item <?php echo $active_tab === 'users' ? 'active' : ''; ?>" data-target="users">User Management</div>
                <div class="tab-nav-item <?php echo $active_tab === 'announcements' ? 'active' : ''; ?>" data-target="announcements">Announcements</div>
                <div class="tab-nav-item <?php echo $active_tab === 'settings' ? 'active' : ''; ?>" data-target="settings">Settings</div>
                <div class="tab-nav-item <?php echo $active_tab === 'profile' ? 'active' : ''; ?>" data-target="profile">Profile</div>
            </div>

            <!-- Dashboard Tab -->
            <div id="dashboard" class="tab-content <?php echo $active_tab === 'dashboard' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-tachometer-alt"></i>
                            Dashboard Overview
                        </h2>
                    </div>
                    <div class="card-body">
                        <!-- Stats Cards -->
                        <div class="stats-container">
                            <div class="stat-card">
                                <i class="fas fa-users stat-icon"></i>
                                <div class="stat-value"><?php echo $stats['active_count']; ?></div>
                                <div class="stat-label">TOTAL USERS</div>
                            </div>
                            <div class="stat-card">
                                <i class="fas fa-user-clock stat-icon"></i>
                                <div class="stat-value"><?php echo $stats['pending_count']; ?></div>
                                <div class="stat-label">PENDING USERS</div>
                            </div>
                            <div class="stat-card">
                                <i class="fas fa-certificate stat-icon"></i>
                                <div class="stat-value"><?php echo $cert_stats['pending_certs']; ?></div>
                                <div class="stat-label">CERTIFICATE REQUESTS</div>
                            </div>
                            <div class="stat-card">
                                <i class="fas fa-user-shield stat-icon"></i>
                                <div class="stat-value"><?php echo ($stats['admin_count'] + $stats['treasurer_count'] + $stats['secretary_count']); ?></div>
                                <div class="stat-label">STAFF MEMBERS</div>
                            </div>
                        </div>
                        <!-- Charts -->
                        <h3 style="margin-top: 15px; color: var(--primary);">User Statistics</h3>
                        <div class="chart-container">
                            <canvas id="userStatsChart"></canvas>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-history"></i>
                            Recent Activities
                        </h2>
                        <button class="btn btn-primary btn-sm" data-target="manage-certificates">
                            <i class="fas fa-list"></i> View All
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" aria-describedby="Recent Activities">
                                <thead>
                                    <tr>
                                        <th scope="col">User</th>
                                        <th scope="col">Activity</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    try {
                                        $stmt = $conn->prepare("SELECT bu.first_name, bu.last_name, cr.certificate_type, cr.status, cr.created_at 
                                                                FROM certificate_requests cr 
                                                                JOIN barangay_users bu ON cr.user_id = bu.id 
                                                                ORDER BY cr.created_at DESC LIMIT 5");
                                        $stmt->execute();
                                        $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                    } catch (PDOException $e) {
                                        $activities = [];
                                        $_SESSION['toast_message'] = 'Error fetching activities: ' . $e->getMessage();
                                        $_SESSION['toast_type'] = 'error';
                                    }
                                    if (empty($activities)):
                                    ?>
                                    <tr>
                                        <td colspan="4">No recent activities.</td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($activities as $activity): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($activity['first_name'] . ' ' . $activity['last_name']); ?></td>
                                        <td>Requested <?php echo ucfirst(htmlspecialchars($activity['certificate_type'])); ?> Certificate</td>
                                        <td><?php echo date('M d, Y, g:i A', strtotime($activity['created_at'])); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo $activity['status'] == 'pending' ? 'warning' : ($activity['status'] == 'approved' ? 'success' : 'danger'); ?>">
                                                <?php echo ucfirst(htmlspecialchars($activity['status'])); ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pending Approvals Tab -->
            <div id="pending" class="tab-content <?php echo $active_tab === 'pending' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-user-clock"></i>
                            Pending User Approvals
                        </h2>
                    </div>
                    <div class="card-body">
                        <?php if (count($pending_users) === 0): ?>
                        <p>No pending user approvals at the moment.</p>
                        <?php else: ?>
                        <div class="table-responsive">
                            <table class="table" aria-describedby="Pending User Approvals">
                                <thead>
                                    <tr>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Phone</th>
                                        <th scope="col">Purok</th>
                                        <th scope="col">Date Registered</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($pending_users as $user): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td><?php echo htmlspecialchars($user['phone'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($user['purok'] ?? 'N/A'); ?></td>
                                        <td><?php echo date('M d, Y g:i A', strtotime($user['created_at'])); ?></td>
                                        <td>
                                            <form method="POST" action="">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                <div class="form-row">
                                                    <div class="form-group" style="margin-right: 10px;">
                                                        <select name="role" class="form-control-full" required>
                                                            <option value="resident">Resident</option>
                                                            <option value="secretary">Secretary</option>
                                                            <option value="treasurer">Treasurer</option>
                                                            <option value="admin">Admin</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <input type="hidden" name="action" value="approve">
                                                        <button type="submit" name="approve_user" class="btn btn-primary btn-sm">
                                                            <i class="fas fa-check"></i> Approve
                                                        </button>
                                                        <input type="hidden" name="action" value="reject" id="rejectAction_<?php echo $user['id']; ?>">
                                                        <button type="submit" name="approve_user" class="btn btn-secondary btn-sm" onclick="document.getElementById('rejectAction_<?php echo $user['id']; ?>').value='reject';">
                                                            <i class="fas fa-times"></i> Reject
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Manage Certificates Tab -->
            <div id="manage-certificates" class="tab-content <?php echo $active_tab === 'manage-certificates' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-certificate"></i>
                            Create Certificate Request
                        </h2>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="user_id">Select User</label>
                                    <select class="form-control-full" id="user_id" name="user_id" required>
                                        <option value="">Select a user</option>
                                        <?php
                                        try {
                                            $stmt = $conn->prepare("SELECT id, first_name, last_name FROM barangay_users WHERE is_approved = 1 ORDER BY first_name");
                                            $stmt->execute();
                                            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                            foreach ($users as $user):
                                        ?>
                                        <option value="<?php echo $user['id']; ?>">
                                            <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>
                                        </option>
                                        <?php endforeach; ?>
                                        <?php } catch (PDOException $e) {
                                            echo '<option value="">Error loading users</option>';
                                            $_SESSION['toast_message'] = 'Error fetching users: ' . $e->getMessage();
                                            $_SESSION['toast_type'] = 'error';
                                        } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="certificate_type">Certificate Type</label>
                                    <select class="form-control-full" id="certificate_type" name="certificate_type" required>
                                        <option value="">Select certificate type</option>
                                        <option value="residency">Certificate of Residency</option>
                                        <option value="indigency">Certificate of Indigency</option>
                                        <option value="clearance">Barangay Clearance</option>
                                    </select>
                                </div>
                            </div>
                            <div class="button-group">
                                <button type="submit" name="create_certificate" class="btn btn-primary">
                                    <i class="fas fa-certificate"></i> Create Request
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-list"></i>
                            Certificate Requests
                        </h2>
                    </div>
                    <div class="card-body">
                        <?php if ($cert_stats['pending_certs'] == 0 && $cert_stats['approved_certs'] == 0 && $cert_stats['rejected_certs'] == 0): ?>
                        <p>No certificate requests at the moment.</p>
                        <?php else: ?>
                        <div class="table-responsive">
                            <table class="table" aria-describedby="Certificate Requests">
                                <thead>
                                    <tr>
                                        <th scope="col">User</th>
                                        <th scope="col">Certificate Type</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Request Date</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    try {
                                        $stmt = $conn->prepare("SELECT cr.id, cr.certificate_type, cr.status, cr.created_at, bu.first_name, bu.last_name 
                                                                FROM certificate_requests cr 
                                                                JOIN barangay_users bu ON cr.user_id = bu.id 
                                                                ORDER BY cr.created_at DESC");
                                        $stmt->execute();
                                        $certificate_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                    } catch (PDOException $e) {
                                        $certificate_requests = [];
                                        $_SESSION['toast_message'] = 'Error fetching certificate requests: ' . $e->getMessage();
                                        $_SESSION['toast_type'] = 'error';
                                    }
                                    if (empty($certificate_requests)):
                                    ?>
                                    <tr>
                                        <td colspan="5">No certificate requests found.</td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($certificate_requests as $request): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($request['first_name'] . ' ' . $request['last_name']); ?></td>
                                        <td><?php echo ucfirst(htmlspecialchars($request['certificate_type'])); ?></td>
                                        <td>
                                            <span class="badge badge-<?php
                                                echo $request['status'] == 'pending' ? 'warning' : ($request['status'] == 'approved' ? 'success' : 'danger');
                                            ?>">
                                                <?php echo ucfirst(htmlspecialchars($request['status'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('M d, Y g:i A', strtotime($request['created_at'])); ?></td>
                                        <td>
                                            <?php if ($request['status'] == 'pending'): ?>
                                            <form method="POST" action="">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                                <button type="submit" name="process_request" class="btn btn-primary btn-sm" onclick="this.form.querySelector('input[name=action]').value='approve';">
                                                    <i class="fas fa-check"></i> Approve
                                                    <input type="hidden" name="action" value="approve">
                                                </button>
                                                <button type="submit" name="process_request" class="btn btn-secondary btn-sm" onclick="this.form.querySelector('input[name=action]').value='reject';">
                                                    <i class="fas fa-times"></i> Reject
                                                    <input type="hidden" name="action" value="reject">
                                                </button>
                                            </form>
                                            <?php else: ?>
                                            <span>No actions available</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- User Management Tab -->
            <div id="users" class="tab-content <?php echo $active_tab === 'users' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-user-shield"></i>
                            User Management
                        </h2>
                        <button class="btn btn-primary btn-sm" id="addUserBtn">
                            <i class="fas fa-user-plus"></i> Add New User
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" id="usersTable" aria-describedby="User Management">
                                <thead>
                                    <tr>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Role</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Date Registered</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($all_users as $user): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td>
                                            <span class="badge badge-<?php
                                                if ($user['role'] === 'admin') echo 'danger';
                                                else if ($user['role'] === 'secretary') echo 'primary';
                                                else if ($user['role'] === 'treasurer') echo 'warning';
                                                else echo 'secondary';
                                            ?>">
                                                <?php echo ucfirst(htmlspecialchars($user['role'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge badge-<?php
                                                if ($user['is_approved'] == 1) echo 'success';
                                                elseif ($user['is_approved'] == 2) echo 'danger';
                                                else echo 'warning';
                                            ?>">
                                                <?php echo $user['is_approved'] == 1 ? 'Active' : ($user['is_approved'] == 2 ? 'Rejected' : 'Pending'); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                        <td>
                                            <button class="btn btn-primary btn-sm edit-user" data-id="<?php echo $user['id']; ?>" data-first-name="<?php echo htmlspecialchars($user['first_name']); ?>" data-last-name="<?php echo htmlspecialchars($user['last_name']); ?>" data-email="<?php echo htmlspecialchars($user['email']); ?>" data-role="<?php echo htmlspecialchars($user['role']); ?>">
                                                <i class="fas fa-edit"></i> Edit
                                            </button>
                                            <form method="POST" action="" style="display: inline;">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                <button type="submit" name="delete_user" class="btn btn-secondary btn-sm" onclick="return confirm('Are you sure you want to delete this user?');">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Announcements Tab -->
            <div id="announcements" class="tab-content <?php echo $active_tab === 'announcements' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-bullhorn"></i>
                            Create Announcement
                        </h2>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                            <div class="form-group">
                                <label for="announcement_title">Title</label>
                                <input type="text" class="form-control-full" id="announcement_title" name="announcement_title" required>
                            </div>
                            <div class="form-group">
                                <label for="announcement_content">Content</label>
                                <textarea class="form-control-full" id="announcement_content" name="announcement_content" rows="5" required></textarea>
                            </div>
                            <div class="button-group">
                                <button type="submit" name="create_announcement" class="btn btn-primary">
                                    <i class="fas fa-bullhorn"></i> Publish
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-list"></i>
                            Recent Announcements
                        </h2>
                    </div>
                    <div class="card-body">
                        <?php if (empty($announcements)): ?>
                        <p>No announcements yet.</p>
                        <?php else: ?>
                        <div class="household-list">
                            <?php foreach ($announcements as $announcement): ?>
                            <div class="household-card">
                                <div class="household-info alert alert-info">
                                    <h3><?php echo htmlspecialchars($announcement['title']); ?></h3>
                                    <p><?php echo htmlspecialchars($announcement['content']); ?></p>
                                    <p><strong>Posted on:</strong> <?php echo date('M d, Y g:i A', strtotime($announcement['created_at'])); ?></p>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Settings Tab -->
            <div id="settings" class="tab-content <?php echo $active_tab === 'settings' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-cog"></i>
                            Barangay Settings
                        </h2>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                            <div class="form-group">
                                <label for="barangay_name">Barangay Name</label>
                                <input type="text" class="form-control-full" id="barangay_name" name="barangay_name" value="<?php echo htmlspecialchars($barangay_settings['barangay_name']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="barangay_address">Barangay Address</label>
                                <input type="text" class="form-control-full" id="barangay_address" name="barangay_address" value="<?php echo htmlspecialchars($barangay_settings['barangay_address']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="barangay_contact">Contact Number</label>
                                <input type="text" class="form-control-full" id="barangay_contact" name="barangay_contact" value="<?php echo htmlspecialchars($barangay_settings['barangay_contact']); ?>">
                            </div>
                            <div class="button-group">
                                <button type="submit" name="update_settings" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Save Settings
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Profile Tab -->
            <div id="profile" class="tab-content <?php echo $active_tab === 'profile' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            <i class="fas fa-user-circle"></i>
                            User Profile
                        </h2>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="first_name">First Name</label>
                                    <input type="text" class="form-control-full" id="first_name" name="first_name" value="<?php echo htmlspecialchars($_SESSION['user']['first_name']); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="last_name">Last Name</label>
                                    <input type="text" class="form-control-full" id="last_name" name="last_name" value="<?php echo htmlspecialchars($_SESSION['user']['last_name']); ?>" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control-full" id="email" name="email" value="<?php echo htmlspecialchars($_SESSION['user']['email']); ?>" required>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="current_password">Current Password</label>
                                    <input type="password" class="form-control-full" id="current_password" name="current_password">
                                </div>
                                <div class="form-group">
                                    <label for="new_password">New Password (optional)</label>
                                    <input type="password" class="form-control-full" id="new_password" name="new_password" placeholder="Leave blank to keep current">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password</label>
                                <input type="password" class="form-control-full" id="confirm_password" name="confirm_password" placeholder="Confirm new password">
                            </div>
                            <div class="button-group">
                                <button type="submit" name="update_user" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Update Profile
                                </button>
                                <button type="submit" name="change_password" class="btn btn-primary">
                                    <i class="fas fa-key"></i> Change Password
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modals -->
    <!-- Add User Modal -->
    <div id="addUserModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Add New User</h3>
                <button class="modal-close" data-modal="addUserModal">×</button>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <div class="form-row">
                    <div class="form-group">
                        <label for="new_first_name">First Name</label>
                        <input type="text" class="form-control-full" id="new_first_name" name="new_first_name" required>
                    </div>
                    <div class="form-group">
                        <label for="new_last_name">Last Name</label>
                        <input type="text" class="form-control-full" id="new_last_name" name="new_last_name" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="new_email">Email</label>
                    <input type="email" class="form-control-full" id="new_email" name="new_email" required>
                </div>
                <div class="form-group">
                    <label for="new_password">Password</label>
                    <input type="password" class="form-control-full" id="new_password" name="new_password" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="new_phone">Phone</label>
                        <input type="text" class="form-control-full" id="new_phone" name="new_phone">
                    </div>
                    <div class="form-group">
                        <label for="new_purok">Purok</label>
                        <input type="text" class="form-control-full" id="new_purok" name="new_purok">
                    </div>
                </div>
                <div class="form-group">
                    <label for="new_address">Address</label>
                    <input type="text" class="form-control-full" id="new_address" name="new_address">
                </div>
                <div class="form-group">
                    <label for="new_role">Role</label>
                    <select class="form-control-full" id="new_role" name="new_role" required>
                        <option value="resident">Resident</option>
                        <option value="secretary">Secretary</option>
                        <option value="treasurer">Treasurer</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close" data-modal="addUserModal">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" name="add_user" class="btn btn-primary">
                        <i class="fas fa-user-plus"></i> Add User
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit User Modal -->
    <div id="editUserModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Edit User</h3>
                <button class="modal-close" data-modal="editUserModal">×</button>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" id="edit_user_id" name="user_id">
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_first_name">First Name</label>
                        <input type="text" class="form-control-full" id="edit_first_name" name="edit_first_name" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_last_name">Last Name</label>
                        <input type="text" class="form-control-full" id="edit_last_name" name="edit_last_name" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="edit_email">Email</label>
                    <input type="email" class="form-control-full" id="edit_email" name="edit_email" required>
                </div>
                <div class="form-group">
                    <label for="edit_role">Role</label>
                    <select class="form-control-full" id="edit_role" name="edit_role" required>
                        <option value="resident">Resident</option>
                        <option value="secretary">Secretary</option>
                        <option value="treasurer">Treasurer</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close" data-modal="editUserModal">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" name="edit_user" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save
                    </button>
                </div>
            </form>
        </div>
    </div>
<!-- Forgot Password Modal (Step 1: Email Verification) -->
<div class="modal fade" id="forgotPasswordModal" tabindex="-1" aria-labelledby="forgotPasswordModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="forgotPasswordModalLabel">Forgot Password</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="text-center mb-4">
          <div class="feature-icon mx-auto mb-3">
            <i class="bi bi-shield-lock"></i>
          </div>
          <p>Please enter your email address to receive a password reset link.</p>
        </div>
        
        <form id="forgotPasswordForm">
          <div class="mb-4">
            <label for="resetEmail" class="form-label">Gmail Address</label>
            <div class="input-group">
              <span class="input-group-text"><i class="bi bi-envelope"></i></span>
              <input type="email" class="form-control" id="resetEmail" name="email" placeholder="Enter your Gmail address" required>
            </div>
            <div class="error-message" id="emailError"></div>
          </div>
          
          <!-- Email Not Found Error Message (initially hidden) -->
          <div class="alert alert-danger d-none" id="emailNotFoundAlert">
            <i class="bi bi-exclamation-triangle me-2"></i>
            This email address is not registered in our system.
          </div>
          
          <button type="submit" class="modal-btn mt-3" id="verifyEmailBtn">
            <i class="bi bi-search me-2"></i>Verify Email
          </button>
        </form>
        
        <div class="text-center mt-4">
          <p class="mb-0">Remember your password? <a href="#" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#loginModal">Back to Login</a></p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Password Reset Modal (Step 2: After Email Verification) -->
<div class="modal fade" id="passwordResetModal" tabindex="-1" aria-labelledby="passwordResetModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="passwordResetModalLabel">Reset Your Password</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="text-center mb-4">
          <div class="feature-icon mx-auto mb-3">
            <i class="bi bi-key"></i>
          </div>
          <p>Create a new secure password for your account.</p>
          <div class="badge bg-success mb-3 py-2 px-3">Email Verified: <span id="verifiedEmail">user@gmail.com</span></div>
        </div>
        
        <form id="resetPasswordForm">
          <div class="mb-3">
            <label for="currentPassword" class="form-label">Current Password</label>
            <div class="input-group">
              <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
              <input type="password" class="form-control" id="currentPassword" name="currentPassword" placeholder="Enter your current password" required>
              <span class="input-group-text toggle-password" data-target="currentPassword"><i class="bi bi-eye"></i></span>
            </div>
            <div class="error-message" id="currentPasswordError"></div>
          </div>
          
          <div class="mb-3">
            <label for="newPassword" class="form-label">New Password</label>
            <div class="input-group">
              <span class="input-group-text"><i class="bi bi-lock"></i></span>
              <input type="password" class="form-control" id="newPassword" name="newPassword" placeholder="Enter new password" required>
              <span class="input-group-text toggle-password" data-target="newPassword"><i class="bi bi-eye"></i></span>
            </div>
            <div class="error-message" id="newPasswordError"></div>
          </div>
          
          <div class="mb-4">
            <label for="confirmPassword" class="form-label">Confirm New Password</label>
            <div class="input-group">
              <span class="input-group-text"><i class="bi bi-lock"></i></span>
              <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" placeholder="Confirm new password" required>
              <span class="input-group-text toggle-password" data-target="confirmPassword"><i class="bi bi-eye"></i></span>
            </div>
            <div class="error-message" id="confirmPasswordError"></div>
          </div>
          
          <!-- Password reset success message (initially hidden) -->
          <div class="alert alert-success d-none" id="resetSuccessAlert">
            <i class="bi bi-check-circle me-2"></i>
            Your password has been reset successfully!
          </div>
          
          <button type="submit" class="modal-btn mt-3">
            <i class="bi bi-check2-circle me-2"></i>Reset Password
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- JavaScript for Forgot Password Flow -->
<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Update the "Forgot password?" link in the login modal
    const forgotPasswordLink = document.querySelector('.form-check a');
    if (forgotPasswordLink) {
      forgotPasswordLink.setAttribute('data-bs-toggle', 'modal');
      forgotPasswordLink.setAttribute('data-bs-target', '#forgotPasswordModal');
    }
    
    // Toggle password visibility
    document.querySelectorAll('.toggle-password').forEach(toggle => {
      toggle.addEventListener('click', function() {
        const targetId = this.getAttribute('data-target');
        const targetInput = document.getElementById(targetId);
        const icon = this.querySelector('i');
        
        if (targetInput.type === 'password') {
          targetInput.type = 'text';
          icon.classList.remove('bi-eye');
          icon.classList.add('bi-eye-slash');
          this.classList.add('active');
        } else {
          targetInput.type = 'password';
          icon.classList.remove('bi-eye-slash');
          icon.classList.add('bi-eye');
          this.classList.remove('active');
        }
      });
    });
    
    // Email verification (step 1)
    const forgotPasswordForm = document.getElementById('forgotPasswordForm');
    if (forgotPasswordForm) {
      forgotPasswordForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('resetEmail').value;
        const emailError = document.getElementById('emailError');
        const emailNotFoundAlert = document.getElementById('emailNotFoundAlert');
        
        // Clear previous errors
        emailError.textContent = '';
        emailNotFoundAlert.classList.add('d-none');
        
        // Basic email validation
        if (!email || !email.includes('@') || !email.includes('.')) {
          emailError.textContent = 'Please enter a valid email address';
          return;
        }
        
        // Simulate email verification (in a real app, this would be an API call)
        // For demo: treat emails ending with "@example.com" as "not found"
        if (email.endsWith('@example.com')) {
          emailNotFoundAlert.classList.remove('d-none');
        } else {
          // Close current modal and open password reset modal
          const forgotModal = bootstrap.Modal.getInstance(document.getElementById('forgotPasswordModal'));
          forgotModal.hide();
          
          // Set the verified email in the next modal
          document.getElementById('verifiedEmail').textContent = email;
          
          // Open the password reset modal
          setTimeout(() => {
            const resetModal = new bootstrap.Modal(document.getElementById('passwordResetModal'));
            resetModal.show();
          }, 500);
        }
      });
    }
    
    // Password reset form (step 2)
    const resetPasswordForm = document.getElementById('resetPasswordForm');
    if (resetPasswordForm) {
      resetPasswordForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const currentPassword = document.getElementById('currentPassword').value;
        const newPassword = document.getElementById('newPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        
        const currentPasswordError = document.getElementById('currentPasswordError');
        const newPasswordError = document.getElementById('newPasswordError');
        const confirmPasswordError = document.getElementById('confirmPasswordError');
        const resetSuccessAlert = document.getElementById('resetSuccessAlert');
        
        // Clear previous errors
        currentPasswordError.textContent = '';
        newPasswordError.textContent = '';
        confirmPasswordError.textContent = '';
        resetSuccessAlert.classList.add('d-none');
        
        // Validate current password (in real app, this would be verified against database)
        if (!currentPassword) {
          currentPasswordError.textContent = 'Please enter your current password';
          return;
        }
        
        // Validate new password
        if (newPassword.length < 8) {
          newPasswordError.textContent = 'Password must be at least 8 characters long';
          return;
        }
        
        // Confirm passwords match
        if (newPassword !== confirmPassword) {
          confirmPasswordError.textContent = 'Passwords do not match';
          return;
        }
        
        // Show success message
        resetSuccessAlert.classList.remove('d-none');
        
        // Disable form fields and button after successful submission
        document.getElementById('currentPassword').disabled = true;
        document.getElementById('newPassword').disabled = true;
        document.getElementById('confirmPassword').disabled = true;
        resetPasswordForm.querySelector('button[type="submit"]').disabled = true;
        
        // Redirect to login after 3 seconds (in real app)
        setTimeout(() => {
          const resetModal = bootstrap.Modal.getInstance(document.getElementById('passwordResetModal'));
          resetModal.hide();
          
          // Optional: Show login modal
          setTimeout(() => {
            const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
            loginModal.show();
          }, 500);
        }, 3000);
      });
    }
  });
</script>
    <!-- Toast Notifications -->
    <?php if ($toast_message): ?>
    <div class="toast-container">
        <div class="toast toast-<?php echo $toast_type; ?>">
            <div class="toast-header">
                <span class="toast-title">
                    <i class="fas fa-<?php echo $toast_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo $toast_type === 'success' ? 'Success' : 'Error'; ?>
                </span>
                <button class="toast-close">×</button>
            </div>
            <div class="toast-body">
                <?php echo htmlspecialchars($toast_message); ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <script>
        $(document).ready(function() {
            // Sidebar toggle for mobile
            $('.mobile-toggle').click(function() {
                $('.sidebar').toggleClass('show');
            });

            // Close sidebar when clicking outside on mobile
            $(document).click(function(e) {
                if ($(window).width() <= 768 && !$(e.target).closest('.sidebar').length && !$(e.target).closest('.mobile-toggle').length) {
                    $('.sidebar').removeClass('show');
                }
            });

            // Tab navigation
            $('.tab-nav-item, .menu-item').click(function(e) {
                e.preventDefault();
                var target = $(this).data('target');
                $('.tab-nav-item').removeClass('active');
                $('.tab-content').removeClass('active');
                $('.menu-item').removeClass('active');
                
                $('.tab-nav-item[data-target="' + target + '"]').addClass('active');
                $('#' + target).addClass('active');
                $('.menu-item[data-target="' + target + '"]').addClass('active');

                // Update active tab via AJAX
                $.post('', { active_tab: target });

                // Update URL hash
                window.location.hash = target;
            });

            // Handle page load with hash
            if (window.location.hash) {
                var target = window.location.hash.substring(1);
                $('.tab-nav-item').removeClass('active');
                $('.tab-content').removeClass('active');
                $('.menu-item').removeClass('active');
                
                $('.tab-nav-item[data-target="' + target + '"]').addClass('active');
                $('#' + target).addClass('active');
                $('.menu-item[data-target="' + target + '"]').addClass('active');
                
                $.post('', { active_tab: target });
            }

            // Modal handling
            function openModal(modalId) {
                $('#' + modalId).fadeIn();
                $('body').css('overflow', 'hidden');
            }

            function closeModal(modalId) {
                $('#' + modalId).fadeOut();
                $('body').css('overflow', 'auto');
            }

            $('.modal-close').click(function() {
                var modalId = $(this).data('modal');
                closeModal(modalId);
            });

            // Add User Modal
            $('#addUserBtn').click(function() {
                openModal('addUserModal');
                $('#new_first_name').focus();
            });

            // Edit User Modal
            $('.edit-user').click(function() {
                $('#edit_user_id').val($(this).data('id'));
                $('#edit_first_name').val($(this).data('first-name'));
                $('#edit_last_name').val($(this).data('last-name'));
                $('#edit_email').val($(this).data('email'));
                $('#edit_role').val($(this).data('role'));
                openModal('editUserModal');
                $('#edit_first_name').focus();
            });

            // Chart initialization
            var ctx = document.getElementById('userStatsChart').getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Admins', 'Treasurers', 'Secretaries', 'Residents'],
                    datasets: [{
                        label: 'User Distribution',
                        data: [
                            <?php echo $stats['admin_count']; ?>,
                            <?php echo $stats['treasurer_count']; ?>,
                            <?php echo $stats['secretary_count']; ?>,
                            <?php echo ($stats['active_count'] - $stats['admin_count'] - $stats['treasurer_count'] - $stats['secretary_count']); ?>
                        ],
                        backgroundColor: [
                            'rgba(231, 76, 60, 0.7)',
                            'rgba(241, 196, 15, 0.7)',
                            'rgba(39, 174, 96, 0.7)',
                            'rgba(108, 117, 125, 0.7)'
                        ],
                        borderColor: [
                            'rgba(231, 76, 60, 1)',
                            'rgba(241, 196, 15, 1)',
                            'rgba(39, 174, 96, 1)',
                            'rgba(108, 117, 125, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Number of Users'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            position: 'top'
                        },
                        title: {
                            display: true,
                            text: 'User Role Distribution'
                        }
                    }
                }
            });

        // Toast and announcement handling
$('.toast-close').click(function() {
    $(this).closest('.toast').fadeOut();
});

setTimeout(function() {
    $('.toast').fadeOut();
}, 5000);

// Announcement pop-up
<?php if (!empty($announcements)): ?>
var announcements = <?php echo json_encode($announcements); ?>;
var currentAnnouncement = 0;

function createAnnouncementToast() {
    return $(
        '<div class="toast toast-info" id="announcementToast">' +
        '<div class="toast-header">' +
        '<span class="toast-title"><i class="fas fa-bullhorn"></i> Announcement</span>' +
        '<button class="toast-close">×</button>' +
        '</div>' +
        '<div class="toast-body" id="announcementText"></div>' +
        '</div>'
    );
}

var announcementToast = createAnnouncementToast();
$('.toast-container').append(announcementToast);

function showAnnouncement() {
    if (announcements.length > 0) {
        $('#announcementText').text(announcements[currentAnnouncement].title);
        $('#announcementToast').fadeIn();
        setTimeout(function() {
            $('#announcementToast').fadeOut();
            currentAnnouncement = (currentAnnouncement + 1) % announcements.length;
            setTimeout(showAnnouncement, 2000);
        }, 5000);
    }
}

showAnnouncement();

// Handle close button for announcement toast
$('#announcementToast .toast-close').click(function() {
    $('#announcementToast').fadeOut();
    // Optionally stop cycling announcements
    // clearTimeout(setTimeout(showAnnouncement));
});
<?php endif; ?>
        });
    </script>
</body>
</html>