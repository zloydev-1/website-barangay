
  // Initialize AOS animations
  document.addEventListener('DOMContentLoaded', function() {
    AOS.init({
      duration: 800,
      once: true,
      offset: 100
    });
    
    // Toggle password visibility for login
    const togglePassword = document.getElementById('togglePassword');
    const passwordField = document.getElementById('loginPassword');
    if (togglePassword && passwordField) {
      togglePassword.addEventListener('click', function() {
        const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordField.setAttribute('type', type);
        this.querySelector('i').classList.toggle('bi-eye');
        this.querySelector('i').classList.toggle('bi-eye-slash');
      });
    }
    
    // Toggle password visibility for signup
    const toggleSignupPassword = document.getElementById('toggleSignupPassword');
    const signupPasswordField = document.getElementById('password');
    if (toggleSignupPassword && signupPasswordField) {
      toggleSignupPassword.addEventListener('click', function() {
        const type = signupPasswordField.getAttribute('type') === 'password' ? 'text' : 'password';
        signupPasswordField.setAttribute('type', type);
        this.querySelector('i').classList.toggle('bi-eye');
        this.querySelector('i').classList.toggle('bi-eye-slash');
      });
    }
    
    // Toggle password visibility for retype password
    const toggleRetypePassword = document.getElementById('toggleRetypePassword');
    const retypePasswordField = document.getElementById('retypePassword');
    if (toggleRetypePassword && retypePasswordField) {
      toggleRetypePassword.addEventListener('click', function() {
        const type = retypePasswordField.getAttribute('type') === 'password' ? 'text' : 'password';
        retypePasswordField.setAttribute('type', type);
        this.querySelector('i').classList.toggle('bi-eye');
        this.querySelector('i').classList.toggle('bi-eye-slash');
      });
    }

    // Toggle password visibility for reset password
    const toggleOldPassword = document.getElementById('toggleOldPassword');
    const oldPasswordField = document.getElementById('oldPassword');
    if (toggleOldPassword && oldPasswordField) {
      toggleOldPassword.addEventListener('click', function() {
        const type = oldPasswordField.getAttribute('type') === 'password' ? 'text' : 'password';
        oldPasswordField.setAttribute('type', type);
        this.querySelector('i').classList.toggle('bi-eye');
        this.querySelector('i').classList.toggle('bi-eye-slash');
      });
    }

    const toggleNewPassword = document.getElementById('toggleNewPassword');
    const newPasswordField = document.getElementById('newPassword');
    if (toggleNewPassword && newPasswordField) {
      toggleNewPassword.addEventListener('click', function() {
        const type = newPasswordField.getAttribute('type') === 'password' ? 'text' : 'password';
        newPasswordField.setAttribute('type', type);
        this.querySelector('i').classList.toggle('bi-eye');
        this.querySelector('i').classList.toggle('bi-eye-slash');
      });
    }

    const toggleRetypeNewPassword = document.getElementById('toggleRetypeNewPassword');
    const retypeNewPasswordField = document.getElementById('retypeNewPassword');
    if (toggleRetypeNewPassword && retypeNewPasswordField) {
      toggleRetypeNewPassword.addEventListener('click', function() {
        const type = retypeNewPasswordField.getAttribute('type') === 'password' ? 'text' : 'password';
        retypeNewPasswordField.setAttribute('type', type);
        this.querySelector('i').classList.toggle('bi-eye');
        this.querySelector('i').classList.toggle('bi-eye-slash');
      });
    }
    
    // Clear error messages
    function clearErrors() {
      document.querySelectorAll('.error-message').forEach(el => el.textContent = '');
    }
    
    // Real-time password matching for signup
    const passwordInput = document.getElementById('password');
    const retypePasswordInput = document.getElementById('retypePassword');
    const retypePasswordError = document.getElementById('retypePasswordError');
    if (passwordInput && retypePasswordInput && retypePasswordError) {
      retypePasswordInput.addEventListener('input', function() {
        const password = passwordInput.value;
        const retypePassword = retypePasswordInput.value;
        if (retypePassword && password !== retypePassword) {
          retypePasswordError.textContent = 'Passwords do not match.';
        } else {
          retypePasswordError.textContent = '';
        }
      });
      passwordInput.addEventListener('input', function() {
        const password = passwordInput.value;
        const retypePassword = retypePasswordInput.value;
        if (retypePassword && password !== retypePassword) {
          retypePasswordError.textContent = 'Passwords do not match.';
        } else {
          retypePasswordError.textContent = '';
        }
      });
    }

    // Real-time password matching for reset password
    const newPasswordInput = document.getElementById('newPassword');
    const retypeNewPasswordInput = document.getElementById('retypeNewPassword');
    const retypeNewPasswordError = document.getElementById('retypeNewPasswordError');
    if (newPasswordInput && retypeNewPasswordInput && retypeNewPasswordError) {
      retypeNewPasswordInput.addEventListener('input', function() {
        const newPassword = newPasswordInput.value;
        const retypeNewPassword = retypeNewPasswordInput.value;
        if (retypeNewPassword && newPassword !== retypeNewPassword) {
          retypeNewPasswordError.textContent = 'Passwords do not match.';
        } else {
          retypeNewPasswordError.textContent = '';
        }
      });
      newPasswordInput.addEventListener('input', function() {
        const newPassword = newPasswordInput.value;
        const retypeNewPassword = retypeNewPasswordInput.value;
        if (retypeNewPassword && newPassword !== retypeNewPassword) {
          retypeNewPasswordError.textContent = 'Passwords do not match.';
        } else {
          retypeNewPasswordError.textContent = '';
        }
      });
    }
    
    // Login form submission
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
      loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        clearErrors();

        const formData = new FormData(loginForm);

        try {
          const response = await fetch('php/login.php', {
            method: 'POST',
            body: formData
          });

          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }

          const result = await response.json();
          
          if (result.status === 'success') {
            showToast('success', result.message);
            setTimeout(() => {
              window.location.href = result.redirect;
            }, 2000);
          } else {
            if (Array.isArray(result.errors)) {
              result.errors.forEach(error => {
                showToast('error', error);
              });
            } else {
              showToast('error', result.message || 'An error occurred.');
            }
          }
        } catch (error) {
          console.error('Fetch error:', error);
                   showToast('error', 'Unable to connect to the server. Please try again later.');
        }
      });
    }
document.addEventListener('DOMContentLoaded', function() {
  // Clear error messages
  function clearErrors() {
    document.querySelectorAll('.error-message').forEach(el => el.textContent = '');
  }

  // Show toast notification
  function showToast(type, message) {
    const toastEl = document.getElementById(`${type}Toast`);
    const toastMessage = document.getElementById(`${type}ToastMessage`);
    if (toastEl && toastMessage) {
      console.log(`Showing ${type} toast with message: ${message}`);
      toastMessage.textContent = message;
      const toast = new bootstrap.Toast(toastEl, { autohide: true, delay: 5000 });
      toast.show();
    } else {
      console.error(`Toast elements not found: ${type}Toast or ${type}ToastMessage`);
    }
  }

  // Password visibility toggle
  document.querySelectorAll('.toggle-password').forEach(toggle => {
    toggle.addEventListener('click', function() {
      const targetId = this.getAttribute('data-target');
      const input = document.getElementById(targetId);
      const icon = this.querySelector('i');
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.replace('bi-eye', 'bi-eye-slash');
      } else {
        input.type = 'password';
        icon.classList.replace('bi-eye-slash', 'bi-eye');
      }
    });
  });

  // Forgot Password form submission
  const forgotPasswordForm = document.getElementById('forgotPasswordForm');
  if (forgotPasswordForm) {
    forgotPasswordForm.addEventListener('submit', async function(e) {
      e.preventDefault();
      clearErrors();

      const formData = new FormData(forgotPasswordForm);
      const email = formData.get('email');

      // Client-side email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        document.getElementById('forgotEmailError').textContent = 'Please enter a valid email address.';
        showToast('error', 'Invalid email address.');
        return;
      }

      try {
        console.log('Sending fetch request to php/forgot_password.php');
        const response = await fetch('php/forgot_password.php', {
          method: 'POST',
          body: formData
        });

        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const result = await response.json();
        console.log('Forgot Password response:', result);

        if (result.status === 'success') {
          showToast('success', result.message);
          // Store email in Reset Password form
          const resetForm = document.getElementById('resetPasswordForm');
          if (resetForm) {
            const emailInput = document.createElement('input');
            emailInput.type = 'hidden';
            emailInput.name = 'email';
            emailInput.value = email;
            resetForm.appendChild(emailInput);
          }
          bootstrap.Modal.getInstance(document.getElementById('forgotPasswordModal')).hide();
          bootstrap.Modal.getOrCreateInstance(document.getElementById('resetPasswordModal')).show();
        } else {
          document.getElementById('forgotEmailError').textContent = result.message || 'An error occurred.';
          showToast('error', result.message || 'Email not found.');
        }
      } catch (error) {
        console.error('Fetch error:', error);
        showToast('error', 'Unable to connect to the server. Please try again later.');
      }
    });
  }

  // Reset Password form submission
  const resetPasswordForm = document.getElementById('resetPasswordForm');
  const resetButton = document.getElementById('resetPasswordButton');
  if (resetPasswordForm && resetButton) {
    console.log('Reset Password Form and Button found');
    resetPasswordForm.addEventListener('submit', async function(e) {
      e.preventDefault();
      console.log('Form submitted via submit event');
      clearErrors();

      const formData = new FormData(resetPasswordForm);
      const oldPassword = formData.get('oldPassword');
      const newPassword = formData.get('newPassword');
      const retypeNewPassword = formData.get('retypeNewPassword');
      const email = formData.get('email');

      // Client-side password validation
      const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
      if (!email) {
        showToast('error', 'Email is missing. Please try again from Forgot Password.');
        return;
      }
      if (!passwordRegex.test(newPassword)) {
        document.getElementById('newPasswordError').textContent = 'Password must be at least 8 characters long with letters and numbers.';
        showToast('error', 'Invalid new password.');
        console.log('Password validation failed');
        return;
      }
      if (newPassword !== retypeNewPassword) {
        document.getElementById('retypeNewPasswordError').textContent = 'Passwords do not match.';
        showToast('error', 'Passwords do not match.');
        console.log('Password mismatch');
        return;
      }

      try {
        console.log('Sending fetch request to php/reset_password.php');
        const response = await fetch('php/reset_password.php', {
          method: 'POST',
          body: formData
        });

        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const result = await response.json();
        console.log('Reset Password response:', result);

        if (result.status === 'success') {
          console.log('Showing success toast');
          showToast('success', result.message);
          resetPasswordForm.reset();
          bootstrap.Modal.getInstance(document.getElementById('resetPasswordModal')).hide();
          bootstrap.Modal.getOrCreateInstance(document.getElementById('loginModal')).show();
        } else {
          console.log('Error response received');
          if (result.errors) {
            Object.keys(result.errors).forEach(field => {
              const errorElement = document.getElementById(`${field}Error`);
              if (errorElement) {
                errorElement.textContent = result.errors[field];
              }
            });
            showToast('error', 'Please correct the errors in the form.');
          } else {
            showToast('error', result.message || 'An error occurred during password reset.');
          }
        }
      } catch (error) {
        console.error('Fetch error:', error);
        showToast('error', 'Unable to connect to the server. Please try again later.');
      }
    });

    resetButton.addEventListener('click', function(e) {
      console.log('Reset Password Button clicked');
      resetPasswordForm.dispatchEvent(new Event('submit', { cancelable: true }));
    });
  } else {
    console.error('Reset Password Form or Button not found');
  }
});
    // Registration form submission
    const registrationForm = document.getElementById('registrationForm');
    if (registrationForm) {
      registrationForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        clearErrors();

        const formData = new FormData(registrationForm);
        const password = formData.get('password');
        const retypePassword = formData.get('retypePassword');
        const termsAgree = document.getElementById('termsAgree').checked;

        // Client-side password validation
        const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
        if (!passwordRegex.test(password)) {
          document.getElementById('passwordError').textContent = 'Password must be at least 8 characters long with letters and numbers.';
          return;
        }

        if (password !== retypePassword) {
          document.getElementById('retypePasswordError').textContent = 'Passwords do not match.';
          return;
        }

        if (!termsAgree) {
          document.getElementById('termsAgreeError').textContent = 'You must agree to the Terms of Service and Privacy Policy.';
          return;
        }

        try {
          const response = await fetch('php/register.php', {
            method: 'POST',
            body: formData
          });

          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }

          const result = await response.json();

          if (result.status === 'success') {
            document.getElementById('registrationSuccess').classList.remove('d-none');
            registrationForm.reset();
            showToast('success', result.message);
            setTimeout(() => {
              document.getElementById('registrationSuccess').classList.add('d-none');
              bootstrap.Modal.getInstance(document.getElementById('signupModal')).hide();
            }, 3000);
          } else {
            if (result.errors) {
              Object.keys(result.errors).forEach(field => {
                document.getElementById(`${field}Error`).textContent = result.errors[field];
              });
            } else {
              showToast('error', result.message || 'An error occurred during registration.');
            }
          }
        } catch (error) {
          console.error('Fetch error:', error);
          showToast('error', 'Unable to connect to the server. Please try again later.');
        }
      });
    }

    // Forgot Password form submission
const forgotPasswordForm = document.getElementById('forgotPasswordForm');
if (forgotPasswordForm) {
  forgotPasswordForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    clearErrors();

    const formData = new FormData(forgotPasswordForm);
    const email = formData.get('email');

    // Client-side email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      document.getElementById('forgotEmailError').textContent = 'Please enter a valid email address.';
      return;
    }

    try {
      const response = await fetch('php/forgot_password.php', {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const result = await response.json();

      if (result.status === 'success') {
        showToast('success', result.message);
        // Optionally open Reset Password modal or redirect
        bootstrap.Modal.getInstance(document.getElementById('forgotPasswordModal')).hide();
        bootstrap.Modal.getOrCreateInstance(document.getElementById('resetPasswordModal')).show();
      } else {
        document.getElementById('forgotEmailError').textContent = result.message || 'An error occurred.';
        showToast('error', result.message || 'Email not found.');
      }
    } catch (error) {
      console.error('Fetch error:', error);
      showToast('error', 'Unable to connect to the server. Please try again later.');
    }
  });
}

    // Reset Password form submission
    const resetPasswordForm = document.getElementById('resetPasswordForm');
    if (resetPasswordForm) {
      resetPasswordForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        clearErrors();

        const formData = new FormData(resetPasswordForm);
        const oldPassword = formData.get('oldPassword');
        const newPassword = formData.get('newPassword');
        const retypeNewPassword = formData.get('retypeNewPassword');

        // Client-side password validation
        const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
        if (!passwordRegex.test(newPassword)) {
          document.getElementById('newPasswordError').textContent = 'Password must be at least 8 characters long with letters and numbers.';
          return;
        }

        if (newPassword !== retypeNewPassword) {
          document.getElementById('retypeNewPasswordError').textContent = 'Passwords do not match.';
          return;
        }

        try {
          const response = await fetch('php/reset_password.php', {
            method: 'POST',
            body: formData
          });

          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }

          const result = await response.json();

          if (result.status === 'success') {
            showToast('success', result.message);
            resetPasswordForm.reset();
            bootstrap.Modal.getInstance(document.getElementById('resetPasswordModal')).hide();
            bootstrap.Modal.getOrCreateInstance(document.getElementById('loginModal')).show();
          } else {
            if (result.errors) {
              Object.keys(result.errors).forEach(field => {
                document.getElementById(`${field}Error`).textContent = result.errors[field];
              });
            } else {
              showToast('error', result.message || 'An error occurred during password reset.');
            }
          }
        } catch (error) {
          console.error('Fetch error:', error);
          showToast('error', 'Unable to connect to the server. Please try again later.');
        }
      });
    }

    // Contact form submission
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
      contactForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        clearErrors();

        const formData = new FormData(contactForm);

        try {
          const response = await fetch('php/contact.php', {
            method: 'POST',
            body: formData
          });

          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }

          const result = await response.json();

          if (result.status === 'success') {
            showToast('success', result.message);
            contactForm.reset();
          } else {
            showToast('error', result.message || 'An error occurred while sending your message.');
          }
        } catch (error) {
          console.error('Fetch error:', error);
          showToast('error', 'Unable to connect to the server. Please try again later.');
        }
      });
    }

    // Stats counter animation
    const stats = document.querySelectorAll('.stat-value');
    stats.forEach(stat => {
      const updateCount = () => {
        const target = +stat.getAttribute('data-count');
        const count = +stat.innerText.replace(/[^0-9]/g, '');
        const increment = target / 100;

        if (count < target) {
          stat.innerText = Math.ceil(count + increment).toLocaleString() + (stat.innerText.includes('+') ? '+' : '');
          setTimeout(updateCount, 20);
        } else {
          stat.innerText = target.toLocaleString() + (stat.innerText.includes('+') ? '+' : '');
        }
      };

      const observer = new IntersectionObserver(entries => {
        if (entries[0].isIntersecting) {
          updateCount();
          observer.disconnect();
        }
      }, { threshold: 0.5 });

      observer.observe(stat);
    });

    // Show toast notification
    function showToast(type, message) {
      const toastEl = document.getElementById(`${type}Toast`);
      const toastMessage = document.getElementById(`${type}ToastMessage`);
      if (toastEl && toastMessage) {
        toastMessage.textContent = message;
        const toast = new bootstrap.Toast(toastEl);
        toast.show();
      }
    }

    // Ensure modals close properly when navigating
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
      modal.addEventListener('hidden.bs.modal', function() {
        clearErrors();
        const forms = modal.querySelectorAll('form');
        forms.forEach(form => form.reset());
      });
    });
  });
