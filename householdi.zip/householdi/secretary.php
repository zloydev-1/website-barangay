<?php
session_start();

// Check if secretary is logged in
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'secretary') {
    header('Location: index.php');
    exit;
}

// Initialize CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Set active tab
if (isset($_POST['active_tab'])) {
    $_SESSION['active_tab'] = $_POST['active_tab'];
}
$active_tab = $_SESSION['active_tab'] ?? 'overview';

// Database connection
$conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Helper function to validate CSRF token
function validate_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && is_string($_SESSION['csrf_token']) && is_string($token) && hash_equals($_SESSION['csrf_token'], $token);
}

// Handle household addition
if (isset($_POST['add_household']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $household_name = filter_input(INPUT_POST, 'household_name', FILTER_SANITIZE_STRING);
        $head_of_family = filter_input(INPUT_POST, 'head_of_family', FILTER_SANITIZE_STRING);
        $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);
        $members_count = filter_input(INPUT_POST, 'members_count', FILTER_VALIDATE_INT) ?: 0;
        $contact_number = filter_input(INPUT_POST, 'contact_number', FILTER_SANITIZE_STRING);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $registration_date = date('Y-m-d');
        $status = 'Active';

        // Check for duplicate household
        $stmt = $conn->prepare("SELECT household_id FROM households WHERE household_name = ? OR head_of_family = ?");
        $stmt->bind_param("ss", $household_name, $head_of_family);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $_SESSION['toast_message'] = "Error: Household with this name or head already exists.";
            $_SESSION['toast_type'] = "error";
        } else {
            $stmt = $conn->prepare("INSERT INTO households (household_name, head_of_family, address, members_count, contact_number, email, registration_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssissss", $household_name, $head_of_family, $address, $members_count, $contact_number, $email, $registration_date, $status);
            if ($stmt->execute()) {
                $_SESSION['toast_message'] = "Household added successfully!";
                $_SESSION['toast_type'] = "success";
            } else {
                $_SESSION['toast_message'] = "Error adding household: " . $stmt->error;
                $_SESSION['toast_type'] = "error";
            }
        }
        $stmt->close();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;

}

// Handle household update
if (isset($_POST['update_household']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $household_id = filter_input(INPUT_POST, 'household_id', FILTER_VALIDATE_INT);
        $household_name = filter_input(INPUT_POST, 'household_name', FILTER_SANITIZE_STRING);
        $head_of_family = filter_input(INPUT_POST, 'head_of_family', FILTER_SANITIZE_STRING);
        $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);
        $members_count = filter_input(INPUT_POST, 'members_count', FILTER_VALIDATE_INT) ?: 0;
        $contact_number = filter_input(INPUT_POST, 'contact_number', FILTER_SANITIZE_STRING);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING);

        $stmt = $conn->prepare("UPDATE households SET household_name = ?, head_of_family = ?, address = ?, members_count = ?, contact_number = ?, email = ?, status = ? WHERE household_id = ?");
        $stmt->bind_param("sssisssi", $household_name, $head_of_family, $address, $members_count, $contact_number, $email, $status, $household_id);
        if ($stmt->execute()) {
            $_SESSION['toast_message'] = "Household updated successfully!";
            $_SESSION['toast_type'] = "success";
        } else {
            $_SESSION['toast_message'] = "Error updating household: " . $stmt->error;
            $_SESSION['toast_type'] = "error";
        }
        $stmt->close();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
}

// Handle household deletion
if (isset($_POST['delete_household']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $household_id = filter_input(INPUT_POST, 'household_id', FILTER_VALIDATE_INT);
        $stmt = $conn->prepare("DELETE FROM households WHERE household_id = ?");
        $stmt->bind_param("i", $household_id);
        if ($stmt->execute()) {
            $_SESSION['toast_message'] = "Household deleted successfully!";
            $_SESSION['toast_type'] = "success";
        } else {
            $_SESSION['toast_message'] = "Error deleting household: " . $stmt->error;
            $_SESSION['toast_type'] = "error";
        }
        $stmt->close();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
}

// Handle household member addition
if (isset($_POST['add_member']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $household_id = filter_input(INPUT_POST, 'modal_household_id', FILTER_VALIDATE_INT);
        $full_name = filter_input(INPUT_POST, 'member_fullname', FILTER_SANITIZE_STRING);
        $birth_date = filter_input(INPUT_POST, 'member_birthdate', FILTER_SANITIZE_STRING);
        $age = filter_input(INPUT_POST, 'member_age', FILTER_VALIDATE_INT);
        $gender = filter_input(INPUT_POST, 'member_gender', FILTER_SANITIZE_STRING);
        $relationship = filter_input(INPUT_POST, 'member_relationship', FILTER_SANITIZE_STRING);
        $occupation = filter_input(INPUT_POST, 'member_occupation', FILTER_SANITIZE_STRING);
        $education_level = filter_input(INPUT_POST, 'member_education', FILTER_SANITIZE_STRING);

        // Verify household_id exists
        $stmt = $conn->prepare("SELECT household_id FROM households WHERE household_id = ?");
        $stmt->bind_param("i", $household_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            $_SESSION['toast_message'] = "Invalid household ID.";
            $_SESSION['toast_type'] = "error";
        } else {
            $stmt = $conn->prepare("INSERT INTO household_members (household_id, fullname, birthdate, age, gender, relationship, occupation, education_level) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ississss", $household_id, $full_name, $birth_date, $age, $gender, $relationship, $occupation, $education_level);
            if ($stmt->execute()) {
                $conn->query("UPDATE households SET members_count = members_count + 1 WHERE household_id = $household_id");
                $_SESSION['toast_message'] = "Member added successfully!";
                $_SESSION['toast_type'] = "success";
            } else {
                $_SESSION['toast_message'] = "Error adding member: " . $stmt->error;
                $_SESSION['toast_type'] = "error";
            }
        }
        $stmt->close();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
}

// Handle household member update
if (isset($_POST['update_member']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $member_id = filter_input(INPUT_POST, 'member_id', FILTER_VALIDATE_INT);
        $household_id = filter_input(INPUT_POST, 'household_id', FILTER_VALIDATE_INT);
        $full_name = filter_input(INPUT_POST, 'member_fullname', FILTER_SANITIZE_STRING);
        $birth_date = filter_input(INPUT_POST, 'member_birthdate', FILTER_SANITIZE_STRING);
        $age = filter_input(INPUT_POST, 'member_age', FILTER_VALIDATE_INT);
        $gender = filter_input(INPUT_POST, 'member_gender', FILTER_SANITIZE_STRING);
        $relationship = filter_input(INPUT_POST, 'member_relationship', FILTER_SANITIZE_STRING);
        $occupation = filter_input(INPUT_POST, 'member_occupation', FILTER_SANITIZE_STRING);
        $education_level = filter_input(INPUT_POST, 'member_education', FILTER_SANITIZE_STRING);

        $stmt = $conn->prepare("UPDATE household_members SET household_id = ?, fullname = ?, birthdate = ?, age = ?, gender = ?, relationship = ?, occupation = ?, education_level = ? WHERE member_id = ?");
        $stmt->bind_param("ississssi", $household_id, $full_name, $birth_date, $age, $gender, $relationship, $occupation, $education_level, $member_id);
        if ($stmt->execute()) {
            $_SESSION['toast_message'] = "Member updated successfully!";
            $_SESSION['toast_type'] = "success";
        } else {
            $_SESSION['toast_message'] = "Error updating member: " . $stmt->error;
            $_SESSION['toast_type'] = "error";
        }
        $stmt->close();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
}

// Handle household member deletion
if (isset($_POST['delete_member']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $member_id = filter_input(INPUT_POST, 'member_id', FILTER_VALIDATE_INT);
        $household_id = filter_input(INPUT_POST, 'household_id', FILTER_VALIDATE_INT);

        $stmt = $conn->prepare("DELETE FROM household_members WHERE member_id = ?");
        $stmt->bind_param("i", $member_id);
        if ($stmt->execute()) {
            $conn->query("UPDATE households SET members_count = members_count - 1 WHERE household_id = $household_id");
            $_SESSION['toast_message'] = "Member deleted successfully!";
            $_SESSION['toast_type'] = "success";
        } else {
            $_SESSION['toast_message'] = "Error deleting member: " . $stmt->error;
            $_SESSION['toast_type'] = "error";
        }
        $stmt->close();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
}

// Handle document upload
if (isset($_POST['upload_document']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $title = filter_input(INPUT_POST, 'doc_title', FILTER_SANITIZE_STRING);
        $type = filter_input(INPUT_POST, 'doc_type', FILTER_SANITIZE_STRING);
        $description = filter_input(INPUT_POST, 'doc_description', FILTER_SANITIZE_STRING) ?: null;
        $uploaded_by = $_SESSION['user']['id'];
        $status = 'Filed';
        $date_filed = date('Y-m-d');

        $valid_types = ['Barangay Clearance', 'Certificate of Residency', 'Certificate of Indigency', 'Other'];
        if (empty($title) || strlen($title) > 255 || !in_array($type, $valid_types)) {
            $_SESSION['toast_message'] = "Invalid title or document type.";
            $_SESSION['toast_type'] = "error";
        } else {
            $file = $_FILES['doc_file'];
            $allowed_types = ['application/pdf', 'image/jpeg', 'image/png'];
            $upload_dir = 'Uploads/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            $file_name = uniqid() . '_' . basename($file['name']);
            $file_path = $upload_dir . $file_name;

            if (in_array($file['type'], $allowed_types) && $file['size'] <= 5 * 1024 * 1024) {
                if (move_uploaded_file($file['tmp_name'], $file_path)) {
                    $stmt = $conn->prepare("INSERT INTO barangay_documents (title, type, description, file_path, uploaded_by, status, date_filed) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("ssssiss", $title, $type, $description, $file_path, $uploaded_by, $status, $date_filed);
                    if ($stmt->execute()) {
                        $_SESSION['toast_message'] = "Document uploaded successfully!";
                        $_SESSION['toast_type'] = "success";
                    } else {
                        $_SESSION['toast_message'] = "Error uploading document: " . $stmt->error;
                        $_SESSION['toast_type'] = "error";
                        unlink($file_path);
                    }
                    $stmt->close();
                } else {
                    $_SESSION['toast_message'] = "Error moving uploaded file.";
                    $_SESSION['toast_type'] = "error";
                }
            } else {
                $_SESSION['toast_message'] = "Invalid file type or size (max 5MB).";
                $_SESSION['toast_type'] = "error";
            }
        }
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
}

// Handle document update
if (isset($_POST['update_document']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $document_id = filter_input(INPUT_POST, 'document_id', FILTER_VALIDATE_INT);
        $title = filter_input(INPUT_POST, 'doc_title', FILTER_SANITIZE_STRING);
        $type = filter_input(INPUT_POST, 'doc_type', FILTER_SANITIZE_STRING);
        $description = filter_input(INPUT_POST, 'doc_description', FILTER_SANITIZE_STRING) ?: null;
        $status = filter_input(INPUT_POST, 'doc_status', FILTER_SANITIZE_STRING);

        $valid_types = ['Barangay Clearance', 'Certificate of Residency', 'Certificate of Indigency', 'Other'];
        $valid_statuses = ['Filed', 'Processed', 'Archived'];
        if (empty($title) || strlen($title) > 255 || !in_array($type, $valid_types) || !in_array($status, $valid_statuses)) {
            $_SESSION['toast_message'] = "Invalid title, type, or status.";
            $_SESSION['toast_type'] = "error";
        } else {
            $stmt = $conn->prepare("UPDATE barangay_documents SET title = ?, type = ?, description = ?, status = ? WHERE document_id = ?");
            $stmt->bind_param("ssssi", $title, $type, $description, $status, $document_id);
            if ($stmt->execute()) {
                $_SESSION['toast_message'] = "Document updated successfully!";
                $_SESSION['toast_type'] = "success";
            } else {
                $_SESSION['toast_message'] = "Error updating document: " . $stmt->error;
                $_SESSION['toast_type'] = "error";
            }
            $stmt->close();
        }
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
}

// Handle document deletion
if (isset($_POST['delete_document']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $document_id = filter_input(INPUT_POST, 'document_id', FILTER_VALIDATE_INT);
        $stmt = $conn->prepare("SELECT file_path FROM barangay_documents WHERE document_id = ?");
        $stmt->bind_param("i", $document_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $file_path = $row['file_path'];
            $stmt->close();
            $stmt = $conn->prepare("DELETE FROM barangay_documents WHERE document_id = ?");
            $stmt->bind_param("i", $document_id);
            if ($stmt->execute()) {
                if (file_exists($file_path)) {
                    unlink($file_path);
                }
                $_SESSION['toast_message'] = "Document deleted successfully!";
                $_SESSION['toast_type'] = "success";
            } else {
                $_SESSION['toast_message'] = "Error deleting document: " . $stmt->error;
                $_SESSION['toast_type'] = "error";
            }
            $stmt->close();
        } else {
            $_SESSION['toast_message'] = "Document not found.";
            $_SESSION['toast_type'] = "error";
        }
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
}

// Handle certificate generation
if (isset($_POST['generate_certificate']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $resident_full_name = filter_input(INPUT_POST, 'resident_full_name', FILTER_SANITIZE_STRING);
        $resident_age = filter_input(INPUT_POST, 'resident_age', FILTER_VALIDATE_INT);
        $resident_gender = filter_input(INPUT_POST, 'cert_gender', FILTER_SANITIZE_STRING);
        $resident_civil_status = filter_input(INPUT_POST, 'cert_civil_status', FILTER_SANITIZE_STRING);
        $resident_address = filter_input(INPUT_POST, 'cert_address', FILTER_SANITIZE_STRING);
        $purok = filter_input(INPUT_POST, 'cert_purok', FILTER_SANITIZE_STRING);
        $duration_of_residency = filter_input(INPUT_POST, 'cert_duration', FILTER_SANITIZE_STRING);
        $purpose_of_certificate = filter_input(INPUT_POST, 'cert_purpose', FILTER_SANITIZE_STRING);
        $barangay_name = filter_input(INPUT_POST, 'cert_barangay', FILTER_SANITIZE_STRING);
        $municipality = filter_input(INPUT_POST, 'cert_municipality', FILTER_SANITIZE_STRING);
        $province = filter_input(INPUT_POST, 'cert_province', FILTER_SANITIZE_STRING);
        $barangay_captain_name = filter_input(INPUT_POST, 'cert_captain', FILTER_SANITIZE_STRING);
        $barangay_secretary_name = filter_input(INPUT_POST, 'cert_secretary', FILTER_SANITIZE_STRING);
        $barangay_contact_number = filter_input(INPUT_POST, 'cert_contact_number', FILTER_SANITIZE_STRING);
        $barangay_email = filter_input(INPUT_POST, 'cert_email', FILTER_SANITIZE_EMAIL);
        $certificate_type = filter_input(INPUT_POST, 'cert_type', FILTER_SANITIZE_STRING);
        $remarks = filter_input(INPUT_POST, 'cert_remarks', FILTER_SANITIZE_STRING);
        $status = 'Approved';
        $issue_date = date('Y-m-d');
        $created_by = $_SESSION['user']['id'];

        $valid_types = ['Residency', 'Indigency', 'Clearance'];
        if (empty($resident_full_name) || $resident_age === false || empty($resident_gender) || !in_array($certificate_type, $valid_types)) {
            $_SESSION['toast_message'] = "Required fields are missing or invalid.";
            $_SESSION['toast_type'] = "error";
        } else {
            $stmt = $conn->prepare("INSERT INTO certificates (certificate_type, resident_full_name, resident_age, resident_gender, resident_civil_status, resident_address, purok, duration_of_residency, purpose_of_certificate, province, municipality, barangay_name, issue_date, barangay_captain_name, barangay_secretary_name, barangay_contact_number, barangay_email, remarks, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssissssssssssssssssi", $certificate_type, $resident_full_name, $resident_age, $resident_gender, $resident_civil_status, $resident_address, $purok, $duration_of_residency, $purpose_of_certificate, $province, $municipality, $barangay_name, $issue_date, $barangay_captain_name, $barangay_secretary_name, $barangay_contact_number, $barangay_email, $remarks, $status, $created_by);
            if ($stmt->execute()) {
                $certificate_id = $stmt->insert_id;
                $_SESSION['toast_message'] = "Certificate generated successfully!";
                $_SESSION['toast_type'] = "success";
                echo "<script>window.location.href='php/generate_certificate_pdf.php?id=$certificate_id';</script>";
            } else {
                $_SESSION['toast_message'] = "Error generating certificate: " . $stmt->error;
                $_SESSION['toast_type'] = "error";
            }
            $stmt->close();
        }
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
}

// Handle certificate template creation
if (isset($_POST['create_template']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $template_name = filter_input(INPUT_POST, 'template_name', FILTER_SANITIZE_STRING);
        $content = filter_input(INPUT_POST, 'template_content', FILTER_SANITIZE_STRING);
        $created_by = $_SESSION['user']['id'];

        $stmt = $conn->prepare("INSERT INTO certificate_templates (template_name, content, created_by) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $template_name, $content, $created_by);
        if ($stmt->execute()) {
            $_SESSION['toast_message'] = "Template created successfully!";
            $_SESSION['toast_type'] = "success";
        } else {
            $_SESSION['toast_message'] = "Error creating template: " . $stmt->error;
            $_SESSION['toast_type'] = "error";
        }
        $stmt->close();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
}

// Handle announcement creation
if (isset($_POST['create_announcement']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $title = filter_input(INPUT_POST, 'ann_title', FILTER_SANITIZE_STRING);
        $content = filter_input(INPUT_POST, 'ann_content', FILTER_SANITIZE_STRING);
        $is_active = filter_input(INPUT_POST, 'ann_is_active', FILTER_VALIDATE_INT) ? 1 : 0;
        $created_by = $_SESSION['user']['id'];

        $stmt = $conn->prepare("INSERT INTO announcements (title, content, created_by, is_active) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssii", $title, $content, $created_by, $is_active);
        if ($stmt->execute()) {
            $_SESSION['toast_message'] = "Announcement created successfully!";
            $_SESSION['toast_type'] = "success";
        } else {
            $_SESSION['toast_message'] = "Error creating announcement: " . $stmt->error;
            $_SESSION['toast_type'] = "error";
        }
        $stmt->close();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
}

// Handle announcement update
if (isset($_POST['update_announcement']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $announcement_id = filter_input(INPUT_POST, 'announcement_id', FILTER_VALIDATE_INT);
        $title = filter_input(INPUT_POST, 'ann_title', FILTER_SANITIZE_STRING);
        $content = filter_input(INPUT_POST, 'ann_content', FILTER_SANITIZE_STRING);
        $is_active = filter_input(INPUT_POST, 'ann_is_active', FILTER_VALIDATE_INT) ? 1 : 0;

        $stmt = $conn->prepare("UPDATE announcements SET title = ?, content = ?, is_active = ? WHERE id = ?");
        $stmt->bind_param("ssii", $title, $content, $is_active, $announcement_id);
        if ($stmt->execute()) {
            $_SESSION['toast_message'] = "Announcement updated successfully!";
            $_SESSION['toast_type'] = "success";
        } else {
            $_SESSION['toast_message'] = "Error updating announcement: " . $stmt->error;
            $_SESSION['toast_type'] = "error";
        }
        $stmt->close();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
}

// Handle announcement deletion
if (isset($_POST['delete_announcement']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $announcement_id = filter_input(INPUT_POST, 'announcement_id', FILTER_VALIDATE_INT);
        $stmt = $conn->prepare("DELETE FROM announcements WHERE id = ?");
        $stmt->bind_param("i", $announcement_id);
        if ($stmt->execute()) {
            $_SESSION['toast_message'] = "Announcement deleted successfully!";
            $_SESSION['toast_type'] = "success";
        } else {
            $_SESSION['toast_message'] = "Error deleting announcement: " . $stmt->error;
            $_SESSION['toast_type'] = "error";
        }
        $stmt->close();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
}

// Handle user settings update
if (isset($_POST['update_settings']) && isset($_POST['csrf_token'])) {
    if (validate_csrf_token($_POST['csrf_token'])) {
        $user_id = $_SESSION['user']['id'];
        $first_name = filter_input(INPUT_POST, 'first_name', FILTER_SANITIZE_STRING);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

        $updates = [];
        $params = [];
        $types = '';

        if (!empty($first_name)) {
            $updates[] = "first_name = ?";
            $params[] = $first_name;
            $types .= 's';
        }
        if (!empty($email)) {
            $updates[] = "email = ?";
            $params[] = $email;
            $types .= 's';
        }
        if (!empty($password)) {
            $updates[] = "password = ?";
            $params[] = password_hash($password, PASSWORD_DEFAULT);
            $types .= 's';
        }

        if (!empty($updates)) {
            $params[] = $user_id;
            $types .= 'i';
            $stmt = $conn->prepare("UPDATE barangay_users SET " . implode(', ', $updates) . " WHERE id = ?");
            $stmt->bind_param($types, ...$params);
            if ($stmt->execute()) {
                $_SESSION['toast_message'] = "Profile updated successfully!";
                $_SESSION['toast_type'] = "success";
                $_SESSION['user']['first_name'] = $first_name ?: $_SESSION['user']['first_name'];
                $_SESSION['user']['email'] = $email ?: $_SESSION['user']['email'];
            } else {
                $_SESSION['toast_message'] = "Error updating profile: " . $stmt->error;
                $_SESSION['toast_type'] = "error";
            }
            $stmt->close();
        } else {
            $_SESSION['toast_message'] = "No changes provided.";
            $_SESSION['toast_type'] = "error";
        }
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['toast_message'] = "Invalid CSRF token.";
        $_SESSION['toast_type'] = "error";
    }
}

// Fetch data
$analytics = ['households' => 0, 'documents_month' => 0, 'certificates_month' => 0, 'announcements_active' => 0];
$households = $documents = $certificates = $members = $announcements = $templates = null;

try {
    $analytics['households'] = $conn->query("SELECT COUNT(*) FROM households")->fetch_row()[0];
    $analytics['documents_month'] = $conn->query("SELECT COUNT(*) FROM barangay_documents WHERE MONTH(date_filed) = MONTH(CURDATE()) AND YEAR(date_filed) = YEAR(CURDATE())")->fetch_row()[0];
    $analytics['certificates_month'] = $conn->query("SELECT COUNT(*) FROM certificates WHERE MONTH(issue_date) = MONTH(CURDATE()) AND YEAR(issue_date) = YEAR(CURDATE())")->fetch_row()[0];
    $analytics['announcements_active'] = $conn->query("SELECT COUNT(*) FROM announcements WHERE is_active = 1")->fetch_row()[0];

    $households = $conn->query("SELECT * FROM households ORDER BY household_name LIMIT 50");
    $documents = $conn->query("SELECT bd.*, bu.first_name FROM barangay_documents bd JOIN barangay_users bu ON bd.uploaded_by = bu.id ORDER BY bd.date_filed DESC LIMIT 20");
    $certificates = $conn->query("SELECT c.*, bu.first_name FROM certificates c JOIN barangay_users bu ON c.created_by = bu.id ORDER BY c.issue_date DESC LIMIT 20");
    $members = $conn->query("SELECT hm.*, h.household_name FROM household_members hm JOIN households h ON hm.household_id = h.household_id ORDER BY hm.created_at DESC LIMIT 20");
    $announcements = $conn->query("SELECT a.*, bu.first_name FROM announcements a JOIN barangay_users bu ON a.created_by = bu.id ORDER BY a.created_at DESC LIMIT 20");
    $templates = $conn->query("SELECT * FROM certificate_templates ORDER BY created_at DESC LIMIT 20");
} catch (Exception $e) {
    error_log("Query error: " . $e->getMessage());
    $_SESSION['toast_message'] = "Error loading data: " . $e->getMessage();
    $_SESSION['toast_type'] = "error";
}

// Fetch household options for modals
$household_options = $conn->query("SELECT household_id, household_name FROM households ORDER BY household_name");

// Get secretary's name
$secretary_id = $_SESSION['user']['id'];
$secretary_query = $conn->prepare("SELECT first_name, email FROM barangay_users WHERE id = ? LIMIT 1");
$secretary_query->bind_param("i", $secretary_id);
$secretary_query->execute();
$secretary_result = $secretary_query->get_result();
$secretary = $secretary_result->num_rows > 0 ? $secretary_result->fetch_assoc() : ['first_name' => 'Secretary', 'email' => ''];
$secretary_name = $secretary['first_name'];
$secretary_email = $secretary['email'];
$secretary_query->close();

// Toast message
$toast_message = $_SESSION['toast_message'] ?? '';
$toast_type = $_SESSION['toast_type'] ?? '';
unset($_SESSION['toast_message'], $_SESSION['toast_type']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Barangay Secretary Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/secretary.css">
</head>
<body>
    <div class="mobile-toggle" aria-label="Toggle sidebar">
        <i class="fas fa-bars"></i> Menu
    </div>

    <div class="sidebar" role="navigation">
        <div class="sidebar-header">
            <div class="logo-container">
                <img src="images/1.png" alt="Barangay Logo" class="logo">
                <div class="admin-name"><?php echo htmlspecialchars($secretary_name); ?></div>
                <div class="admin-role">Barangay Secretary</div>
            </div>
        </div>
        <div class="menu">
            <div class="menu-category">DASHBOARD</div>
            <a href="#" class="menu-item <?php echo $active_tab === 'overview' ? 'active' : ''; ?>" data-target="overview">
                <i class="fas fa-tachometer-alt"></i><span>Overview</span>
            </a>
            <div class="menu-category">MANAGEMENT</div>
            <a href="#" class="menu-item <?php echo $active_tab === 'households' ? 'active' : ''; ?>" data-target="households">
                <i class="fas fa-house-user"></i><span>Households</span>
            </a>
            <a href="#" class="menu-item <?php echo $active_tab === 'members' ? 'active' : ''; ?>" data-target="members">
                <i class="fas fa-users"></i><span>Members</span>
            </a>
            <a href="#" class="menu-item <?php echo $active_tab === 'documents' ? 'active' : ''; ?>" data-target="documents">
                <i class="fas fa-file-alt"></i><span>Documents</span>
            </a>
            <a href="#" class="menu-item <?php echo $active_tab === 'certificates' ? 'active' : ''; ?>" data-target="certificates">
                <i class="fas fa-certificate"></i><span>Certificates</span>
            </a>
            <a href="#" class="menu-item <?php echo $active_tab === 'announcements' ? 'active' : ''; ?>" data-target="announcements">
                <i class="fas fa-bullhorn"></i><span>Announcements</span>
            </a>
            <div class="menu-category">SETTINGS</div>
            <a href="#" class="menu-item <?php echo $active_tab === 'settings' ? 'active' : ''; ?>" data-target="settings">
                <i class="fas fa-cog"></i><span>Settings</span>
            </a>
            <a href="php/logout.php" class="menu-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
        </div>
    </div>

    <div class="main-content" role="main">
        <div class="dashboard-header">
            <div class="dashboard-header-left">
                <h1 class="page-title"><i class="fas fa-tachometer-alt"></i> Barangay Secretary Dashboard</h1>
                <div class="dashboard-header-subtitle">
                    Welcome back, <?php echo htmlspecialchars($secretary_name); ?>! Today is <?php echo date('F j, Y'); ?>
                </div>
            </div>
            <a href="php/logout.php" class="logout-btn" aria-label="Logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>

        <div class="tab-container">
            <div class="tab-nav">
                <div class="tab-nav-item <?php echo $active_tab === 'overview' ? 'active' : ''; ?>" data-target="overview">Overview</div>
                <div class="tab-nav-item <?php echo $active_tab === 'households' ? 'active' : ''; ?>" data-target="households">Households</div>
                <div class="tab-nav-item <?php echo $active_tab === 'members' ? 'active' : ''; ?>" data-target="members">Members</div>
                <div class="tab-nav-item <?php echo $active_tab === 'documents' ? 'active' : ''; ?>" data-target="documents">Documents</div>
                <div class="tab-nav-item <?php echo $active_tab === 'certificates' ? 'active' : ''; ?>" data-target="certificates">Certificates</div>
                <div class="tab-nav-item <?php echo $active_tab === 'announcements' ? 'active' : ''; ?>" data-target="announcements">Announcements</div>
                <div class="tab-nav-item <?php echo $active_tab === 'settings' ? 'active' : ''; ?>" data-target="settings">Settings</div>
            </div>

            <!-- Overview Tab -->
            <div id="overview" class="tab-content <?php echo $active_tab === 'overview' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title"><i class="fas fa-tachometer-alt"></i> Dashboard Overview</h2>
                    </div>
                    <div class="card-body">
                        <div class="stats-container">
                            <div class="stat-card">
                                <i class="fas fa-house-user stat-icon"></i>
                                <div class="stat-value"><?php echo $analytics['households']; ?></div>
                                <div class="stat-label">TOTAL HOUSEHOLDS</div>
                            </div>
                            <div class="stat-card">
                                <i class="fas fa-file-alt stat-icon"></i>
                                <div class="stat-value"><?php echo $analytics['documents_month']; ?></div>
                                <div class="stat-label">DOCUMENTS THIS MONTH</div>
                            </div>
                            <div class="stat-card">
                                <i class="fas fa-certificate stat-icon"></i>
                                <div class="stat-value"><?php echo $analytics['certificates_month']; ?></div>
                                <div class="stat-label">CERTIFICATES ISSUED</div>
                            </div>
                            <div class="stat-card">
                                <i class="fas fa-bullhorn stat-icon"></i>
                                <div class="stat-value"><?php echo $analytics['announcements_active']; ?></div>
                                <div class="stat-label">ACTIVE ANNOUNCEMENTS</div>
                            </div>
                        </div>
                        <h3 style="margin-top: 15px; color: var(--primary);">Monthly Activity</h3>
                        <div class="chart-container">
                            <canvas id="analyticsChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Households Tab -->
            <div id="households" class="tab-content <?php echo $active_tab === 'households' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title"><i class="fas fa-house-user"></i> Registered Households</h2>
                        <div class="quick-actions">
                            <input type="text" class="form-control-full" id="householdSearch" placeholder="Search by household name or head..." aria-label="Search households">
                            <button class="btn btn-primary btn-sm" id="addHouseholdBtn"><i class="fas fa-plus"></i> Add New Household</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="household-list" id="householdList">
                            <?php if ($households && $households->num_rows > 0): ?>
                                <?php while ($household = $households->fetch_assoc()): ?>
                                    <div class="household-card" data-id="<?php echo $household['household_id']; ?>">
                                        <div class="household-info">
                                            <h3><?php echo htmlspecialchars($household['household_name']); ?></h3>
                                            <p><strong>Head:</strong> <?php echo htmlspecialchars($household['head_of_family']); ?></p>
                                            <p><strong>Members:</strong> <?php echo htmlspecialchars($household['members_count']); ?> | <strong>Status:</strong> <span class="badge badge-<?php echo ($household['status'] === 'Active') ? 'success' : 'warning'; ?>"><?php echo htmlspecialchars($household['status']); ?></span></p>
                                            <p><strong>Registered:</strong> <?php echo date('M d, Y', strtotime($household['registration_date'])); ?></p>
                                            <p><strong>Address:</strong> <?php echo htmlspecialchars($household['address']); ?></p>
                                            <p><strong>Contact:</strong> <?php echo htmlspecialchars($household['contact_number'] ?: 'N/A'); ?> | <strong>Email:</strong> <?php echo htmlspecialchars($household['email'] ?: 'N/A'); ?></p>
                                        </div>
                                        <div class="household-actions">
                                            <button class="btn btn-primary btn-sm view-household" data-id="<?php echo $household['household_id']; ?>"><i class="fas fa-eye"></i> View</button>
                                            <button class="btn btn-warning btn-sm edit-household" data-id="<?php echo $household['household_id']; ?>"><i class="fas fa-edit"></i> Edit</button>
                                            <button class="btn btn-danger btn-sm delete-household" data-id="<?php echo $household['household_id']; ?>"><i class="fas fa-trash"></i> Delete</button>
                                            <button class="btn btn-warning btn-sm add-member" data-id="<?php echo $household['household_id']; ?>" data-name="<?php echo htmlspecialchars($household['household_name']); ?>"><i class="fas fa-user-plus"></i> Add Member</button>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p>No households found.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Members Tab -->
            <div id="members" class="tab-content <?php echo $active_tab === 'members' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title"><i class="fas fa-users"></i> Household Members</h2>
                        <div class="quick-actions">
                            <input type="text" class="form-control-full" id="memberSearch" placeholder="Search by name or household..." aria-label="Search members">
                            <select class="form-control-full" id="memberFilterGender" aria-label="Filter by gender">
                                <option value="">All Genders</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                            <button class="btn btn-primary btn-sm" id="addMemberBtn"><i class="fas fa-plus"></i> Add New Member</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" id="memberTable" aria-describedby="Household Members">
                                <thead>
                                    <tr>
                                        <th scope="col">Full Name</th>
                                        <th scope="col">Household</th>
                                        <th scope="col">Birth Date</th>
                                        <th scope="col">Age</th>
                                        <th scope="col">Gender</th>
                                        <th scope="col">Relationship</th>
                                        <th scope="col">Occupation</th>
                                        <th scope="col">Education</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($members && $members->num_rows > 0): ?>
                                        <?php while ($row = $members->fetch_assoc()): ?>
                                            <tr data-id="<?php echo $row['member_id']; ?>">
                                                <td><?php echo htmlspecialchars($row['fullname']); ?></td>
                                                <td><?php echo htmlspecialchars($row['household_name']); ?></td>
                                                <td><?php echo date('M d, Y', strtotime($row['birthdate'])); ?></td>
                                                <td><?php echo htmlspecialchars($row['age']); ?></td>
                                                <td><?php echo htmlspecialchars($row['gender']); ?></td>
                                                <td><?php echo htmlspecialchars($row['relationship']); ?></td>
                                                <td><?php echo htmlspecialchars($row['occupation'] ?: 'N/A'); ?></td>
                                                <td><?php echo htmlspecialchars($row['education_level'] ?: 'N/A'); ?></td>
                                                <td>
                                                    <button class="btn btn-primary btn-sm view-member" data-id="<?php echo $row['member_id']; ?>"><i class="fas fa-eye"></i> View</button>
                                                    <button class="btn btn-warning btn-sm edit-member" data-id="<?php echo $row['member_id']; ?>" data-household-id="<?php echo $row['household_id']; ?>"><i class="fas fa-edit"></i> Edit</button>
                                                    <button class="btn btn-danger btn-sm delete-member" data-id="<?php echo $row['member_id']; ?>" data-household-id="<?php echo $row['household_id']; ?>"><i class="fas fa-trash"></i> Delete</button>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr><td colspan="9" class="text-center">No members found.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Documents Tab -->
            <div id="documents" class="tab-content <?php echo $active_tab === 'documents' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title"><i class="fas fa-file-alt"></i> Barangay Documents</h2>
                        <div class="quick-actions">
                            <input type="text" class="form-control-full" id="documentSearch" placeholder="Search documents..." aria-label="Search documents">
                            <button class="btn btn-primary btn-sm" id="uploadDocumentBtn"><i class="fas fa-upload"></i> Upload Document</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" id="documentTable" aria-describedby="Barangay Documents">
                                <thead>
                                    <tr>
                                        <th scope="col">Title</th>
                                        <th scope="col">Type</th>
                                        <th scope="col">Description</th>
                                        <th scope="col">Uploaded By</th>
                                        <th scope="col">Date Filed</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($documents && $documents->num_rows > 0): ?>
                                        <?php while ($row = $documents->fetch_assoc()): ?>
                                            <tr data-id="<?php echo $row['document_id']; ?>" data-title="<?php echo htmlspecialchars($row['title']); ?>" data-type="<?php echo htmlspecialchars($row['type']); ?>" data-description="<?php echo htmlspecialchars($row['description']); ?>" data-file-path="<?php echo htmlspecialchars($row['file_path']); ?>">
                                                <td><?php echo htmlspecialchars($row['title']); ?></td>
                                                <td><?php echo htmlspecialchars($row['type']); ?></td>
                                                <td><?php echo htmlspecialchars($row['description'] ?: 'N/A'); ?></td>
                                                <td><?php echo htmlspecialchars($row['first_name']); ?></td>
                                                <td><?php echo date('M d, Y', strtotime($row['date_filed'])); ?></td>
                                                <td><span class="badge badge-<?php echo $row['status'] === 'Processed' ? 'success' : ($row['status'] === 'Filed' ? 'warning' : 'danger'); ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                                                <td>
                                                    <button class="btn btn-primary btn-sm view-document" data-id="<?php echo $row['document_id']; ?>"><i class="fas fa-eye"></i> View</button>
                                                    <button class="btn btn-warning btn-sm edit-document" data-id="<?php echo $row['document_id']; ?>"><i class="fas fa-edit"></i> Edit</button>
                                                    <button class="btn btn-danger btn-sm delete-document" data-id="<?php echo $row['document_id']; ?>"><i class="fas fa-trash"></i> Delete</button>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr><td colspan="7" class="text-center">No documents found.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Certificates Tab -->
            <div id="certificates" class="tab-content <?php echo $active_tab === 'certificates' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title"><i class="fas fa-certificate"></i> Issued Certificates</h2>
                        <div class="quick-actions">
                            <button class="btn btn-primary btn-sm" id="generateCertificateBtn"><i class="fas fa-plus"></i> Generate Certificate</button>
                            <button class="btn btn-primary btn-sm" id="createTemplateBtn"><i class="fas fa-file-alt"></i> Create Template</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" id="certificateTable" aria-describedby="Issued Certificates">
                                <thead>
                                    <tr>
                                        <th scope="col">Resident Name</th>
                                        <th scope="col">Certificate Type</th>
                                        <th scope="col">Issue Date</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($certificates && $certificates->num_rows > 0): ?>
                                        <?php while ($row = $certificates->fetch_assoc()): ?>
                                            <tr data-id="<?php echo $row['certificate_id']; ?>">
                                                <td><?php echo htmlspecialchars($row['resident_full_name']); ?></td>
                                                <td><?php echo htmlspecialchars($row['certificate_type']); ?></td>
                                                <td><?php echo date('M d, Y', strtotime($row['issue_date'])); ?></td>
                                                <td><span class="badge badge-<?php echo $row['status'] === 'Approved' ? 'success' : 'warning'; ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                                                <td>
                                                    <button class="btn btn-primary btn-sm view-certificate" data-id="<?php echo $row['certificate_id']; ?>"><i class="fas fa-eye"></i> View</button>
                                                    <button class="btn btn-success btn-sm print-certificate" data-id="<?php echo $row['certificate_id']; ?>"><i class="fas fa-print"></i> Print</button>
                                                    <button class="btn btn-info btn-sm qrcode-certificate" data-id="<?php echo $row['certificate_id']; ?>"><i class="fas fa-qrcode"></i> QR Code</button>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr><td colspan="5" class="text-center">No certificates found.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <h3 style="margin-top: 15px;">Certificate Templates</h3>
                        <div class="table-responsive">
                            <table class="table" id="templateTable" aria-describedby="Certificate Templates">
                                <thead>
                                    <tr>
                                        <th scope="col">Template Name</th>
                                        <th scope="col">Created By</th>
                                        <th scope="col">Created At</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($templates && $templates->num_rows > 0): ?>
                                        <?php while ($row = $templates->fetch_assoc()): ?>
                                            <tr data-id="<?php echo $row['id']; ?>" data-name="<?php echo htmlspecialchars($row['template_name']); ?>" data-content="<?php echo htmlspecialchars($row['content']); ?>">
                                                <td><?php echo htmlspecialchars($row['template_name']); ?></td>
                                                <td><?php echo htmlspecialchars($secretary_name); ?></td>
                                                <td><?php echo date('M d, Y', strtotime($row['created_at'])); ?></td>
                                                <td>
                                                    <button class="btn btn-primary btn-sm view-template" data-id="<?php echo $row['id']; ?>"><i class="fas fa-eye"></i> View</button>
                                                    <button class="btn btn-warning btn-sm edit-template" data-id="<?php echo $row['id']; ?>"><i class="fas fa-edit"></i> Edit</button>
                                                    <button class="btn btn-danger btn-sm delete-template" data-id="<?php echo $row['id']; ?>"><i class="fas fa-trash"></i> Delete</button>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr><td colspan="4" class="text-center">No templates found.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Announcements Tab -->
            <div id="announcements" class="tab-content <?php echo $active_tab === 'announcements' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title"><i class="fas fa-bullhorn"></i> Announcements</h2>
                        <div class="quick-actions">
                            <input type="text" class="form-control-full" id="announcementSearch" placeholder="Search announcements..." aria-label="Search announcements">
                            <button class="btn btn-primary btn-sm" id="createAnnouncementBtn"><i class="fas fa-plus"></i> Create Announcement</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" id="announcementTable" aria-describedby="Announcements">
                                <thead>
                                    <tr>
                                        <th scope="col">Title</th>
                                        <th scope="col">Content</th>
                                        <th scope="col">Created By</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($announcements && $announcements->num_rows > 0): ?>
                                        <?php while ($row = $announcements->fetch_assoc()): ?>
                                            <tr data-id="<?php echo $row['id']; ?>" data-title="<?php echo htmlspecialchars($row['title']); ?>" data-content="<?php echo htmlspecialchars($row['content']); ?>" data-is-active="<?php echo $row['is_active']; ?>">
                                                <td><?php echo htmlspecialchars($row['title']); ?></td>
                                                <td><?php echo htmlspecialchars(substr($row['content'], 0, 50)); ?>...</td>
                                                <td><?php echo htmlspecialchars($row['first_name']); ?></td>
                                                <td><span class="badge badge-<?php echo $row['is_active'] ? 'success' : 'warning'; ?>"><?php echo $row['is_active'] ? 'Active' : 'Inactive'; ?></span></td>
                                                <td>
                                                    <button class="btn btn-primary btn-sm view-announcement" data-id="<?php echo $row['id']; ?>"><i class="fas fa-eye"></i> View</button>
                                                    <button class="btn btn-warning btn-sm edit-announcement" data-id="<?php echo $row['id']; ?>"><i class="fas fa-edit"></i> Edit</button>
                                                    <button class="btn btn-danger btn-sm delete-announcement" data-id="<?php echo $row['id']; ?>"><i class="fas fa-trash"></i> Delete</button>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr><td colspan="5" class="text-center">No announcements found.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Settings Tab -->
            <div id="settings" class="tab-content <?php echo $active_tab === 'settings' ? 'active' : ''; ?>">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title"><i class="fas fa-cog"></i> User Settings</h2>
                    </div>
                    <div class="card-body">
                        <form id="settingsForm" action="" method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                            <input type="hidden" name="update_settings" value="1">
                            <div class="form-group">
                                <label for="first_name">Full Name</label>
                                <input type="text" class="form-control-full" id="first_name" name="first_name" value="<?php echo htmlspecialchars($secretary_name); ?>">
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control-full" id="email" name="email" value="<?php echo htmlspecialchars($secretary_email); ?>">
                            </div>
                            <div class="form-group">
                                <label for="password">New Password (leave blank to keep current)</label>
                                <input type="password" class="form-control-full" id="password" name="password">
                            </div>
                            <div class="button-group">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Household Modal -->
    <div id="addHouseholdModal" class="modal" role="dialog" aria-labelledby="addHouseholdModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="addHouseholdModalLabel">Add New Household</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="addHouseholdForm" action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="add_household" value="1">
                <div class="form-row">
                    <div class="form-group">
                        <label for="household_name">Household Name</label>
                        <input type="text" class="form-control-full" id="household_name" name="household_name" required>
                    </div>
                    <div class="form-group">
                        <label for="head_of_family">Head of Family</label>
                        <input type="text" class="form-control-full" id="head_of_family" name="head_of_family" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea class="form-control-full" id="address" name="address" rows="3" required></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="members_count">Number of Members</label>
                        <input type="number" class="form-control-full" id="members_count" name="members_count" min="0" value="0">
                    </div>
                    <div class="form-group">
                        <label for="contact_number">Contact Number</label>
                        <input type="text" class="form-control-full" id="contact_number" name="contact_number">
                    </div>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control-full" id="email" name="email">
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Household Modal -->
    <div id="editHouseholdModal" class="modal" role="dialog" aria-labelledby="editHouseholdModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="editHouseholdModalLabel">Edit Household</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="editHouseholdForm" action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="update_household" value="1">
                <input type="hidden" name="household_id" id="edit_household_id">
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_household_name">Household Name</label>
                        <input type="text" class="form-control-full" id="edit_household_name" name="household_name" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_head_of_family">Head of Family</label>
                        <input type="text" class="form-control-full" id="edit_head_of_family" name="head_of_family" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="edit_address">Address</label>
                    <textarea class="form-control-full" id="edit_address" name="address" rows="3" required></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_members_count">Number of Members</label>
                        <input type="number" class="form-control-full" id="edit_members_count" name="members_count" min="0" value="0">
                    </div>
                    <div class="form-group">
                        <label for="edit_contact_number">Contact Number</label>
                        <input type="text" class="form-control-full" id="edit_contact_number" name="contact_number">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_email">Email</label>
                        <input type="email" class="form-control-full" id="edit_email" name="email">
                    </div>
                    <div class="form-group">
                        <label for="edit_status">Status</label>
                        <select class="form-control-full" id="edit_status" name="status" required>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Household Modal -->
    <div id="deleteHouseholdModal" class="modal" role="dialog" aria-labelledby="deleteHouseholdModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="deleteHouseholdModalLabel">Delete Household</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="deleteHouseholdForm" action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="delete_household" value="1">
                <input type="hidden" name="household_id" id="delete_household_id">
                <div class="modal-body">
                    <p>Are you sure you want to delete this household?</p>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Household Modal -->
    <div id="viewHouseholdModal" class="modal" role="dialog" aria-labelledby="viewHouseholdModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="viewHouseholdModalLabel">Household Details</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <div class="modal-body" id="householdDetails">
                <p>Loading...</p>
            </div>
            <div class="button-group">
                <button type="button" class="btn btn-secondary modal-close">Close</button>
            </div>
        </div>
    </div>

    <!-- Add Member Modal -->
    <div id="addMemberModal" class="modal" role="dialog" aria-labelledby="addMemberModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="addMemberModalLabel">Add New Member</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="addMemberForm" action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="add_member" value="1">
                <input type="hidden" name="modal_household_id" id="modal_household_id">
                <div class="form-group">
                    <label for="household_select">Household</label>
                    <select class="form-control-full" id="household_select" name="modal_household_id" required>
                        <option value="">Select Household</option>
                        <?php while ($h = $household_options->fetch_assoc()): ?>
                            <option value="<?php echo $h['household_id']; ?>"><?php echo htmlspecialchars($h['household_name']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="member_fullname">Full Name</label>
                        <input type="text" class="form-control-full" id="member_fullname" name="member_fullname" required>
                    </div>
                    <div class="form-group">
                        <label for="member_birthdate">Birth Date</label>
                        <input type="date" class="form-control-full" id="member_birthdate" name="member_birthdate" required>
                    </div>
                    <div class="form-group">
                        <label for="member_age">Age</label>
                        <input type="number" class="form-control-full" id="member_age" name="member_age" min="0" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="member_gender">Gender</label>
                        <select class="form-control-full" id="member_gender" name="member_gender" required>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="member_relationship">Relationship to Head</label>
                        <input type="text" class="form-control-full" id="member_relationship" name="member_relationship" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="member_occupation">Occupation</label>
                        <input type="text" class="form-control-full" id="member_occupation" name="member_occupation">
                    </div>
                    <div class="form-group">
                        <label for="member_education">Education Level</label>
                        <input type="text" class="form-control-full" id="member_education" name="member_education">
                    </div>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Member Modal -->
    <div id="editMemberModal" class="modal" role="dialog" aria-labelledby="editMemberModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="editMemberModalLabel">Edit Member</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="editMemberForm" action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="update_member" value="1">
                <input type="hidden" name="member_id" id="edit_member_id">
                <div class="form-group">
                    <label for="edit_household_select">Household</label>
                    <select class="form-control-full" id="edit_household_select" name="household_id" required>
                        <option value="">Select Household</option>
                        <?php
                        $household_options->data_seek(0);
                        while ($h = $household_options->fetch_assoc()): ?>
                            <option value="<?php echo $h['household_id']; ?>"><?php echo htmlspecialchars($h['household_name']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_member_fullname">Full Name</label>
                        <input type="text" class="form-control-full" id="edit_member_fullname" name="member_fullname" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_member_birthdate">Birth Date</label>
                        <input type="date" class="form-control-full" id="edit_member_birthdate" name="member_birthdate" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_member_age">Age</label>
                        <input type="number" class="form-control-full" id="edit_member_age" name="member_age" min="0" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_member_gender">Gender</label>
                        <select class="form-control-full" id="edit_member_gender" name="member_gender" required>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="edit_member_relationship">Relationship to Head</label>
                        <input type="text" class="form-control-full" id="edit_member_relationship" name="member_relationship" required>
                        </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_member_occupation">Occupation</label>
                        <input type="text" class="form-control-full" id="edit_member_occupation" name="member_occupation">
                    </div>
                    <div class="form-group">
                        <label for="edit_member_education">Education Level</label>
                        <input type="text" class="form-control-full" id="edit_member_education" name="member_education">
                    </div>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Member Modal -->
    <div id="viewMemberModal" class="modal" role="dialog" aria-labelledby="viewMemberModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="viewMemberModalLabel">Member Details</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <div class="modal-body" id="memberDetails">
                <p>Loading...</p>
            </div>
            <div class="button-group">
                <button type="button" class="btn btn-secondary modal-close">Close</button>
            </div>
        </div>
    </div>

    <!-- Delete Member Modal -->
    <div id="deleteMemberModal" class="modal" role="dialog" aria-labelledby="deleteMemberModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="deleteMemberModalLabel">Delete Member</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="deleteMemberForm" action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="delete_member" value="1">
                <input type="hidden" name="member_id" id="delete_member_id">
                <input type="hidden" name="household_id" id="delete_member_household_id">
                <div class="modal-body">
                    <p>Are you sure you want to delete this member?</p>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Upload Document Modal -->
    <div id="uploadDocumentModal" class="modal" role="dialog" aria-labelledby="uploadDocumentModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="uploadDocumentModalLabel">Upload Document</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="uploadDocumentForm" action="" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="upload_document" value="1">
                <div class="form-group">
                    <label for="doc_title">Document Title</label>
                    <input type="text" class="form-control-full" id="doc_title" name="doc_title" required>
                </div>
                <div class="form-group">
                    <label for="doc_type">Document Type</label>
                    <select class="form-control-full" id="doc_type" name="doc_type" required>
                        <option value="Barangay Clearance">Barangay Clearance</option>
                        <option value="Certificate of Residency">Certificate of Residency</option>
                        <option value="Certificate of Indigency">Certificate of Indigency</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="doc_description">Description</label>
                    <textarea class="form-control-full" id="doc_description" name="doc_description" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label for="doc_file">Upload File</label>
                    <input type="file" class="form-control-full" id="doc_file" name="doc_file" accept=".pdf,.jpg,.jpeg,.png" required>
                    <small class="form-text">Max 5MB. Allowed: PDF, JPG, PNG.</small>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Upload</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Document Modal -->
    <div id="editDocumentModal" class="modal" role="dialog" aria-labelledby="editDocumentModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="editDocumentModalLabel">Edit Document</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="editDocumentForm" action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="update_document" value="1">
                <input type="hidden" name="document_id" id="edit_document_id">
                <div class="form-group">
                    <label for="edit_doc_title">Document Title</label>
                    <input type="text" class="form-control-full" id="edit_doc_title" name="doc_title" required>
                </div>
                <div class="form-group">
                    <label for="edit_doc_type">Document Type</label>
                    <select class="form-control-full" id="edit_doc_type" name="doc_type" required>
                        <option value="Barangay Clearance">Barangay Clearance</option>
                        <option value="Certificate of Residency">Certificate of Residency</option>
                        <option value="Certificate of Indigency">Certificate of Indigency</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="edit_doc_description">Description</label>
                    <textarea class="form-control-full" id="edit_doc_description" name="doc_description" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label for="edit_doc_status">Status</label>
                    <select class="form-control-full" id="edit_doc_status" name="doc_status" required>
                        <option value="Filed">Filed</option>
                        <option value="Processed">Processed</option>
                        <option value="Archived">Archived</option>
                    </select>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Document Modal -->
    <div id="deleteDocumentModal" class="modal" role="dialog" aria-labelledby="deleteDocumentModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="deleteDocumentModalLabel">Delete Document</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="deleteDocumentForm" action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="delete_document" value="1">
                <input type="hidden" name="document_id" id="delete_document_id">
                <div class="modal-body">
                    <p>Are you sure you want to delete this document?</p>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Document Modal -->
    <div id="viewDocumentModal" class="modal" role="dialog" aria-labelledby="viewDocumentModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="viewDocumentModalLabel">Document Details</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <div class="modal-body" id="documentDetails">
                <p>Loading...</p>
            </div>
            <div class="button-group">
                <button type="button" class="btn btn-secondary modal-close">Close</button>
            </div>
        </div>
    </div>

    <!-- Generate Certificate Modal -->
    <div id="generateCertificateModal" class="modal" role="dialog" aria-labelledby="generateCertificateModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="generateCertificateModalLabel">Generate Certificate</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="generateCertificateForm" action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="generate_certificate" value="1">
                <div class="form-group">
                    <label for="cert_type">Certificate Type</label>
                    <select class="form-control-full" id="cert_type" name="cert_type" required>
                        <option value="Residency">Certificate of Residency</option>
                        <option value="Indigency">Certificate of Indigency</option>
                        <option value="Clearance">Barangay Clearance</option>
                    </select>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="resident_full_name">Resident Full Name</label>
                        <input type="text" class="form-control-full" id="resident_full_name" name="resident_full_name" required>
                    </div>
                    <div class="form-group">
                        <label for="resident_age">Age</label>
                        <input type="number" class="form-control-full" id="resident_age" name="resident_age" min="0" required>
                    </div>
                    <div class="form-group">
                        <label for="cert_gender">Gender</label>
                        <select class="form-control-full" id="cert_gender" name="cert_gender" required>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="cert_civil_status">Civil Status</label>
                        <select class="form-control-full" id="cert_civil_status" name="cert_civil_status" required>
                            <option value="Single">Single</option>
                            <option value="Married">Married</option>
                            <option value="Widowed">Widowed</option>
                            <option value="Divorced">Divorced</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="cert_address">Address</label>
                        <input type="text" class="form-control-full" id="cert_address" name="cert_address" required>
                    </div>
                    <div class="form-group">
                        <label for="cert_purok">Purok</label>
                        <input type="text" class="form-control-full" id="cert_purok" name="cert_purok">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="cert_duration">Duration of Residency</label>
                        <input type="text" class="form-control-full" id="cert_duration" name="cert_duration">
                    </div>
                    <div class="form-group">
                        <label for="cert_purpose">Purpose of Certificate</label>
                        <input type="text" class="form-control-full" id="cert_purpose" name="cert_purpose" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="cert_barangay">Barangay Name</label>
                    <input type="text" class="form-control-full" id="cert_barangay" name="cert_barangay" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="cert_municipality">Municipality</label>
                        <input type="text" class="form-control-full" id="cert_municipality" name="cert_municipality" required>
                    </div>
                    <div class="form-group">
                        <label for="cert_province">Province</label>
                        <input type="text" class="form-control-full" id="cert_province" name="cert_province" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="cert_captain">Barangay Captain Name</label>
                        <input type="text" class="form-control-full" id="cert_captain" name="cert_captain" required>
                    </div>
                    <div class="form-group">
                        <label for="cert_secretary">Barangay Secretary Name</label>
                        <input type="text" class="form-control-full" id="cert_secretary" name="cert_secretary" value="<?php echo htmlspecialchars($secretary_name); ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="cert_contact_number">Barangay Contact Number</label>
                        <input type="text" class="form-control-full" id="cert_contact_number" name="cert_contact_number">
                    </div>
                    <div class="form-group">
                        <label for="cert_email">Barangay Email</label>
                        <input type="email" class="form-control-full" id="cert_email" name="cert_email" value="<?php echo htmlspecialchars($secretary_email); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="cert_remarks">Remarks</label>
                    <textarea class="form-control-full" id="cert_remarks" name="cert_remarks" rows="3"></textarea>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Generate</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Create Template Modal -->
    <div id="createTemplateModal" class="modal" role="dialog" aria-labelledby="createTemplateModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="createTemplateModalLabel">Create Certificate Template</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="createTemplateForm" action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="create_template" value="1">
                <div class="form-group">
                    <label for="template_name">Template Name</label>
                    <input type="text" class="form-control-full" id="template_name" name="template_name" required>
                </div>
                <div class="form-group">
                    <label for="template_content">Template Content</label>
                    <textarea class="form-control-full" id="template_content" name="template_content" rows="5" required placeholder="e.g., This certifies that [RESIDENT_NAME] is a resident of [BARANGAY_NAME]..."></textarea>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Create</button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Certificate Modal -->
    <div id="viewCertificateModal" class="modal" role="dialog" aria-labelledby="viewCertificateModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="viewCertificateModalLabel">Certificate Details</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <div class="modal-body" id="certificateDetails">
                <p>Loading...</p>
            </div>
            <div class="button-group">
                <button type="button" class="btn btn-secondary modal-close">Close</button>
            </div>
        </div>
    </div>

    <!-- QR Code Certificate Modal -->
    <div id="qrcodeCertificateModal" class="modal" role="dialog" aria-labelledby="qrcodeCertificateModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="qrcodeCertificateModalLabel">Certificate QR Code</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <div class="modal-body" id="qrcodeDetails">
                <p>Loading QR code...</p>
            </div>
            <div class="button-group">
                <button type="button" class="btn btn-secondary modal-close">Close</button>
            </div>
        </div>
    </div>

    <!-- View Template Modal -->
    <div id="viewTemplateModal" class="modal" role="dialog" aria-labelledby="viewTemplateModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="viewTemplateModalLabel">Template Details</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <div class="modal-body" id="templateDetails">
                <p>Loading...</p>
            </div>
            <div class="button-group">
                <button type="button" class="btn btn-secondary modal-close">Close</button>
            </div>
        </div>
    </div>

    <!-- Edit Template Modal -->
    <div id="editTemplateModal" class="modal" role="dialog" aria-labelledby="editTemplateModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="editTemplateModalLabel">Edit Template</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="editTemplateForm" action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="update_template" value="1">
                <input type="hidden" name="template_id" id="edit_template_id">
                <div class="form-group">
                    <label for="edit_template_name">Template Name</label>
                    <input type="text" class="form-control-full" id="edit_template_name" name="template_name" required>
                </div>
                <div class="form-group">
                    <label for="edit_template_content">Template Content</label>
                    <textarea class="form-control-full" id="edit_template_content" name="template_content" rows="5" required></textarea>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Template Modal -->
    <div id="deleteTemplateModal" class="modal" role="dialog" aria-labelledby="deleteTemplateModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="deleteTemplateModalLabel">Delete Template</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="deleteTemplateForm" action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="delete_template" value="1">
                <input type="hidden" name="template_id" id="delete_template_id">
                <div class="modal-body">
                    <p>Are you sure you want to delete this template?</p>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Create Announcement Modal -->
    <div id="createAnnouncementModal" class="modal" role="dialog" aria-labelledby="createAnnouncementModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="createAnnouncementModalLabel">Create Announcement</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="createAnnouncementForm" action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="create_announcement" value="1">
                <div class="form-group">
                    <label for="ann_title">Title</label>
                    <input type="text" class="form-control-full" id="ann_title" name="ann_title" required>
                </div>
                <div class="form-group">
                    <label for="ann_content">Content</label>
                    <textarea class="form-control-full" id="ann_content" name="ann_content" rows="5" required></textarea>
                </div>
                <div class="form-group">
                    <label for="ann_is_active">Status</label>
                    <select class="form-control-full" id="ann_is_active" name="ann_is_active" required>
                        <option value="1">Active</option>
                        <option value="0">Inactive</option>
                    </select>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Create</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Announcement Modal -->
    <div id="editAnnouncementModal" class="modal" role="dialog" aria-labelledby="editAnnouncementModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="editAnnouncementModalLabel">Edit Announcement</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="editAnnouncementForm" action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="update_announcement" value="1">
                <input type="hidden" name="announcement_id" id="edit_announcement_id">
                <div class="form-group">
                    <label for="edit_ann_title">Title</label>
                    <input type="text" class="form-control-full" id="edit_ann_title" name="ann_title" required>
                </div>
                <div class="form-group">
                    <label for="edit_ann_content">Content</label>
                    <textarea class="form-control-full" id="edit_ann_content" name="ann_content" rows="5" required></textarea>
                </div>
                <div class="form-group">
                    <label for="edit_ann_is_active">Status</label>
                    <select class="form-control-full" id="edit_ann_is_active" name="ann_is_active" required>
                        <option value="1">Active</option>
                        <option value="0">Inactive</option>
                    </select>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Announcement Modal -->
    <div id="deleteAnnouncementModal" class="modal" role="dialog" aria-labelledby="deleteAnnouncementModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="deleteAnnouncementModalLabel">Delete Announcement</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <form id="deleteAnnouncementForm" action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="delete_announcement" value="1">
                <input type="hidden" name="announcement_id" id="delete_announcement_id">
                <div class="modal-body">
                    <p>Are you sure you want to delete this announcement?</p>
                </div>
                <div class="button-group">
                    <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                    <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Announcement Modal -->
    <div id="viewAnnouncementModal" class="modal" role="dialog" aria-labelledby="viewAnnouncementModalLabel">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="viewAnnouncementModalLabel">Announcement Details</h3>
                <button class="modal-close" aria-label="Close">×</button>
            </div>
            <div class="modal-body" id="announcementDetails">
                <p>Loading...</p>
            </div>
            <div class="button-group">
                <button type="button" class="btn btn-secondary modal-close">Close</button>
            </div>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast" class="toast <?php echo $toast_type; ?>" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-content">
            <span id="toastMessage"><?php echo htmlspecialchars($toast_message); ?></span>
            <button class="toast-close" aria-label="Close">×</button>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <script>
        $(document).ready(function() {
            // Sidebar and Tab Navigation
            $('.mobile-toggle').click(function() {
                $('.sidebar').toggleClass('active');
            });

            $('.menu-item').click(function(e) {
                if (!$(this).hasClass('logout')) {
                    e.preventDefault();
                    const target = $(this).data('target');
                    $('.menu-item').removeClass('active');
                    $(this).addClass('active');
                    $('.tab-content').removeClass('active');
                    $(`#${target}`).addClass('active');
                    $.post('', { active_tab: target });
                }
            });

            $('.tab-nav-item').click(function() {
                const target = $(this).data('target');
                $('.tab-nav-item').removeClass('active');
                $(this).addClass('active');
                $('.tab-content').removeClass('active');
                $(`#${target}`).addClass('active');
                $.post('', { active_tab: target });
            });

            // Modal Handling
            function openModal(modalId) {
                $(`#${modalId}`).addClass('active');
                $('body').addClass('modal-open');
            }

            function closeModal(modalId) {
                $(`#${modalId}`).removeClass('active');
                $('body').removeClass('modal-open');
                $(`#${modalId} form`)[0].reset();
            }

            $('.modal-close').click(function() {
                closeModal($(this).closest('.modal').attr('id'));
            });

            $(document).on('click', function(e) {
                if ($(e.target).hasClass('modal')) {
                    closeModal($(e.target).attr('id'));
                }
            });

            // Household Actions
            $('#addHouseholdBtn').click(function() {
                openModal('addHouseholdModal');
            });

            $('.view-household').click(function() {
                const id = $(this).data('id');
                $.ajax({
                    url: 'php/fetch_household.php',
                    method: 'POST',
                    data: { household_id: id },
                    success: function(data) {
                        $('#householdDetails').html(data);
                        openModal('viewHouseholdModal');
                    },
                    error: function() {
                        alert('Error fetching household details.');
                    }
                });
            });

            $('.edit-household').click(function() {
                const id = $(this).data('id');
                $.ajax({
                    url: 'php/fetch_household.php',
                    method: 'POST',
                    data: { household_id: id, edit: true },
                    dataType: 'json',
                    success: function(data) {
                        $('#edit_household_id').val(data.household_id);
                        $('#edit_household_name').val(data.household_name);
                        $('#edit_head_of_family').val(data.head_of_family);
                        $('#edit_address').val(data.address);
                        $('#edit_members_count').val(data.members_count);
                        $('#edit_contact_number').val(data.contact_number);
                        $('#edit_email').val(data.email);
                        $('#edit_status').val(data.status);
                        openModal('editHouseholdModal');
                    },
                    error: function() {
                        alert('Error fetching household details.');
                    }
                });
            });

            $('.delete-household').click(function() {
                $('#delete_household_id').val($(this).data('id'));
                openModal('deleteHouseholdModal');
            });

            $('.add-member').click(function() {
                const id = $(this).data('id');
                const name = $(this).data('name');
                $('#modal_household_id').val(id);
                $('#household_select').val(id);
                $('#addMemberModalLabel').text(`Add Member to ${name}`);
                openModal('addMemberModal');
            });

// Member Actions
$('#addMemberBtn').click(function() {
    $('#modal_household_id').val('');
    $('#household_select').val('');
    $('#addMemberModalLabel').text('Add New Member');
    openModal('addMemberModal');
});

$('.view-member').click(function() {
    const id = $(this).data('id');
    if (!id || isNaN(id) || id <= 0) {
        console.error('Invalid member_id:', id);
        alert('Invalid member ID. Please ensure the member exists.');
        return;
    }
    console.log('Fetching member with ID:', id); // Debug
    $.ajax({
        url: 'php/fetch_members.php',
        method: 'POST',
        data: { member_id: id },
        success: function(data) {
            $('#memberDetails').html(data);
            openModal('viewMemberModal');
        },
        error: function(xhr, status, error) {
            console.error('View Member AJAX Error:', {
                status: status,
                error: error,
                responseText: xhr.responseText
            });
            alert('Error fetching member details: ' + (xhr.responseText || 'Unknown error. Check console for details.'));
        }
    });
});

$('.edit-member').click(function() {
    const id = $(this).data('id');
    const householdId = $(this).data('household-id');
    if (!id || isNaN(id) || id <= 0) {
        console.error('Invalid member_id:', id);
        alert('Invalid member ID. Please ensure the member exists.');
        return;
    }
    if (!householdId || isNaN(householdId) || householdId <= 0) {
        console.error('Invalid household_id:', householdId);
        alert('Invalid household ID. Please try again.');
        return;
    }
    console.log('Fetching member with ID:', id, 'Household ID:', householdId); // Debug
    $.ajax({
        url: 'php/fetch_members.php',
        method: 'POST',
        data: { member_id: id, edit: true },
        dataType: 'json',
        success: function(data) {
            $('#edit_member_id').val(data.member_id);
            $('#edit_household_select').val(householdId);
            $('#edit_member_fullname').val(data.fullname);
            $('#edit_member_birthdate').val(data.birthdate);
            $('#edit_member_age').val(data.age);
            $('#edit_member_gender').val(data.gender);
            $('#edit_member_relationship').val(data.relationship);
            $('#edit_member_occupation').val(data.occupation);
            $('#edit_member_education').val(data.education_level);
            openModal('editMemberModal');
        },
        error: function(xhr, status, error) {
            console.error('Edit Member AJAX Error:', {
                status: status,
                error: error,
                responseText: xhr.responseText
            });
            alert('Error fetching member details: ' + (xhr.responseText || 'Unknown error. Check console for details.'));
        }
    });
});

            $('.delete-member').click(function() {
                $('#delete_member_id').val($(this).data('id'));
                $('#delete_member_household_id').val($(this).data('household-id'));
                openModal('deleteMemberModal');
            });

            // Document Actions
            $('#uploadDocumentBtn').click(function() {
                openModal('uploadDocumentModal');
            });

            $('.view-document').click(function() {
                const id = $(this).data('id');
                $.ajax({
                    url: 'php/fetch_document.php',
                    method: 'POST',
                    data: { document_id: id },
                    success: function(data) {
                        $('#documentDetails').html(data);
                        openModal('viewDocumentModal');
                    },
                    error: function() {
                        alert('Error fetching document details.');
                    }
                });
            });

            $('.edit-document').click(function() {
                const row = $(this).closest('tr');
                $('#edit_document_id').val(row.data('id'));
                $('#edit_doc_title').val(row.data('title'));
                $('#edit_doc_type').val(row.data('type'));
                $('#edit_doc_description').val(row.data('description'));
                $('#edit_doc_status').val(row.find('td:eq(5) .badge').text());
                openModal('editDocumentModal');
            });

            $('.delete-document').click(function() {
                $('#delete_document_id').val($(this).data('id'));
                openModal('deleteDocumentModal');
            });

            // Certificate Actions
            $('#generateCertificateBtn').click(function() {
                openModal('generateCertificateModal');
            });

            $('#createTemplateBtn').click(function() {
                openModal('createTemplateModal');
            });

            $('.view-certificate').click(function() {
                const id = $(this).data('id');
                $.ajax({
                    url: 'php/fetch_certificate.php',
                    method: 'POST',
                    data: { certificate_id: id },
                    success: function(data) {
                        $('#certificateDetails').html(data);
                        openModal('viewCertificateModal');
                    },
                    error: function() {
                        alert('Error fetching certificate details.');
                    }
                });
            });

            $('.print-certificate').click(function() {
                const id = $(this).data('id');
                window.location.href = `php/generate_certificate_pdf.php?id=${id}`;
            });

            $('.qrcode-certificate').click(function() {
                const id = $(this).data('id');
                $('#qrcodeDetails').html(`<img src="php/generate_qr_code.php?id=${id}" alt="QR Code">`);
                openModal('qrcodeCertificateModal');
            });

            $('.view-template').click(function() {
                const row = $(this).closest('tr');
                const name = row.data('name');
                const content = row.data('content');
                $('#templateDetails').html(`
                    <p><strong>Template Name:</strong> ${name}</p>
                    <p><strong>Content:</strong> ${content}</p>
                `);
                openModal('viewTemplateModal');
            });

            $('.edit-template').click(function() {
                const row = $(this).closest('tr');
                $('#edit_template_id').val(row.data('id'));
                $('#edit_template_name').val(row.data('name'));
                $('#edit_template_content').val(row.data('content'));
                openModal('editTemplateModal');
            });

            $('.delete-template').click(function() {
                $('#delete_template_id').val($(this).data('id'));
                openModal('deleteTemplateModal');
            });

            // Announcement Actions
            $('#createAnnouncementBtn').click(function() {
                openModal('createAnnouncementModal');
            });

            $('.view-announcement').click(function() {
                const row = $(this).closest('tr');
                const title = row.data('title');
                const content = row.data('content');
                const status = row.data('is-active') ? 'Active' : 'Inactive';
                $('#announcementDetails').html(`
                    <p><strong>Title:</strong> ${title}</p>
                    <p><strong>Content:</strong> ${content}</p>
                    <p><strong>Status:</strong> ${status}</p>
                `);
                openModal('viewAnnouncementModal');
            });

            $('.edit-announcement').click(function() {
                const row = $(this).closest('tr');
                $('#edit_announcement_id').val(row.data('id'));
                $('#edit_ann_title').val(row.data('title'));
                $('#edit_ann_content').val(row.data('content'));
                $('#edit_ann_is_active').val(row.data('is-active'));
                openModal('editAnnouncementModal');
            });

            $('.delete-announcement').click(function() {
                $('#delete_announcement_id').val($(this).data('id'));
                openModal('deleteAnnouncementModal');
            });

            // Search and Filter
            $('#householdSearch').on('input', function() {
                const query = $(this).val().toLowerCase();
                $('.household-card').each(function() {
                    const name = $(this).find('h3').text().toLowerCase();
                    const head = $(this).find('p:contains("Head:")').text().toLowerCase();
                    $(this).toggle(name.includes(query) || head.includes(query));
                });
            });

            $('#memberSearch').on('input', function() {
                const query = $(this).val().toLowerCase();
                $('#memberTable tbody tr').each(function() {
                    const name = $(this).find('td:eq(0)').text().toLowerCase();
                    const household = $(this).find('td:eq(1)').text().toLowerCase();
                    $(this).toggle(name.includes(query) || household.includes(query));
                });
            });

            $('#memberFilterGender').change(function() {
                const gender = $(this).val();
                $('#memberTable tbody tr').each(function() {
                    const rowGender = $(this).find('td:eq(4)').text();
                    $(this).toggle(gender === '' || rowGender === gender);
                });
            });

            $('#documentSearch').on('input', function() {
                const query = $(this).val().toLowerCase();
                $('#documentTable tbody tr').each(function() {
                    const title = $(this).find('td:eq(0)').text().toLowerCase();
                    const type = $(this).find('td:eq(1)').text().toLowerCase();
                    $(this).toggle(title.includes(query) || type.includes(query));
                });
            });

            $('#announcementSearch').on('input', function() {
                const query = $(this).val().toLowerCase();
                $('#announcementTable tbody tr').each(function() {
                    const title = $(this).find('td:eq(0)').text().toLowerCase();
                    $(this).toggle(title.includes(query));
                });
            });

            // Toast Notification
          // Toast Notification
if ($('#toastMessage').text().trim() !== '') {
    $('#toast').addClass('show');
    setTimeout(() => $('#toast').removeClass('show'), 5000);
}

$('.toast-close').click(function() {
    $('#toast').removeClass('show');
});

            // Chart
            const ctx = $('#analyticsChart')[0].getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Households', 'Documents', 'Certificates', 'Announcements'],
                    datasets: [{
                        label: 'Activity',
                        data: [
                            <?php echo $analytics['households']; ?>,
                            <?php echo $analytics['documents_month']; ?>,
                            <?php echo $analytics['certificates_month']; ?>,
                            <?php echo $analytics['announcements_active']; ?>
                        ],
                        backgroundColor: ['#007bff', '#28a745', '#ffc107', '#dc3545'],
                        borderColor: ['#0056b3', '#218838', '#e0a800', '#c82333'],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: { beginAtZero: true }
                    }
                }
            });
        });
    </script>
</body>
</html>
<?php
$conn->close();
?>