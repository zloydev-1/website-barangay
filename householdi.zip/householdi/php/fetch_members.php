<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'secretary') {
    header('HTTP/1.1 403 Forbidden');
    exit('Unauthorized access');
}

$conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
if ($conn->connect_error) {
    error_log("Database connection failed: " . $conn->connect_error);
    header('HTTP/1.1 500 Internal Server Error');
    exit("Connection failed: " . $conn->connect_error);
}

$member_id = filter_input(INPUT_POST, 'member_id', FILTER_VALIDATE_INT);
$edit = filter_input(INPUT_POST, 'edit', FILTER_VALIDATE_BOOLEAN);

if ($member_id === false || $member_id === null) {
    error_log("Invalid or missing member_id: " . var_export($_POST['member_id'], true));
    header('HTTP/1.1 400 Bad Request');
    exit('Invalid or missing member ID');
}

// Debug: Log the request
error_log("Fetching details for member_id: $member_id, edit: " . ($edit ? 'true' : 'false'));

$stmt = $conn->prepare("SELECT hm.*, h.household_name FROM household_members hm JOIN households h ON hm.household_id = h.household_id WHERE hm.member_id = ?");
if (!$stmt) {
    error_log("Prepare failed: " . $conn->error);
    header('HTTP/1.1 500 Internal Server Error');
    exit('Query preparation failed');
}
$stmt->bind_param("i", $member_id);
$stmt->execute();
$result = $stmt->get_result();

// Debug: Log query result
error_log("Query result rows: " . $result->num_rows);

if ($row = $result->fetch_assoc()) {
    // Debug: Log fetched data
    error_log("Fetched member data: " . json_encode($row));
    if ($edit) {
        header('Content-Type: application/json');
        echo json_encode($row);
    } else {
        echo "
            <p><strong>Full Name:</strong> " . htmlspecialchars($row['fullname']) . "</p>
            <p><strong>Household:</strong> " . htmlspecialchars($row['household_name']) . "</p>
            <p><strong>Birth Date:</strong> " . date('M d, Y', strtotime($row['birthdate'])) . "</p>
            <p><strong>Age:</strong> " . htmlspecialchars($row['age']) . "</p>
            <p><strong>Gender:</strong> " . htmlspecialchars($row['gender']) . "</p>
            <p><strong>Relationship:</strong> " . htmlspecialchars($row['relationship']) . "</p>
            <p><strong>Occupation:</strong> " . htmlspecialchars($row['occupation'] ?: 'N/A') . "</p>
            <p><strong>Education:</strong> " . htmlspecialchars($row['education_level'] ?: 'N/A') . "</p>
        ";
    }
} else {
    error_log("No member found for member_id: $member_id");
    header('HTTP/1.1 404 Not Found');
    exit('Error fetching member details: Member not found');
}

$stmt->close();
$conn->close();
?>