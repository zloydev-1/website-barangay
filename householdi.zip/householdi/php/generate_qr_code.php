<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/config.php'; // PDO connection
require_once __DIR__ . '/../vendor/autoload.php';
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;
use Endroid\QrCode\Color\Color;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelEnum;

// Validate request parameter
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    http_response_code(400);
    echo "Invalid certificate ID.";
    exit;
}

$certificate_id = (int)$_GET['id'];

try {
    // Fetch certificate data
    $stmt = $conn->prepare("SELECT certificate_id, resident_full_name FROM certificates WHERE certificate_id = ?");
    $stmt->execute([$certificate_id]);
    $certificate = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$certificate) {
        http_response_code(404);
        echo "Certificate not found.";
        exit;
    }

    // Create QR code data
    $qrData = "Certificate ID: " . $certificate_id . "\nName: " . $certificate['resident_full_name'];

    // Generate QR code
    $qrCode = QrCode::create($qrData)
        ->setEncoding(new Encoding('UTF-8'))
        ->setErrorCorrectionLevel(ErrorCorrectionLevelEnum::High)
        ->setSize(300)
        ->setMargin(10)
        ->setForegroundColor(new Color(0, 0, 0)) // Black foreground
        ->setBackgroundColor(new Color(255, 255, 255)); // White background

    // Write QR code to PNG
    $writer = new PngWriter();
    $result = $writer->write($qrCode);

    // Output QR code as PNG
    header('Content-Type: ' . $result->getMimeType());
    echo $result->getString();

} catch (PDOException $e) {
    http_response_code(500);
    echo "Database error: " . $e->getMessage();
    exit;
} catch (Exception $e) {
    http_response_code(500);
    echo "Error generating QR code: " . $e->getMessage();
    exit;
}