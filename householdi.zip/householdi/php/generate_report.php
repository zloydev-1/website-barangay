<?php
ob_start(); // Start output buffering to prevent header issues
session_start();

// Check if user is treasurer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'treasurer') {
    header('HTTP/1.1 403 Forbidden');
    exit('Unauthorized access');
}

// Validate CSRF token
function validate_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && is_string($_SESSION['csrf_token']) && is_string($token) && hash_equals($_SESSION['csrf_token'], $token);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['csrf_token']) || !validate_csrf_token($_POST['csrf_token'])) {
    $_SESSION['toast_message'] = "Invalid request.";
    $_SESSION['toast_type'] = "error";
    header('Location: /householdi/treasurer.php#reports'); // Absolute path
    exit;
}

// Get form data
$report_type = $_POST['report_type'] ?? '';
$report_period = $_POST['report_period'] ?? '';
$report_date = $_POST['report_date'] ?? '';
$month = date('m', strtotime($report_date));
$year = date('Y', strtotime($report_date));
$treasurer_id = $_SESSION['user']['id'];

// Connect to database
$conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
if ($conn->connect_error) {
    error_log("Database connection failed: " . $conn->connect_error);
    header('HTTP/1.1 500 Internal Server Error');
    exit('Connection failed');
}

// Calculate totals
$total_income = $conn->query("SELECT SUM(amount_paid) as total FROM household_financials WHERE payment_status = 'Paid'")->fetch_assoc()['total'] ?? 0;
$total_expenses = $conn->query("SELECT SUM(amount) as total FROM financial_aid")->fetch_assoc()['total'] ?? 0;

// Prepare report file
$file_name = 'report_' . time() . '.pdf';
$file_path = "reports/$file_name";

// Save report to database
$stmt = $conn->prepare("INSERT INTO financial_reports (report_type, report_period, month, year, total_income, total_expenses, generated_by, file_path, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
$stmt->bind_param("ssiiddis", $report_type, $report_period, $month, $year, $total_income, $total_expenses, $treasurer_id, $file_path);
if (!$stmt->execute()) {
    error_log("Database insert failed: " . $conn->error);
    $_SESSION['toast_message'] = "Failed to save report.";
    $_SESSION['toast_type'] = "error";
    header('Location: /householdi/treasurer.php#reports'); // Absolute path
    exit;
}
$stmt->close();
$conn->close();

// Set success message and redirect
$_SESSION['toast_message'] = "Report generated successfully.";
$_SESSION['toast_type'] = "success";
header('Location: /householdi/treasurer.php#reports'); // Absolute path
ob_end_flush(); // Flush buffer and send headers
exit;
?>