<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

require 'php/config.php';

if (isset($_POST['update_certificate'])) {
    $request_id = $_POST['request_id'];
    $status = $_POST['status'];

    try {
        $stmt = $conn->prepare("UPDATE certificate_requests SET status = ? WHERE id = ?");
        $stmt->execute([$status, $request_id]);
        $_SESSION['toast_message'] = 'Certificate request updated successfully!';
        $_SESSION['toast_type'] = 'success';
    } catch (PDOException $e) {
        $_SESSION['toast_message'] = 'Error updating certificate: ' . $e->getMessage();
        $_SESSION['toast_type'] = 'error';
    }
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

try {
    $stmt = $conn->prepare("SELECT cr.id, cr.user_id, cr.certificate_type, cr.purpose, cr.status, cr.created_at, bu.first_name, bu.last_name 
                            FROM certificate_requests cr 
                            JOIN barangay_users bu ON cr.user_id = bu.id 
                            ORDER BY cr.created_at DESC");
    $stmt->execute();
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $requests = [];
    $_SESSION['toast_message'] = 'Error fetching certificate requests: ' . $e->getMessage();
    $_SESSION['toast_type'] = 'error';
}

$toast_message = $_SESSION['toast_message'] ?? '';
$toast_type = $_SESSION['toast_type'] ?? '';
unset($_SESSION['toast_message'], $_SESSION['toast_type']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificates | Barangay Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="container mt-4">
        <h1><i class="fas fa-certificate"></i> Certificate Requests</h1>
        
        <?php if (!empty($toast_message)): ?>
        <div class="alert alert-<?php echo $toast_type == 'success' ? 'success' : 'danger'; ?>">
            <?php echo $toast_message; ?>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Manage Certificate Requests</h5>
            </div>
            <div class="card-body">
                <?php if (empty($requests)): ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> No certificate requests found.
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Certificate Type</th>
                                <th>Purpose</th>
                                <th>Status</th>
                                <th>Date Requested</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($requests as $request): ?>
                            <tr>
                                <td><?php echo $request['first_name'] . ' ' . $request['last_name']; ?></td>
                                <td><?php echo ucfirst($request['certificate_type']); ?></td>
                                <td><?php echo $request['purpose']; ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $request['status'] == 'pending' ? 'warning' : ($request['status'] == 'approved' ? 'success' : 'danger'); ?>">
                                        <?php echo ucfirst($request['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M d, Y g:i A', strtotime($request['created_at'])); ?></td>
                                <td>
                                    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                        <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                        <select name="status" class="form-select form-select-sm d-inline-block w-auto">
                                            <option value="pending" <?php echo $request['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                            <option value="approved" <?php echo $request['status'] == 'approved' ? 'selected' : ''; ?>>Approved</option>
                                            <option value="rejected" <?php echo $request['status'] == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                                        </select>
                                        <button type="submit" name="update_certificate" class="btn btn-sm btn-primary">Update</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>