<?php
session_start();
require_once '../vendor/autoload.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'secretary' || !isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $_SESSION['toast_message'] = "Unauthorized access.";
    $_SESSION['toast_type'] = "error";
    header('Location: ../secretary.php');
    exit;
}

$conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
if ($conn->connect_error) {
    $_SESSION['toast_message'] = "Database connection failed.";
    $_SESSION['toast_type'] = "error";
    header('Location: ../secretary.php');
    exit;
}

$user_id = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
$first_name = filter_input(INPUT_POST, 'first_name', FILTER_SANITIZE_STRING);
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
$new_password = $_POST['new_password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';

if (!$user_id || !$first_name || !$email) {
    $_SESSION['toast_message'] = "Required fields are missing.";
    $_SESSION['toast_type'] = "error";
    header('Location: ../secretary.php');
    exit;
}

if ($new_password && $new_password !== $confirm_password) {
    $_SESSION['toast_message'] = "Passwords do not match.";
    $_SESSION['toast_type'] = "error";
    header('Location: ../secretary.php');
    exit;
}

if ($new_password) {
    $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE barangay_users SET first_name = ?, email = ?, password = ? WHERE id = ?");
    $stmt->bind_param("sssi", $first_name, $email, $password_hash, $user_id);
} else {
    $stmt = $conn->prepare("UPDATE barangay_users SET first_name = ?, email = ? WHERE id = ?");
    $stmt->bind_param("ssi", $first_name, $email, $user_id);
}

if ($stmt->execute()) {
    $_SESSION['user']['first_name'] = $first_name;
    $_SESSION['user']['email'] = $email;
    $_SESSION['toast_message'] = "Profile updated successfully!";
    $_SESSION['toast_type'] = "success";
} else {
    $_SESSION['toast_message'] = "Error updating profile: " . $stmt->error;
    $_SESSION['toast_type'] = "error";
}
$stmt->close();
$conn->close();
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
header('Location: ../secretary.php');
exit;
?>