<?php
require 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize input
    $email = trim($_POST['email'] ?? '');

    // Basic validation
    $errors = [];
    if (empty($email)) {
        $errors[] = 'Email is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email address.';
    }

    if (!empty($errors)) {
        echo json_encode(['status' => 'error', 'message' => $errors[0]]);
        exit;
    }

    try {
        // Check if email exists in barangay_users
        $stmt = $conn->prepare("SELECT id FROM barangay_users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user) {
            echo json_encode(['status' => 'success', 'message' => 'Email found.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Email not found.']);
        }
    } catch (PDOException $e) {
        file_put_contents('forgot_password_debug.txt', "Database error: " . $e->getMessage() . "\n", FILE_APPEND);
        echo json_encode(['status' => 'error', 'message' => 'An error occurred. Please try again later.']);
        exit;
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}
?>