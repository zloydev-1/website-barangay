<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'secretary') {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
if ($conn->connect_error) {
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$certificate_id = filter_input(INPUT_POST, 'certificate_id', FILTER_VALIDATE_INT);
if (!$certificate_id) {
    echo json_encode(['error' => 'Invalid certificate ID']);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM certificates WHERE certificate_id = ?");
$stmt->bind_param("i", $certificate_id);
$stmt->execute();
$result = $stmt->get_result();
$certificate = $result->fetch_assoc();

if (!$certificate) {
    echo json_encode(['error' => 'Certificate not found']);
} else {
    echo json_encode($certificate);
}

$stmt->close();
$conn->close();
?>