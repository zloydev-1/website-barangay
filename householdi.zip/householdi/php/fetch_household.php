<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'secretary') {
    exit;
}
$conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$household_id = filter_input(INPUT_POST, 'household_id', FILTER_VALIDATE_INT);
$edit = filter_input(INPUT_POST, 'edit', FILTER_VALIDATE_BOOLEAN);
$stmt = $conn->prepare("SELECT * FROM households WHERE household_id = ?");
$stmt->bind_param("i", $household_id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    if ($edit) {
        header('Content-Type: application/json');
        echo json_encode($row);
    } else {
        echo "
            <p><strong>Household Name:</strong> " . htmlspecialchars($row['household_name']) . "</p>
            <p><strong>Head of Family:</strong> " . htmlspecialchars($row['head_of_family']) . "</p>
            <p><strong>Address:</strong> " . htmlspecialchars($row['address']) . "</p>
            <p><strong>Members:</strong> " . htmlspecialchars($row['members_count']) . "</p>
            <p><strong>Contact:</strong> " . htmlspecialchars($row['contact_number'] ?: 'N/A') . "</p>
            <p><strong>Email:</strong> " . htmlspecialchars($row['email'] ?: 'N/A') . "</p>
            <p><strong>Status:</strong> " . htmlspecialchars($row['status']) . "</p>
            <p><strong>Registered:</strong> " . date('M d, Y', strtotime($row['registration_date'])) . "</p>
        ";
    }
}
$stmt->close();
$conn->close();
?>