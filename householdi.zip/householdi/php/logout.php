<?php
session_start();

// Include database configuration
require 'config.php';

// Helper function to log actions
function log_action($conn, $user_id, $action, $description) {
    try {
        $stmt = $conn->prepare("INSERT INTO audit_logs (user_id, action, description, created_at) VALUES (:user_id, :action, :description, NOW())");
        $stmt->execute([':user_id' => $user_id, ':action' => $action, ':description' => $description]);
    } catch (PDOException $e) {
        // Silently fail to avoid disrupting logout
    }
}

// Check if user is logged in
if (!isset($_SESSION['user']) || !isset($_SESSION['csrf_token'])) {
    session_unset();
    session_destroy();
    header("Location: http://localhost/householdi/index.html");
    exit;
}

// Log the logout action
$user_id = $_SESSION['user']['id'] ?? 0;
if ($user_id) {
    log_action($conn, $user_id, 'Logout', "User ID: $user_id logged out.");
}

// Clear and destroy session
session_unset();
session_destroy();

// Redirect to homepage
header("Location: http://localhost/householdi/index.html");
exit;
?>