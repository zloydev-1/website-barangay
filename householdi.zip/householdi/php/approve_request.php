<?php
session_start();
$conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'], $_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $id = intval($_POST['id']);
    $stmt = $conn->prepare("SELECT cr.*, bu.first_name, bu.email FROM certificate_requests cr JOIN barangay_users bu ON cr.user_id = bu.id WHERE cr.id = ? AND cr.status = 'Pending'");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        // Update request status
        $stmt = $conn->prepare("UPDATE certificate_requests SET status = 'Approved' WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();

        // Generate certificate (simplified, adjust fields as needed)
        $resident_full_name = $row['first_name'];
        $certificate_type = $row['certificate_type'];
        $status = 'Approved';
        $issue_date = date('Y-m-d H:i:s');
        $created_by = $_SESSION['user']['id'];
        $stmt = $conn->prepare("INSERT INTO certificates (resident_full_name, certificate_type, status, issue_date, created_by) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssi", $resident_full_name, $certificate_type, $status, $issue_date, $created_by);
        $stmt->execute();
        $certificate_id = $stmt->insert_id;

        // Add QR code
        $qr_code = "https://yourdomain.com/verify.php?cert_id=$certificate_id";
        $stmt = $conn->prepare("UPDATE certificates SET qr_code = ? WHERE id = ?");
        $stmt->bind_param("si", $qr_code, $certificate_id);
        $stmt->execute();

        // Log action
        $log_stmt = $conn->prepare("INSERT INTO audit_logs (action, user_id, details, created_at) VALUES (?, ?, ?, NOW())");
        $action = "Certificate Request Approved";
        $details = "Approved $certificate_type request ID $id";
        $log_stmt->bind_param("sis", $action, $_SESSION['user']['id'], $details);
        $log_stmt->execute();
        $log_stmt->close();

        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Request not found or already processed.']);
    }
    $stmt->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request or CSRF token.']);
}
$conn->close();
?>