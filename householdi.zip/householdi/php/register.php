<?php
require 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize input
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $purok = trim($_POST['purok'] ?? '');

    // Basic validation
    $errors = [];
    if (empty($first_name)) {
        $errors[] = 'First name is required.';
    }
    if (empty($last_name)) {
        $errors[] = 'Last name is required.';
    }
    if (empty($email)) {
        $errors[] = 'Email is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email address.';
    }
    if (empty($username)) {
        $errors[] = 'Username is required.';
    }
    if (empty($password)) {
        $errors[] = 'Password is required.';
    } elseif (strlen($password) < 8 || !preg_match('/[a-zA-Z]/', $password) || !preg_match('/\d/', $password)) {
        $errors[] = 'Password must be at least 8 characters long with letters and numbers.';
    }
    if (!empty($phone) && !preg_match('/^\d{11}$/', $phone)) {
        $errors[] = 'Phone number must be 11 digits.';
    }
    if (empty($purok)) {
        $errors[] = 'Purok is required.';
    } elseif (!in_array($purok, ['purok1', 'purok2', 'purok3', 'purok4', 'purok5', 'purok6', 'purok7'])) {
        $errors[] = 'Invalid purok selected.';
    }
    if (empty($address)) {
        $errors[] = 'Address is required.';
    }

    try {
        // Check if email exists
        $stmt = $conn->prepare("SELECT id FROM barangay_users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'Email is already registered.';
        }

        // Check if username exists
        $stmt = $conn->prepare("SELECT id FROM barangay_users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $errors[] = 'Username is already taken.';
        }

        if (!empty($errors)) {
            echo json_encode(['success' => false, 'errors' => $errors]);
            exit;
        }

        // Insert user into database
        $stmt = $conn->prepare("INSERT INTO barangay_users (first_name, last_name, email, username, password, phone, address, purok, role, is_approved) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $role = 'resident'; // Default role
        $is_approved = 0; // Pending approval
        $stmt->execute([$first_name, $last_name, $email, $username, $hashed_password, $phone, $address, $purok, $role, $is_approved]);

        echo json_encode(['success' => true, 'message' => 'Registration successful! Waiting for the Barangay Captain to approve.']);
    } catch (PDOException $e) {
        file_put_contents('register_debug.txt', "Database error: " . $e->getMessage() . "\n", FILE_APPEND);
        echo json_encode(['success' => false, 'errors' => ['Registration failed due to a database error.']]);
        exit;
    }
} else {
    echo json_encode(['success' => false, 'errors' => ['Invalid request.']]);
}
?>