<?php
session_start();
require_once __DIR__ . '/config.php'; // Include PDO-based config.php
require_once __DIR__ . '/../vendor/tecnickcom/tcpdf/tcpdf.php'; // Path to TCPDF

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid certificate ID.");
}

$certificate_id = (int)$_GET['id'];

try {
    // Prepare and execute query using PDO
    $stmt = $conn->prepare("SELECT * FROM certificates WHERE certificate_id = ?");
    if (!$stmt) {
        die("Prepare failed: " . $conn->errorInfo()[2]);
    }
    $stmt->execute([$certificate_id]);
    $certificate = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$certificate) {
        die("Certificate not found.");
    }
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

// Define a class that extends TCPDF to create our custom certificate
class BarangayCertificate extends TCPDF {
    protected $watermark;
    protected $certificate;
    
    public function setWatermark($file) {
        $this->watermark = $file;
    }
    
    public function setCertificateData($data) {
        $this->certificate = $data;
    }
    
    // Page background
    public function Header() {
        if (!empty($this->watermark) && file_exists($this->watermark)) {
            // Set watermark image in the background
            $this->Image($this->watermark, 0, 0, $this->getPageWidth(), $this->getPageHeight(), '', '', '', false, 300, '', false, false, 0);
        }
    }
}

// Create new custom PDF document
$pdf = new BarangayCertificate('P', 'mm', 'LETTER', true, 'UTF-8', false);
$pdf->setCertificateData($certificate);

// Set document information
$pdf->SetCreator('Barangay ' . $certificate['barangay_name'] . ' Official Certificate System');
$pdf->SetAuthor('Barangay ' . $certificate['barangay_name']);
$pdf->SetTitle($certificate['certificate_type'] . ' - ' . $certificate['resident_full_name']);
$pdf->SetSubject('Official Barangay ' . $certificate['certificate_type']);
$pdf->SetKeywords('barangay, certificate, official, philippines, ' . $certificate['barangay_name']);

// Set watermark if available
$watermark = __DIR__ . '/../images/watermark.png'; // Create a semi-transparent barangay logo as watermark
if (file_exists($watermark)) {
    $pdf->setWatermark($watermark);
}

// Remove default header/footer
$pdf->setPrintHeader(true); // We use custom header for watermark
$pdf->setPrintFooter(false);

// Set margins
$pdf->SetMargins(10, 10, 10);
$pdf->SetHeaderMargin(0);
$pdf->SetFooterMargin(5);

// Set auto page breaks
$pdf->SetAutoPageBreak(TRUE, 15);

// Set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// Set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('times', '', 12);

// Add disclaimer at the top
$pdf->SetFont('helvetica', 'B', 10);
$pdf->Cell(0, 8, 'THIS DOCUMENT IS A RECREATED SAMPLE OF A BARANGAY CLEARANCE', 0, 1, 'C');
$pdf->Cell(0, 8, 'FOR ILLUSTRATIVE PURPOSES ONLY.', 0, 1, 'C');
$pdf->Ln(2);

// Add barangay logo
$barangay_logo = __DIR__ . '/../images/S.jpg'; // Circular purple logo
if (file_exists($barangay_logo)) {
    $pdf->Image($barangay_logo, 20, 20, 40, '', 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);
}

// Set the purple color for text
$purple_color = array(102, 0, 102); // RGB for dark purple
$pdf->SetTextColor($purple_color[0], $purple_color[1], $purple_color[2]);

// Add header text
$pdf->SetFont('times', '', 12);
$pdf->SetXY(75, 30);
$pdf->Cell(120, 6, 'Republic of the Philippines', 0, 1, 'L');
$pdf->SetXY(75, 36);
$pdf->Cell(120, 6, 'Province of ' . htmlspecialchars($certificate['province']), 0, 1, 'L');
$pdf->SetXY(75, 42);
$pdf->Cell(120, 6, 'City of ' . htmlspecialchars($certificate['municipality']), 0, 1, 'L');

// Add barangay name in large purple text
$pdf->SetFont('times', 'B', 28);
$pdf->SetXY(75, 50);
$pdf->Cell(120, 12, 'BARANGAY ' . strtoupper(htmlspecialchars($certificate['barangay_name'])), 0, 1, 'L');
$pdf->Ln(5);

// Add horizontal line
$pdf->SetDrawColor(0, 0, 0);
$pdf->Line(10, 70, 200, 70);

// Set up two-column layout
// Left column - Officials
$pdf->SetFont('times', 'B', 14);
$pdf->SetXY(15, 80);
$pdf->Cell(60, 10, 'BARANGAY CHAIRMAN', 0, 1, 'L');
$pdf->SetFont('times', '', 11);
$pdf->SetXY(15, 90);
$pdf->Cell(60, 8, htmlspecialchars($certificate['barangay_captain_name']), 0, 1, 'L');

$pdf->SetFont('times', 'B', 14);
$pdf->SetXY(15, 105);
$pdf->Cell(60, 10, 'KAGAWAD', 0, 1, 'L');

// Add placeholder kagawads
// In real implementation, you would fetch these from database
$pdf->SetFont('times', '', 11);
$kagawad_y = 115;
for ($i = 1; $i <= 7; $i++) {
    if(isset($certificate['kagawad_'.$i]) && !empty($certificate['kagawad_'.$i])) {
        $pdf->SetXY(15, $kagawad_y);
        $pdf->Cell(60, 6, htmlspecialchars($certificate['kagawad_'.$i]), 0, 1, 'L');
    } else {
        $pdf->SetXY(15, $kagawad_y);
        $pdf->Cell(60, 6, "[name of Kagawad ".$i."]", 0, 1, 'L');
    }
    $kagawad_y += 8;
}

$pdf->SetFont('times', 'B', 14);
$pdf->SetXY(15, 175);
$pdf->Cell(60, 10, 'BRGY. SECRETARY', 0, 1, 'L');
$pdf->SetFont('times', '', 11);
$pdf->SetXY(15, 185);
if(isset($certificate['barangay_secretary_name']) && !empty($certificate['barangay_secretary_name'])) {
    $pdf->Cell(60, 8, htmlspecialchars($certificate['barangay_secretary_name']), 0, 1, 'L');
} else {
    $pdf->Cell(60, 8, "[name of Barangay Secretary]", 0, 1, 'L');
}

$pdf->SetFont('times', 'B', 14);
$pdf->SetXY(15, 200);
$pdf->Cell(60, 10, 'BRGY. TREASURER', 0, 1, 'L');
$pdf->SetFont('times', '', 11);
$pdf->SetXY(15, 210);
if(isset($certificate['barangay_treasurer']) && !empty($certificate['barangay_treasurer'])) {
    $pdf->Cell(60, 8, htmlspecialchars($certificate['barangay_treasurer']), 0, 1, 'L');
} else {
    $pdf->Cell(60, 8, "[name of Barangay Treasurer]", 0, 1, 'L');
}

// Add "NOT VALID WITHOUT SEAL" text in the bottom left
$pdf->SetFont('helvetica', 'B', 10);
$pdf->SetXY(15, 245);
$pdf->Cell(60, 10, 'NOT VALID WITHOUT SEAL', 0, 1, 'L');

// Vertical line dividing the columns
$pdf->SetDrawColor(0, 0, 0);
$pdf->Line(80, 70, 80, 270);

// Right column - Certificate content
$pdf->SetTextColor(0, 0, 0); // Reset to black for standard text
$pdf->SetXY(170, 80);
$pdf->SetFont('times', 'B', 12);
$pdf->Cell(20, 10, 'NO. ' . sprintf('%04d', $certificate_id), 0, 1, 'R');

$pdf->SetXY(90, 95);
$pdf->SetFont('times', 'B', 12);
$pdf->Cell(100, 10, 'To Whom It May Concern:', 0, 1, 'L');

$pdf->SetXY(90, 110);
$pdf->SetFont('times', '', 11);
$pdf->MultiCell(100, 6, 'This is to certify that ', 0, 'L');

// Add resident name in purple
$pdf->SetXY(90, 116);
$pdf->SetTextColor($purple_color[0], $purple_color[1], $purple_color[2]);
$pdf->SetFont('times', 'B', 12);
$pdf->Cell(100, 10, strtoupper(htmlspecialchars($certificate['resident_full_name'])), 0, 1, 'L');

// Continue with black text
$pdf->SetXY(90, 126);
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('times', '', 11);
$pdf->MultiCell(100, 6, ', of legal age, a resident of ' . htmlspecialchars($certificate['resident_address']) . ', is known to us as a person of good moral character and is a member of this community.', 0, 'L');

$pdf->Ln(4);
$pdf->SetXY(90, 152);
$pdf->MultiCell(100, 6, 'This clearance is issued upon the request of the individual as a requirement for ', 0, 'L');

// Add purpose in purple
$pdf->SetXY(90, 164);
$pdf->SetTextColor($purple_color[0], $purple_color[1], $purple_color[2]);
$pdf->SetFont('times', 'B', 12);
$pdf->Cell(100, 10, htmlspecialchars($certificate['purpose_of_certificate']), 0, 1, 'L');

// Continue with black text
$pdf->SetXY(90, 174);
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('times', '', 11);
$pdf->MultiCell(100, 6, '. We have no record of any pending legal case or violation against the said individual within our jurisdiction.', 0, 'L');

$pdf->Ln(4);
$pdf->SetXY(90, 192);
$pdf->MultiCell(100, 6, 'This certificate is issued this ' . date('jS \d\a\y \of F, Y', strtotime($certificate['issue_date'])) . ' at the Barangay Hall of ' . htmlspecialchars($certificate['barangay_name']) . ', City of ' . htmlspecialchars($certificate['municipality']) . '.', 0, 'L');

// Add signature of Barangay Chairman
$pdf->SetXY(90, 222);
$pdf->SetTextColor($purple_color[0], $purple_color[1], $purple_color[2]);
$pdf->SetFont('times', 'B', 12);
$signature_image = __DIR__ . '/../images/signature.png';
if (file_exists($signature_image)) {
    $pdf->Image($signature_image, 110, 208, 40, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);
}
$pdf->Cell(100, 10, strtoupper(htmlspecialchars($certificate['barangay_captain_name'])), 0, 1, 'C');
$pdf->SetXY(90, 228);
$pdf->SetFont('times', 'I', 11);
$pdf->Cell(100, 10, 'Barangay Chairman', 0, 1, 'C');

// Add resident signature line
$pdf->SetXY(90, 242);
$pdf->SetFont('times', 'B', 12);
$signature_image = __DIR__ . '/../images/signature.png';
if (file_exists($signature_image)) {
    $pdf->Image($signature_image, 110, 235, 40, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);
}
$pdf->Cell(100, 10, '[YOUR SIGNATURE]', 0, 1, 'C');
$pdf->SetXY(90, 248);
$pdf->SetFont('times', 'I', 11);
$pdf->Cell(100, 10, 'SIGNATURE', 0, 1, 'C');

// Add seal image
$seal_image = __DIR__ . '/../images/seal.png';
if (file_exists($seal_image)) {
    $pdf->Image($seal_image, 160, 230, 40, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);
}

// Output PDF
$pdf->Output($certificate['certificate_type'] . '_' . $certificate_id . '.pdf', 'I');
exit;