<?php
ob_start(); // Start output buffering
session_start();
require 'config.php';

header('Content-Type: application/json');
// Add CORS headers if frontend is on a different domain/port
header('Access-Control-Allow-Origin: *'); // Adjust to specific origin in production
header('Access-Control-Allow-Methods: POST, GET');

// Check database connection
if (!$conn) {
    file_put_contents('login_debug.txt', "Database connection is null\n", FILE_APPEND);
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed.', 'errors' => ['Database connection failed.']]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize input
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    // Log raw POST data for debugging
    file_put_contents('login_debug.txt', "Raw POST: Email=" . (isset($_POST['email']) ? $_POST['email'] : 'unset') . ", Password=" . (isset($_POST['password']) ? 'set' : 'unset') . "\n", FILE_APPEND);

    // Basic validation
    if (!$email || !$password) {
        file_put_contents('login_debug.txt', "Missing fields: Email='$email', PasswordLength=" . strlen($password) . "\n", FILE_APPEND);
        ob_end_clean();
        echo json_encode(['status' => 'error', 'message' => 'Please fill in all fields.', 'errors' => ['Please fill in all fields.']]);
        exit;
    }

    // Validate Gmail address
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/@gmail\.com$/', $email)) {
        file_put_contents('login_debug.txt', "Invalid Gmail address: '$email'\n", FILE_APPEND);
        ob_end_clean();
        echo json_encode(['status' => 'error', 'message' => 'Please enter a valid Gmail address.', 'errors' => ['Please enter a valid Gmail address.']]);
        exit;
    }

    // Debug login attempt
    file_put_contents('login_debug.txt', "Login attempt: Email='$email', PasswordLength=" . strlen($password) . "\n", FILE_APPEND);

    try {
        // Check if user exists
        $stmt = $conn->prepare("SELECT id, username, email, password, role, is_approved, first_name, last_name FROM barangay_users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            file_put_contents('login_debug.txt', "No user found for email: '$email'\n", FILE_APPEND);
            ob_end_clean();
            echo json_encode(['status' => 'error', 'message' => 'Account not found.', 'errors' => ['Account not found.']]);
            exit;
        }

        file_put_contents('login_debug.txt', "DB values: Email='{$user['email']}', Role='{$user['role']}', Approved={$user['is_approved']}, PasswordHashLength=" . strlen($user['password']) . "\n", FILE_APPEND);

        // Verify password
        if (!password_verify($password, $user['password'])) {
            file_put_contents('login_debug.txt', "Password verification failed for email: '$email'\n", FILE_APPEND);
            ob_end_clean();
            echo json_encode(['status' => 'error', 'message' => 'Incorrect password.', 'errors' => ['Incorrect password.']]);
            exit;
        }

        // Check approval status
        if ($user['is_approved'] != 1) {
            file_put_contents('login_debug.txt', "Account not approved: Email='{$user['email']}'\n", FILE_APPEND);
            ob_end_clean();
            echo json_encode([
                'status' => 'error',
                'message' => 'Account not approved yet. Please contact an administrator.',
                'errors' => ['Account not approved yet. Please contact an administrator.'],
                'approved' => (int)$user['is_approved'],
                'role' => $user['role']
            ]);
            exit;
        }

        // Define valid roles
        $valid_roles = [
            'resident',
            'barangay captain',
            'admin',
            'treasurer',
            'secretary' // Normalized to lowercase
        ];

        // Normalize and validate role
        $db_role = strtolower(trim($user['role']));
        if (!in_array($db_role, $valid_roles)) {
            file_put_contents('login_debug.txt', "Invalid database role: '$db_role' for email: '$email'\n", FILE_APPEND);
            ob_end_clean();
            echo json_encode([
                'status' => 'error',
                'message' => 'Invalid role assigned to this account. Please contact an administrator.',
                'errors' => ['Invalid role assigned to this account. Please contact an administrator.']
            ]);
            exit;
        }

        // Determine dashboard URL based on role
        $dashboard_url = "dashboard.php";
        switch ($db_role) {
            case 'barangay captain':
            case 'admin':
                $dashboard_url = "admin.php";
                break;
            case 'treasurer':
                $dashboard_url = "treasurer.php";
                break;
            case 'secretary':
                $dashboard_url = "secretary.php";
                break;
        }

        // Clear existing session data
        session_unset();
        session_regenerate_id(true);

        // Set session
        $_SESSION['user'] = [
            'id' => $user['id'],
            'email' => $user['email'],
            'username' => $user['username'],
            'role' => $user['role'],
            'fullname' => trim($user['first_name'] . ' ' . $user['last_name'])
        ];

        file_put_contents('login_debug.txt', "Login success: Email='{$user['email']}', Role='{$user['role']}', Redirect='$dashboard_url'\n", FILE_APPEND);

        ob_end_clean();
        echo json_encode([
            'status' => 'success',
            'message' => 'Login successful!',
            'approved' => (int)$user['is_approved'],
            'role' => $user['role'],
            'redirect' => $dashboard_url
        ]);
    } catch (PDOException $e) {
        file_put_contents('login_debug.txt', "Database error: " . $e->getMessage() . "\n", FILE_APPEND);
        ob_end_clean();
        echo json_encode(['status' => 'error', 'message' => 'Database error.', 'errors' => ['Database error.']]);
        exit;
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Handle GET requests to check session status
    if (isset($_SESSION['user']) && isset($_SESSION['user']['id'])) {
        ob_end_clean();
        echo json_encode([
            'status' => 'success',
            'message' => 'Session active',
            'user' => [
                'id' => $_SESSION['user']['id'],
                'email' => $_SESSION['user']['email'],
                'role' => $_SESSION['user']['role'],
                'fullname' => $_SESSION['user']['fullname']
            ]
        ]);
    } else {
        ob_end_clean();
        echo json_encode([
            'status' => 'error',
            'message' => 'No active session.',
            'errors' => ['No active session.']
        ]);
    }
} else {
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.', 'errors' => ['Invalid request method.']]);
}
?>