<?php
header('Content-Type: application/json');
require 'config.php';

$certificate_id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_STRING);

if (!$certificate_id) {
    echo json_encode(['error' => 'Invalid certificate ID']);
    exit;
}

try {
    $stmt = $conn->prepare("SELECT * FROM certificates WHERE certificate_id = :id");
    $stmt->execute([':id' => $certificate_id]);
    $certificate = $stmt->fetch();
    if ($certificate) {
        echo json_encode($certificate);
    } else {
        echo json_encode(['error' => 'Certificate not found']);
    }
} catch (PDOException $e) {
    echo json_encode(['error' => 'Error fetching certificate: ' . $e->getMessage()]);
}
?>