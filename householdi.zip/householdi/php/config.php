<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'iihousehold');
define('DB_PASS', 'iihousehold');
define('DB_NAME', 'ihouseholds');

try {
    $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {
    file_put_contents('login_debug.txt', "PDO Connection failed: " . $e->getMessage() . "\n", FILE_APPEND);
    echo json_encode(['success' => false, 'message' => 'Database connection failed.', 'errors' => ['Database connection failed.']]);
    exit;
}
?>