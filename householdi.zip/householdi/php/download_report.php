<?php
session_start();
require_once '../vendor/autoload.php'; // Adjusted path
use Dompdf\Dompdf;

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'treasurer') {
    header('HTTP/1.1 403 Forbidden');
    exit('Unauthorized access');
}

if (!isset($_GET['id'])) {
    header('HTTP/1.1 400 Bad Request');
    exit('Invalid report ID');
}

$report_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if ($report_id === false || $report_id === null) {
    header('HTTP/1.1 400 Bad Request');
    exit('Invalid report ID');
}

$conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
if ($conn->connect_error) {
    error_log("Database connection failed: " . $conn->connect_error);
    header('HTTP/1.1 500 Internal Server Error');
    exit('Connection failed');
}

$stmt = $conn->prepare("SELECT report_type, report_period, month, year, total_income, total_expenses, file_path FROM financial_reports WHERE id = ?");
$stmt->bind_param("i", $report_id);
$stmt->execute();
$report = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$report) {
    $conn->close();
    header('HTTP/1.1 404 Not Found');
    exit('Report not found');
}

$reports_dir = '../reports';
if (!is_dir($reports_dir)) {
    mkdir($reports_dir, 0777, true);
}

$dompdf = new Dompdf();
$html = "
    <h1>" . htmlspecialchars($report['report_type']) . "</h1>
    <p><strong>Period:</strong> " . htmlspecialchars($report['report_period']) . "</p>
    <p><strong>Date:</strong> " . htmlspecialchars(sprintf('%02d-%04d', $report['month'], $report['year'])) . "</p>
    <p><strong>Total Income:</strong> ₱" . number_format($report['total_income'], 2) . "</p>
    <p><strong>Total Expenses:</strong> ₱" . number_format($report['total_expenses'], 2) . "</p>
";
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$pdf_content = $dompdf->output();

$file_path = '../' . $report['file_path'];
if (!file_put_contents($file_path, $pdf_content)) {
    $conn->close();
    error_log("Failed to save PDF: $file_path");
    header('HTTP/1.1 500 Internal Server Error');
    exit('Failed to generate report');
}

$conn->close();

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
header('Content-Length: ' . filesize($file_path));
readfile($file_path);
exit;
?>