<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'secretary') {
    exit;
}
$conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$document_id = filter_input(INPUT_POST, 'document_id', FILTER_VALIDATE_INT);
$stmt = $conn->prepare("SELECT bd.*, bu.first_name FROM barangay_documents bd JOIN barangay_users bu ON bd.uploaded_by = bu.id WHERE bd.document_id = ?");
$stmt->bind_param("i", $document_id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    echo "
        <p><strong>Title:</strong> " . htmlspecialchars($row['title']) . "</p>
        <p><strong>Type:</strong> " . htmlspecialchars($row['type']) . "</p>
        <p><strong>Description:</strong> " . htmlspecialchars($row['description'] ?: 'N/A') . "</p>
        <p><strong>Uploaded By:</strong> " . htmlspecialchars($row['first_name']) . "</p>
        <p><strong>Date Filed:</strong> " . date('M d, Y', strtotime($row['date_filed'])) . "</p>
        <p><strong>Status:</strong> " . htmlspecialchars($row['status']) . "</p>
        <p><a href='" . htmlspecialchars($row['file_path']) . "' target='_blank'>View File</a></p>
    ";
}
$stmt->close();
$conn->close();
?>