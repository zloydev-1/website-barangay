<?php
session_start();

if (isset($_POST['active_tab'])) {
    $_SESSION['active_tab'] = filter_input(INPUT_POST, 'active_tab', FILTER_SANITIZE_STRING);
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'No tab specified']);
}
?>