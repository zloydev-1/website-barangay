<?php
header('Content-Type: application/json');
require 'config.php';

$announcement_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$announcement_id) {
    echo json_encode(['error' => 'Invalid announcement ID']);
    exit;
}

try {
    $stmt = $conn->prepare("SELECT a.title, a.content, a.created_at, a.is_active, CONCAT(u.first_name, ' ', u.last_name) AS creator_name FROM announcements a JOIN barangay_users u ON a.created_by = u.id WHERE a.id = :id");
    $stmt->execute([':id' => $announcement_id]);
    $announcement = $stmt->fetch();
    if ($announcement) {
        echo json_encode($announcement);
    } else {
        echo json_encode(['error' => 'Announcement not found']);
    }
} catch (PDOException $e) {
    echo json_encode(['error' => 'Error fetching announcement: ' . $e->getMessage()]);
}
?>