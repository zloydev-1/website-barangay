<?php
require 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize input
    $email = trim($_POST['email'] ?? '');
    $old_password = trim($_POST['oldPassword'] ?? '');
    $new_password = trim($_POST['newPassword'] ?? '');
    $retype_new_password = trim($_POST['retypeNewPassword'] ?? '');

    // Basic validation
    $errors = [];
    if (empty($email)) {
        $errors['email'] = 'Email is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email address.';
    }
    if (empty($old_password)) {
        $errors['oldPassword'] = 'Old password is required.';
    }
    if (empty($new_password)) {
        $errors['newPassword'] = 'New password is required.';
    } elseif (strlen($new_password) < 8 || !preg_match('/[a-zA-Z]/', $new_password) || !preg_match('/\d/', $new_password)) {
        $errors['newPassword'] = 'Password must be at least 8 characters long with letters and numbers.';
    }
    if ($new_password !== $retype_new_password) {
        $errors['retypeNewPassword'] = 'Passwords do not match.';
    }

    if (!empty($errors)) {
        echo json_encode(['status' => 'error', 'errors' => $errors]);
        exit;
    }

    try {
        // Check if email exists
        $stmt = $conn->prepare("SELECT id, password FROM barangay_users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user) {
            echo json_encode(['status' => 'error', 'message' => 'Email not found.']);
            exit;
        }

        // Verify old password
        if (!password_verify($old_password, $user['password'])) {
            $errors['oldPassword'] = 'Incorrect old password.';
            echo json_encode(['status' => 'error', 'errors' => $errors]);
            exit;
        }

        // Update password
        $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("UPDATE barangay_users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE email = ?");
        $stmt->execute([$hashed_password, $email]);

        echo json_encode(['status' => 'success', 'message' => 'Password reset successful. Please log in with your new password.']);
    } catch (PDOException $e) {
        file_put_contents('reset_password_debug.txt', "Database error: " . $e->getMessage() . "\n", FILE_APPEND);
        echo json_encode(['status' => 'error', 'message' => 'An error occurred. Please try again later.']);
        exit;
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}
?>