<?php
session_start();
require_once '../vendor/autoload.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'secretary' || !isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
if ($conn->connect_error) {
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$request_id = filter_input(INPUT_POST, 'request_id', FILTER_VALIDATE_INT);
$action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);
if (!$request_id || !in_array($action, ['approve', 'reject'])) {
    echo json_encode(['error' => 'Invalid request']);
    exit;
}

$status = $action === 'approve' ? 'Approved' : 'Rejected';
$stmt = $conn->prepare("UPDATE certificate_requests SET status = ?, updated_at = NOW() WHERE id = ?");
$stmt->bind_param("si", $status, $request_id);
if ($stmt->execute()) {
    $log_stmt = $conn->prepare("INSERT INTO audit_logs (action, user_id, details, created_at) VALUES (?, ?, ?, NOW())");
    $log_action = "Certificate Request " . ucfirst($action) . "d";
    $details = ucfirst($action) . "d certificate request ID $request_id";
    $log_stmt->bind_param("sis", $log_action, $_SESSION['user']['id'], $details);
    $log_stmt->execute();
    $log_stmt->close();
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['error' => 'Error updating request: ' . $stmt->error]);
}
$stmt->close();
$conn->close();
?>