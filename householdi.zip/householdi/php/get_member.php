<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'secretary') {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
if ($conn->connect_error) {
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$member_id = filter_input(INPUT_POST, 'member_id', FILTER_VALIDATE_INT);
if (!$member_id) {
    echo json_encode(['error' => 'Invalid member ID']);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM household_members WHERE member_id = ?");
$stmt->bind_param("i", $member_id);
$stmt->execute();
$result = $stmt->get_result();
$member = $result->fetch_assoc();

if (!$member) {
    echo json_encode(['error' => 'Member not found']);
} else {
    echo json_encode($member);
}

$stmt->close();
$conn->close();
?>