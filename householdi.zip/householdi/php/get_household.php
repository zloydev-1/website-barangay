<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'secretary') {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
if ($conn->connect_error) {
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$household_id = filter_input(INPUT_POST, 'household_id', FILTER_VALIDATE_INT);
if (!$household_id) {
    echo json_encode(['error' => 'Invalid household ID']);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM households WHERE household_id = ?");
$stmt->bind_param("i", $household_id);
$stmt->execute();
$result = $stmt->get_result();
$household = $result->fetch_assoc();

if (!$household) {
    echo json_encode(['error' => 'Household not found']);
} else {
    echo json_encode($household);
}

$stmt->close();
$conn->close();
?>