<?php
session_start();
$conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'], $_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $id = intval($_POST['id']);
    $stmt = $conn->prepare("UPDATE certificate_requests SET status = 'Rejected' WHERE id = ? AND status = 'Pending'");
    $stmt->bind_param("i", $id);
    if ($stmt->execute() && $stmt->affected_rows > 0) {
        $log_stmt = $conn->prepare("INSERT INTO audit_logs (action, user_id, details, created_at) VALUES (?, ?, ?, NOW())");
        $action = "Certificate Request Rejected";
        $details = "Rejected request ID $id";
        $log_stmt->bind_param("sis", $action, $_SESSION['user']['id'], $details);
        $log_stmt->execute();
        $log_stmt->close();

        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Request not found or already processed.']);
    }
    $stmt->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request or CSRF token.']);
}
$conn->close();
?>