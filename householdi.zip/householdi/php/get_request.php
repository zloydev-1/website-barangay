<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'secretary') {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$conn = new mysqli('localhost', 'iihousehold', 'iihousehold', 'ihouseholds');
if ($conn->connect_error) {
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$request_id = filter_input(INPUT_POST, 'request_id', FILTER_VALIDATE_INT);
if (!$request_id) {
    echo json_encode(['error' => 'Invalid request ID']);
    exit;
}

$stmt = $conn->prepare("SELECT cr.*, bu.first_name FROM certificate_requests cr JOIN barangay_users bu ON cr.user_id = bu.id WHERE cr.id = ?");
$stmt->bind_param("i", $request_id);
$stmt->execute();
$result = $stmt->get_result();
$request = $result->fetch_assoc();

if (!$request) {
    echo json_encode(['error' => 'Request not found']);
} else {
    echo json_encode($request);
}

$stmt->close();
$conn->close();
?>